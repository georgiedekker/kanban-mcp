--
-- PostgreSQL database cluster dump
--

\restrict hu2yMFOj0Qg5503yMdGpBj6600vMZXnZxdKb3C3G3mooFBcdIY12Qpkn5KucdKw

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--

DROP DATABASE enterprise_mcp_server;
DROP DATABASE planka;




--
-- Drop roles
--

DROP ROLE postgres;


--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:RXXbR5Ez0xCVEUmXHIR9qA==$3o0TSW6x5rqx3qdlLk32OfFNrZRZVB8/K7bWHnwLmkQ=:xIdiISN265+TTY4Pv++lFB8dX/RomJ7hp+cbJs6PIT8=';

--
-- User Configurations
--








\unrestrict hu2yMFOj0Qg5503yMdGpBj6600vMZXnZxdKb3C3G3mooFBcdIY12Qpkn5KucdKw

--
-- Databases
--

--
-- Database "template1" dump
--

--
-- PostgreSQL database dump
--

\restrict Y3YdXhNoqhKyaoB9AMxTXksWNUSUKHpN9gXR6qzFdfheuc0vfSnEU6EdflxyyCK

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

UPDATE pg_catalog.pg_database SET datistemplate = false WHERE datname = 'template1';
DROP DATABASE template1;
--
-- Name: template1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE template1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE template1 OWNER TO postgres;

\unrestrict Y3YdXhNoqhKyaoB9AMxTXksWNUSUKHpN9gXR6qzFdfheuc0vfSnEU6EdflxyyCK
\connect template1
\restrict Y3YdXhNoqhKyaoB9AMxTXksWNUSUKHpN9gXR6qzFdfheuc0vfSnEU6EdflxyyCK

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE template1 IS 'default template for new databases';


--
-- Name: template1; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE template1 IS_TEMPLATE = true;


\unrestrict Y3YdXhNoqhKyaoB9AMxTXksWNUSUKHpN9gXR6qzFdfheuc0vfSnEU6EdflxyyCK
\connect template1
\restrict Y3YdXhNoqhKyaoB9AMxTXksWNUSUKHpN9gXR6qzFdfheuc0vfSnEU6EdflxyyCK

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: ACL; Schema: -; Owner: postgres
--

REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict Y3YdXhNoqhKyaoB9AMxTXksWNUSUKHpN9gXR6qzFdfheuc0vfSnEU6EdflxyyCK

--
-- Database "enterprise_mcp_server" dump
--

--
-- PostgreSQL database dump
--

\restrict e3s9edDDGk6B0YFkL0ngjgW6OeGvXqntiIYgah43u7q9MML8Je2gwUsJMbudw7e

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: enterprise_mcp_server; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE enterprise_mcp_server WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE enterprise_mcp_server OWNER TO postgres;

\unrestrict e3s9edDDGk6B0YFkL0ngjgW6OeGvXqntiIYgah43u7q9MML8Je2gwUsJMbudw7e
\connect enterprise_mcp_server
\restrict e3s9edDDGk6B0YFkL0ngjgW6OeGvXqntiIYgah43u7q9MML8Je2gwUsJMbudw7e

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    actor_id integer,
    actor_type text NOT NULL,
    action_type text NOT NULL,
    resource_type text NOT NULL,
    resource_id text,
    status text NOT NULL,
    details jsonb,
    request_id text,
    ip_address text
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_id_seq OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: mcp_tool_files; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mcp_tool_files (
    id integer NOT NULL,
    tool_id uuid NOT NULL,
    filename text NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.mcp_tool_files OWNER TO postgres;

--
-- Name: mcp_tool_files_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mcp_tool_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mcp_tool_files_id_seq OWNER TO postgres;

--
-- Name: mcp_tool_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mcp_tool_files_id_seq OWNED BY public.mcp_tool_files.id;


--
-- Name: mcp_tool_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mcp_tool_versions (
    id integer NOT NULL,
    tool_id uuid NOT NULL,
    version_number integer NOT NULL,
    code text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by integer,
    description text
);


ALTER TABLE public.mcp_tool_versions OWNER TO postgres;

--
-- Name: mcp_tool_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mcp_tool_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mcp_tool_versions_id_seq OWNER TO postgres;

--
-- Name: mcp_tool_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mcp_tool_versions_id_seq OWNED BY public.mcp_tool_versions.id;


--
-- Name: mcp_tools; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mcp_tools (
    id integer NOT NULL,
    tool_id uuid NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    code text NOT NULL,
    is_multi_file boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.mcp_tools OWNER TO postgres;

--
-- Name: mcp_tools_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mcp_tools_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mcp_tools_id_seq OWNER TO postgres;

--
-- Name: mcp_tools_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mcp_tools_id_seq OWNED BY public.mcp_tools.id;


--
-- Name: oauth_access_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_access_tokens (
    id integer NOT NULL,
    token text NOT NULL,
    client_id text NOT NULL,
    user_id integer,
    scope text,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.oauth_access_tokens OWNER TO postgres;

--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_access_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_access_tokens_id_seq OWNER TO postgres;

--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_access_tokens_id_seq OWNED BY public.oauth_access_tokens.id;


--
-- Name: oauth_auth_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_auth_codes (
    id integer NOT NULL,
    code text NOT NULL,
    client_id text NOT NULL,
    user_id integer,
    scope text,
    code_challenge text NOT NULL,
    code_challenge_method text NOT NULL,
    redirect_uri text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.oauth_auth_codes OWNER TO postgres;

--
-- Name: oauth_auth_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_auth_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_auth_codes_id_seq OWNER TO postgres;

--
-- Name: oauth_auth_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_auth_codes_id_seq OWNED BY public.oauth_auth_codes.id;


--
-- Name: oauth_clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_clients (
    id integer NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    client_name text NOT NULL,
    redirect_uris jsonb NOT NULL,
    client_uri text,
    logo_uri text,
    scope text,
    contacts jsonb,
    client_id_issued_at bigint NOT NULL,
    client_secret_expires_at bigint NOT NULL
);


ALTER TABLE public.oauth_clients OWNER TO postgres;

--
-- Name: oauth_clients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_clients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_clients_id_seq OWNER TO postgres;

--
-- Name: oauth_clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_clients_id_seq OWNED BY public.oauth_clients.id;


--
-- Name: oauth_refresh_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_refresh_tokens (
    id integer NOT NULL,
    token text NOT NULL,
    client_id text NOT NULL,
    user_id integer,
    scope text,
    access_token_id integer,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.oauth_refresh_tokens OWNER TO postgres;

--
-- Name: oauth_refresh_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_refresh_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_refresh_tokens_id_seq OWNER TO postgres;

--
-- Name: oauth_refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_refresh_tokens_id_seq OWNED BY public.oauth_refresh_tokens.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    name text NOT NULL,
    description text
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_permissions (
    role_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name text NOT NULL,
    description text
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    user_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password_hash text,
    api_key_hash text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone NOT NULL,
    email text
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: mcp_tool_files id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_files ALTER COLUMN id SET DEFAULT nextval('public.mcp_tool_files_id_seq'::regclass);


--
-- Name: mcp_tool_versions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_versions ALTER COLUMN id SET DEFAULT nextval('public.mcp_tool_versions_id_seq'::regclass);


--
-- Name: mcp_tools id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tools ALTER COLUMN id SET DEFAULT nextval('public.mcp_tools_id_seq'::regclass);


--
-- Name: oauth_access_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.oauth_access_tokens_id_seq'::regclass);


--
-- Name: oauth_auth_codes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_auth_codes ALTER COLUMN id SET DEFAULT nextval('public.oauth_auth_codes_id_seq'::regclass);


--
-- Name: oauth_clients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_clients ALTER COLUMN id SET DEFAULT nextval('public.oauth_clients_id_seq'::regclass);


--
-- Name: oauth_refresh_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_refresh_tokens ALTER COLUMN id SET DEFAULT nextval('public.oauth_refresh_tokens_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, "timestamp", actor_id, actor_type, action_type, resource_type, resource_id, status, details, request_id, ip_address) FROM stdin;
\.


--
-- Data for Name: mcp_tool_files; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mcp_tool_files (id, tool_id, filename, content, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mcp_tool_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mcp_tool_versions (id, tool_id, version_number, code, created_at, created_by, description) FROM stdin;
\.


--
-- Data for Name: mcp_tools; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mcp_tools (id, tool_id, name, description, code, is_multi_file, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: oauth_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_access_tokens (id, token, client_id, user_id, scope, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_auth_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_auth_codes (id, code, client_id, user_id, scope, code_challenge, code_challenge_method, redirect_uri, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_clients (id, client_id, client_secret, client_name, redirect_uris, client_uri, logo_uri, scope, contacts, client_id_issued_at, client_secret_expires_at) FROM stdin;
\.


--
-- Data for Name: oauth_refresh_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_refresh_tokens (id, token, client_id, user_id, scope, access_token_id, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (id, name, description) FROM stdin;
1	admin	Grants all permissions
2	tool:create	Create new tools
3	tool:read	Read tool definitions and list tools
4	tool:update	Update existing tools
5	tool:delete	Delete tools
6	tool:execute	Execute tools
7	tool:backup	Access and create tool backups
8	tool:restore	Restore tools from backups
9	user:create	Create new users
10	user:read	Read user information
11	user:update	Update user information
12	user:delete	Delete users
13	role:create	Create new roles
14	role:read	Read role information
15	role:update	Update roles and assign permissions
16	role:delete	Delete roles
17	role:assign	Assign roles to users
18	log:read	Read audit logs
19	gateway:configure	Configure gateway settings (e.g., allowed imports)
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
1	1
1	2
1	3
1	4
1	5
1	6
1	7
1	8
1	9
1	10
1	11
1	12
1	13
1	14
1	15
1	16
1	17
1	18
1	19
2	2
2	3
2	4
2	5
2	7
2	8
3	3
3	6
4	3
4	10
4	14
5	18
6	19
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, description) FROM stdin;
1	admin	Full administrative access with all permissions
2	tool_creator	Can create and manage tools
3	tool_user	Can execute tools
4	readonly	Read-only access to system information
5	auditor	Can view audit logs
6	api_gateway	Internal role for API Gateway communication
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (user_id, role_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password_hash, api_key_hash, is_active, created_at, email) FROM stdin;
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: mcp_tool_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mcp_tool_files_id_seq', 1, false);


--
-- Name: mcp_tool_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mcp_tool_versions_id_seq', 1, false);


--
-- Name: mcp_tools_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mcp_tools_id_seq', 1, false);


--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_access_tokens_id_seq', 1, false);


--
-- Name: oauth_auth_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_auth_codes_id_seq', 1, false);


--
-- Name: oauth_clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_clients_id_seq', 1, false);


--
-- Name: oauth_refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_refresh_tokens_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.permissions_id_seq', 228, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 72, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: mcp_tool_files mcp_tool_files_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_files
    ADD CONSTRAINT mcp_tool_files_pkey PRIMARY KEY (id);


--
-- Name: mcp_tool_files mcp_tool_files_tool_id_filename_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_files
    ADD CONSTRAINT mcp_tool_files_tool_id_filename_key UNIQUE (tool_id, filename);


--
-- Name: mcp_tool_versions mcp_tool_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_versions
    ADD CONSTRAINT mcp_tool_versions_pkey PRIMARY KEY (id);


--
-- Name: mcp_tool_versions mcp_tool_versions_tool_id_version_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_versions
    ADD CONSTRAINT mcp_tool_versions_tool_id_version_number_key UNIQUE (tool_id, version_number);


--
-- Name: mcp_tools mcp_tools_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tools
    ADD CONSTRAINT mcp_tools_name_key UNIQUE (name);


--
-- Name: mcp_tools mcp_tools_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tools
    ADD CONSTRAINT mcp_tools_pkey PRIMARY KEY (id);


--
-- Name: mcp_tools mcp_tools_tool_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tools
    ADD CONSTRAINT mcp_tools_tool_id_key UNIQUE (tool_id);


--
-- Name: oauth_access_tokens oauth_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT oauth_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_tokens oauth_access_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT oauth_access_tokens_token_key UNIQUE (token);


--
-- Name: oauth_auth_codes oauth_auth_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_auth_codes
    ADD CONSTRAINT oauth_auth_codes_code_key UNIQUE (code);


--
-- Name: oauth_auth_codes oauth_auth_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_auth_codes
    ADD CONSTRAINT oauth_auth_codes_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_client_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_clients
    ADD CONSTRAINT oauth_clients_client_id_key UNIQUE (client_id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_refresh_tokens oauth_refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_refresh_tokens
    ADD CONSTRAINT oauth_refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_refresh_tokens oauth_refresh_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_refresh_tokens
    ADD CONSTRAINT oauth_refresh_tokens_token_key UNIQUE (token);


--
-- Name: permissions permissions_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_key UNIQUE (name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: audit_logs_actor_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_logs_actor_id_idx ON public.audit_logs USING btree (actor_id);


--
-- Name: audit_logs_resource_type_resource_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_logs_resource_type_resource_id_idx ON public.audit_logs USING btree (resource_type, resource_id);


--
-- Name: audit_logs_timestamp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_logs_timestamp_idx ON public.audit_logs USING btree ("timestamp");


--
-- Name: oauth_access_tokens_expires_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_access_tokens_expires_at_idx ON public.oauth_access_tokens USING btree (expires_at);


--
-- Name: oauth_access_tokens_token_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_access_tokens_token_idx ON public.oauth_access_tokens USING btree (token);


--
-- Name: oauth_auth_codes_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_auth_codes_code_idx ON public.oauth_auth_codes USING btree (code);


--
-- Name: oauth_auth_codes_expires_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_auth_codes_expires_at_idx ON public.oauth_auth_codes USING btree (expires_at);


--
-- Name: oauth_clients_client_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_clients_client_id_idx ON public.oauth_clients USING btree (client_id);


--
-- Name: oauth_refresh_tokens_expires_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_refresh_tokens_expires_at_idx ON public.oauth_refresh_tokens USING btree (expires_at);


--
-- Name: oauth_refresh_tokens_token_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_refresh_tokens_token_idx ON public.oauth_refresh_tokens USING btree (token);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: audit_logs audit_logs_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: mcp_tool_files mcp_tool_files_tool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_files
    ADD CONSTRAINT mcp_tool_files_tool_id_fkey FOREIGN KEY (tool_id) REFERENCES public.mcp_tools(tool_id) ON DELETE CASCADE;


--
-- Name: mcp_tool_versions mcp_tool_versions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_versions
    ADD CONSTRAINT mcp_tool_versions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: mcp_tool_versions mcp_tool_versions_tool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_versions
    ADD CONSTRAINT mcp_tool_versions_tool_id_fkey FOREIGN KEY (tool_id) REFERENCES public.mcp_tools(tool_id) ON DELETE CASCADE;


--
-- Name: oauth_access_tokens oauth_access_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT oauth_access_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: oauth_auth_codes oauth_auth_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_auth_codes
    ADD CONSTRAINT oauth_auth_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: oauth_refresh_tokens oauth_refresh_tokens_access_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_refresh_tokens
    ADD CONSTRAINT oauth_refresh_tokens_access_token_id_fkey FOREIGN KEY (access_token_id) REFERENCES public.oauth_access_tokens(id) ON DELETE CASCADE;


--
-- Name: oauth_refresh_tokens oauth_refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_refresh_tokens
    ADD CONSTRAINT oauth_refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict e3s9edDDGk6B0YFkL0ngjgW6OeGvXqntiIYgah43u7q9MML8Je2gwUsJMbudw7e

--
-- Database "planka" dump
--

--
-- PostgreSQL database dump
--

\restrict Za45xWzbpLVFqVKLeDbPp4O2zxKpD8gZKLFXSyfYKiiKFOLIbuTb3pT4huwemab

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: planka; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE planka WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE planka OWNER TO postgres;

\unrestrict Za45xWzbpLVFqVKLeDbPp4O2zxKpD8gZKLFXSyfYKiiKFOLIbuTb3pT4huwemab
\connect planka
\restrict Za45xWzbpLVFqVKLeDbPp4O2zxKpD8gZKLFXSyfYKiiKFOLIbuTb3pT4huwemab

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: next_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.next_id(OUT id bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
      DECLARE
        shard INT := 1;
        epoch BIGINT := 1567191600000;
        sequence BIGINT;
        milliseconds BIGINT;
      BEGIN
        SELECT nextval('next_id_seq') % 1024 INTO sequence;
        SELECT FLOOR(EXTRACT(EPOCH FROM clock_timestamp()) * 1000) INTO milliseconds;
        id := (milliseconds - epoch) << 23;
        id := id | (shard << 10);
        id := id | (sequence);
      END;
    $$;


ALTER FUNCTION public.next_id(OUT id bigint) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.action (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint,
    type text NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    board_id bigint
);


ALTER TABLE public.action OWNER TO postgres;

--
-- Name: attachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attachment (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    creator_user_id bigint,
    type text NOT NULL,
    data jsonb NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.attachment OWNER TO postgres;

--
-- Name: background_image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.background_image (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    uploaded_file_id text NOT NULL,
    extension text NOT NULL,
    size bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.background_image OWNER TO postgres;

--
-- Name: base_custom_field_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.base_custom_field_group (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.base_custom_field_group OWNER TO postgres;

--
-- Name: board; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text NOT NULL,
    default_view text NOT NULL,
    default_card_type text NOT NULL,
    limit_card_types_to_default_one boolean NOT NULL,
    always_display_card_creator boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    expand_task_lists_by_default boolean NOT NULL
);


ALTER TABLE public.board OWNER TO postgres;

--
-- Name: board_membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board_membership (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    board_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role text NOT NULL,
    can_comment boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.board_membership OWNER TO postgres;

--
-- Name: board_subscription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board_subscription (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.board_subscription OWNER TO postgres;

--
-- Name: card; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    list_id bigint NOT NULL,
    creator_user_id bigint,
    prev_list_id bigint,
    cover_attachment_id bigint,
    type text NOT NULL,
    "position" double precision,
    name text NOT NULL,
    description text,
    due_date timestamp without time zone,
    stopwatch jsonb,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    list_changed_at timestamp without time zone,
    comments_total integer NOT NULL,
    is_closed boolean NOT NULL,
    is_due_completed boolean
);


ALTER TABLE public.card OWNER TO postgres;

--
-- Name: card_label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_label (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    label_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_label OWNER TO postgres;

--
-- Name: card_membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_membership (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_membership OWNER TO postgres;

--
-- Name: card_subscription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_subscription (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint NOT NULL,
    is_permanent boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_subscription OWNER TO postgres;

--
-- Name: comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comment (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint,
    text text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.comment OWNER TO postgres;

--
-- Name: config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.config (
    id bigint DEFAULT public.next_id() NOT NULL,
    is_initialized boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    smtp_host text,
    smtp_port integer,
    smtp_name text,
    smtp_secure boolean NOT NULL,
    smtp_tls_reject_unauthorized boolean NOT NULL,
    smtp_user text,
    smtp_password text,
    smtp_from text
);


ALTER TABLE public.config OWNER TO postgres;

--
-- Name: custom_field; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_field (
    id bigint DEFAULT public.next_id() NOT NULL,
    base_custom_field_group_id bigint,
    custom_field_group_id bigint,
    "position" double precision NOT NULL,
    name text NOT NULL,
    show_on_front_of_card boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.custom_field OWNER TO postgres;

--
-- Name: custom_field_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_field_group (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint,
    card_id bigint,
    base_custom_field_group_id bigint,
    "position" double precision NOT NULL,
    name text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.custom_field_group OWNER TO postgres;

--
-- Name: custom_field_value; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_field_value (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    custom_field_group_id bigint NOT NULL,
    custom_field_id bigint NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.custom_field_value OWNER TO postgres;

--
-- Name: identity_provider_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.identity_provider_user (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    issuer text NOT NULL,
    sub text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.identity_provider_user OWNER TO postgres;

--
-- Name: label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.label (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text,
    color text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.label OWNER TO postgres;

--
-- Name: list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.list (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    type text NOT NULL,
    "position" double precision,
    name text,
    color text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.list OWNER TO postgres;

--
-- Name: migration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migration (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


ALTER TABLE public.migration OWNER TO postgres;

--
-- Name: migration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_id_seq OWNER TO postgres;

--
-- Name: migration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migration_id_seq OWNED BY public.migration.id;


--
-- Name: migration_lock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migration_lock (
    index integer NOT NULL,
    is_locked integer
);


ALTER TABLE public.migration_lock OWNER TO postgres;

--
-- Name: migration_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migration_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_lock_index_seq OWNER TO postgres;

--
-- Name: migration_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migration_lock_index_seq OWNED BY public.migration_lock.index;


--
-- Name: next_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.next_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.next_id_seq OWNER TO postgres;

--
-- Name: notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    creator_user_id bigint,
    board_id bigint NOT NULL,
    card_id bigint NOT NULL,
    comment_id bigint,
    action_id bigint,
    type text NOT NULL,
    data jsonb NOT NULL,
    is_read boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.notification OWNER TO postgres;

--
-- Name: notification_service; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_service (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint,
    board_id bigint,
    url text NOT NULL,
    format text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.notification_service OWNER TO postgres;

--
-- Name: project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project (
    id bigint DEFAULT public.next_id() NOT NULL,
    owner_project_manager_id bigint,
    background_image_id bigint,
    name text NOT NULL,
    description text,
    background_type text,
    background_gradient text,
    is_hidden boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.project OWNER TO postgres;

--
-- Name: project_favorite; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_favorite (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.project_favorite OWNER TO postgres;

--
-- Name: project_manager; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_manager (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.project_manager OWNER TO postgres;

--
-- Name: session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    access_token text,
    http_only_token text,
    remote_address text NOT NULL,
    user_agent text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    pending_token text
);


ALTER TABLE public.session OWNER TO postgres;

--
-- Name: storage_usage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.storage_usage (
    id bigint DEFAULT public.next_id() NOT NULL,
    total bigint NOT NULL,
    user_avatars bigint NOT NULL,
    background_images bigint NOT NULL,
    attachments bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.storage_usage OWNER TO postgres;

--
-- Name: task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task (
    id bigint DEFAULT public.next_id() NOT NULL,
    task_list_id bigint NOT NULL,
    assignee_user_id bigint,
    "position" double precision NOT NULL,
    name text NOT NULL,
    is_completed boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    linked_card_id bigint
);


ALTER TABLE public.task OWNER TO postgres;

--
-- Name: task_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_list (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text NOT NULL,
    show_on_front_of_card boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    hide_completed_tasks boolean NOT NULL
);


ALTER TABLE public.task_list OWNER TO postgres;

--
-- Name: uploaded_file; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.uploaded_file (
    id text DEFAULT public.next_id() NOT NULL,
    references_total integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    type text NOT NULL,
    mime_type text,
    size bigint NOT NULL
);


ALTER TABLE public.uploaded_file OWNER TO postgres;

--
-- Name: user_account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_account (
    id bigint DEFAULT public.next_id() NOT NULL,
    email text NOT NULL,
    password text,
    role text NOT NULL,
    name text NOT NULL,
    username text,
    avatar jsonb,
    phone text,
    organization text,
    language text,
    subscribe_to_own_cards boolean NOT NULL,
    subscribe_to_card_when_commenting boolean NOT NULL,
    turn_off_recent_card_highlighting boolean NOT NULL,
    enable_favorites_by_default boolean NOT NULL,
    default_editor_mode text NOT NULL,
    default_home_view text NOT NULL,
    default_projects_order text NOT NULL,
    is_sso_user boolean NOT NULL,
    is_deactivated boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    password_changed_at timestamp without time zone,
    terms_signature text,
    terms_accepted_at timestamp without time zone,
    api_key_prefix text,
    api_key_hash text,
    api_key_created_at timestamp without time zone
);


ALTER TABLE public.user_account OWNER TO postgres;

--
-- Name: webhook; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.webhook (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint,
    name text NOT NULL,
    url text NOT NULL,
    access_token text,
    events text[],
    excluded_events text[],
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.webhook OWNER TO postgres;

--
-- Name: migration id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration ALTER COLUMN id SET DEFAULT nextval('public.migration_id_seq'::regclass);


--
-- Name: migration_lock index; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration_lock ALTER COLUMN index SET DEFAULT nextval('public.migration_lock_index_seq'::regclass);


--
-- Data for Name: action; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.action (id, card_id, user_id, type, data, created_at, updated_at, board_id) FROM stdin;
1566011327149769792	1566011327091049535	1560278692305830913	createCard	{"card": {"name": "test"}, "list": {"id": "1566004621732742167", "name": "TODO", "type": "active"}}	2025-07-30 11:24:57.736	\N	1541385320996537361
1566031207873905757	1566011327091049535	1560328737491256322	moveCard	{"card": {"name": "test"}, "toList": {"id": "1566004621741130776", "name": "READY", "type": "active"}, "fromList": {"id": "1566004621732742167", "name": "TODO", "type": "active"}}	2025-07-30 12:04:27.702	\N	1541385320996537361
1566031272583627871	1566011327091049535	1560328737491256322	moveCard	{"card": {"name": "test"}, "toList": {"id": "1566004621732742167", "name": "TODO", "type": "active"}, "fromList": {"id": "1566004621741130776", "name": "READY", "type": "active"}}	2025-07-30 12:04:35.417	\N	1541385320996537361
1566031331001893985	1566011327091049535	1560328737491256322	moveCard	{"card": {"name": "test"}, "toList": {"id": "1566004621741130776", "name": "READY", "type": "active"}, "fromList": {"id": "1566004621732742167", "name": "TODO", "type": "active"}}	2025-07-30 12:04:42.38	\N	1541385320996537361
1566031382063350883	1566011327091049535	1560328737491256322	moveCard	{"card": {"name": "test"}, "toList": {"id": "1566004621732742167", "name": "TODO", "type": "active"}, "fromList": {"id": "1566004621741130776", "name": "READY", "type": "active"}}	2025-07-30 12:04:48.468	\N	1541385320996537361
1566034264774935664	1566034264749769839	1560328737491256322	createCard	{"card": {"name": "test"}, "list": {"id": "1566000088495424528", "name": "TODO", "type": "active"}}	2025-07-30 12:10:32.115	\N	1565999911277691916
1626139517637363562	1626139517612197737	1560328737491256322	createCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "list": {"id": "1626139471978170170", "name": "TODO", "type": "active"}}	2025-10-21 10:28:56.607	\N	1626139471911061302
1626139517838690156	1626139517830301547	1560328737491256322	createCard	{"card": {"name": "Load Quality Requirements"}, "list": {"id": "1626139471978170170", "name": "TODO", "type": "active"}}	2025-10-21 10:28:56.632	\N	1626139471911061302
1626139518023239534	1626139518014850925	1560328737491256322	createCard	{"card": {"name": "Extract Repo-Specific Principles"}, "list": {"id": "1626139471978170170", "name": "TODO", "type": "active"}}	2025-10-21 10:28:56.654	\N	1626139471911061302
1626139518191011696	1626139518182623087	1560328737491256322	createCard	{"card": {"name": "Load Prompt Templates"}, "list": {"id": "1626139471978170170", "name": "TODO", "type": "active"}}	2025-10-21 10:28:56.674	\N	1626139471911061302
1626139518325229426	1626139518316840817	1560328737491256322	createCard	{"card": {"name": "Validate META Asset Completeness"}, "list": {"id": "1626139471978170170", "name": "TODO", "type": "active"}}	2025-10-21 10:28:56.69	\N	1626139471911061302
1626139518417504115	1626139517612197737	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "toList": {"id": "1626139472045279035", "name": "READY", "type": "active"}, "fromList": {"id": "1626139471978170170", "name": "TODO", "type": "active"}}	2025-10-21 10:28:56.701	\N	1626139471911061302
1626139640698242938	1626139517612197737	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "toList": {"id": "1626139472095610684", "name": "DOING", "type": "active"}, "fromList": {"id": "1626139472045279035", "name": "READY", "type": "active"}}	2025-10-21 10:29:11.278	\N	1626139471911061302
1626144083749636040	1626144083716081607	1560328737491256322	createCard	{"card": {"name": "Load Core Procedures for CLASSIFICATION"}, "list": {"id": "1626143869420701589", "name": "TODO", "type": "active"}}	2025-10-21 10:38:00.931	\N	1626143869236152209
1626144083950962634	1626144083934185417	1560328737491256322	createCard	{"card": {"name": "Load Quality Requirements"}, "list": {"id": "1626143869420701589", "name": "TODO", "type": "active"}}	2025-10-21 10:38:00.954	\N	1626143869236152209
1626144084101957580	1626144084093568971	1560328737491256322	createCard	{"card": {"name": "Load Prompt Templates"}, "list": {"id": "1626143869420701589", "name": "TODO", "type": "active"}}	2025-10-21 10:38:00.973	\N	1626143869236152209
1626144084244563918	1626144084236175309	1560328737491256322	createCard	{"card": {"name": "Validate META Asset Completeness"}, "list": {"id": "1626143869420701589", "name": "TODO", "type": "active"}}	2025-10-21 10:38:00.99	\N	1626143869236152209
1626144084362004431	1626144083716081607	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CLASSIFICATION"}, "toList": {"id": "1626143869512976278", "name": "READY", "type": "active"}, "fromList": {"id": "1626143869420701589", "name": "TODO", "type": "active"}}	2025-10-21 10:38:01.003	\N	1626143869236152209
1626144575967987669	1626144083716081607	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CLASSIFICATION"}, "toList": {"id": "1626143869580085143", "name": "DOING", "type": "active"}, "fromList": {"id": "1626143869512976278", "name": "READY", "type": "active"}}	2025-10-21 10:38:59.608	\N	1626143869236152209
1626762360104420387	1626762360079254562	1560328737491256322	createCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "list": {"id": "1626762338889631728", "name": "TODO", "type": "active"}}	2025-10-22 07:06:25.215	\N	1626762338814134252
1626762360305746981	1626762360297358372	1560328737491256322	createCard	{"card": {"name": "Load Quality Requirements"}, "list": {"id": "1626762338889631728", "name": "TODO", "type": "active"}}	2025-10-22 07:06:25.24	\N	1626762338814134252
1626762360456741927	1626762360439964710	1560328737491256322	createCard	{"card": {"name": "Extract Repo-Specific Principles"}, "list": {"id": "1626762338889631728", "name": "TODO", "type": "active"}}	2025-10-22 07:06:25.257	\N	1626762338814134252
1626762360599348265	1626762360582571048	1560328737491256322	createCard	{"card": {"name": "Load Prompt Templates"}, "list": {"id": "1626762338889631728", "name": "TODO", "type": "active"}}	2025-10-22 07:06:25.274	\N	1626762338814134252
1626762360725177387	1626762360716788778	1560328737491256322	createCard	{"card": {"name": "Validate META Asset Completeness"}, "list": {"id": "1626762338889631728", "name": "TODO", "type": "active"}}	2025-10-22 07:06:25.29	\N	1626762338814134252
1626762360834229292	1626762360079254562	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "toList": {"id": "1626762338956740593", "name": "READY", "type": "active"}, "fromList": {"id": "1626762338889631728", "name": "TODO", "type": "active"}}	2025-10-22 07:06:25.303	\N	1626762338814134252
1626762741291156531	1626762360079254562	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "toList": {"id": "1626762339007072242", "name": "DOING", "type": "active"}, "fromList": {"id": "1626762338956740593", "name": "READY", "type": "active"}}	2025-10-22 07:07:10.656	\N	1626762338814134252
1626777168304407682	1626777168279241857	1560328737491256322	createCard	{"card": {"name": "Load Core Procedures for ANALYSIS"}, "list": {"id": "1626777064319222863", "name": "TODO", "type": "active"}}	2025-10-22 07:35:50.491	\N	1626777064243725387
1626777168514122884	1626777168497345667	1560328737491256322	createCard	{"card": {"name": "Load Quality Requirements"}, "list": {"id": "1626777064319222863", "name": "TODO", "type": "active"}}	2025-10-22 07:35:50.516	\N	1626777064243725387
1626777168698672262	1626777168690283653	1560328737491256322	createCard	{"card": {"name": "Load Prompt Templates"}, "list": {"id": "1626777064319222863", "name": "TODO", "type": "active"}}	2025-10-22 07:35:50.538	\N	1626777064243725387
1626777168883221640	1626777168866444423	1560328737491256322	createCard	{"card": {"name": "Validate META Asset Completeness"}, "list": {"id": "1626777064319222863", "name": "TODO", "type": "active"}}	2025-10-22 07:35:50.56	\N	1626777064243725387
1626777169009050761	1626777168279241857	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for ANALYSIS"}, "toList": {"id": "1626777064369554512", "name": "READY", "type": "active"}, "fromList": {"id": "1626777064319222863", "name": "TODO", "type": "active"}}	2025-10-22 07:35:50.574	\N	1626777064243725387
1626840782038107344	1626840781996164303	1560328737491256322	createCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "list": {"id": "1626840257431340189", "name": "TODO", "type": "active"}}	2025-10-22 09:42:13.839	\N	1626840257347454105
1626840782264599762	1626840782256211153	1560328737491256322	createCard	{"card": {"name": "Load Quality Requirements"}, "list": {"id": "1626840257431340189", "name": "TODO", "type": "active"}}	2025-10-22 09:42:13.866	\N	1626840257347454105
1626840782415594708	1626840782407206099	1560328737491256322	createCard	{"card": {"name": "Extract Repo-Specific Principles"}, "list": {"id": "1626840257431340189", "name": "TODO", "type": "active"}}	2025-10-22 09:42:13.884	\N	1626840257347454105
1626840782558201046	1626840782541423829	1560328737491256322	createCard	{"card": {"name": "Load Prompt Templates"}, "list": {"id": "1626840257431340189", "name": "TODO", "type": "active"}}	2025-10-22 09:42:13.9	\N	1626840257347454105
1626840782692418776	1626840782684030167	1560328737491256322	createCard	{"card": {"name": "Validate META Asset Completeness"}, "list": {"id": "1626840257431340189", "name": "TODO", "type": "active"}}	2025-10-22 09:42:13.916	\N	1626840257347454105
1626840782835025113	1626840781996164303	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "toList": {"id": "1626840257506837662", "name": "READY", "type": "active"}, "fromList": {"id": "1626840257431340189", "name": "TODO", "type": "active"}}	2025-10-22 09:42:13.934	\N	1626840257347454105
1626853522446222624	1626853522404279583	1560328737491256322	createCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "list": {"id": "1626853200306898157", "name": "TODO", "type": "active"}}	2025-10-22 10:07:32.613	\N	1626853200231400681
1626853522630772002	1626853522622383393	1560328737491256322	createCard	{"card": {"name": "Load Quality Requirements"}, "list": {"id": "1626853200306898157", "name": "TODO", "type": "active"}}	2025-10-22 10:07:32.636	\N	1626853200231400681
1626853522790155556	1626853522773378339	1560328737491256322	createCard	{"card": {"name": "Extract Repo-Specific Principles"}, "list": {"id": "1626853200306898157", "name": "TODO", "type": "active"}}	2025-10-22 10:07:32.654	\N	1626853200231400681
1626853522924373286	1626853522915984677	1560328737491256322	createCard	{"card": {"name": "Load Prompt Templates"}, "list": {"id": "1626853200306898157", "name": "TODO", "type": "active"}}	2025-10-22 10:07:32.671	\N	1626853200231400681
1626853523058591016	1626853523050202407	1560328737491256322	createCard	{"card": {"name": "Validate META Asset Completeness"}, "list": {"id": "1626853200306898157", "name": "TODO", "type": "active"}}	2025-10-22 10:07:32.687	\N	1626853200231400681
1626853523150865705	1626853522404279583	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "toList": {"id": "1626853200365618414", "name": "READY", "type": "active"}, "fromList": {"id": "1626853200306898157", "name": "TODO", "type": "active"}}	2025-10-22 10:07:32.698	\N	1626853200231400681
1626890447974565166	1626139517612197737	1560328737491256322	addMemberToCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "user": {"id": "1560328737491256325", "name": "Meta Agent"}}	2025-10-22 11:20:54.479	\N	1626139471911061302
1626893542825657720	1626893542792103287	1560328737491256322	createCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "list": {"id": "1626893018537657669", "name": "TODO", "type": "active"}}	2025-10-22 11:27:03.415	\N	1626893018478937409
1626893543052150138	1626893543035372921	1560328737491256322	createCard	{"card": {"name": "Load Quality Requirements"}, "list": {"id": "1626893018537657669", "name": "TODO", "type": "active"}}	2025-10-22 11:27:03.441	\N	1626893018478937409
1626893543177979260	1626893543169590651	1560328737491256322	createCard	{"card": {"name": "Extract Repo-Specific Principles"}, "list": {"id": "1626893018537657669", "name": "TODO", "type": "active"}}	2025-10-22 11:27:03.457	\N	1626893018478937409
1626893543614186878	1626893543597409661	1560328737491256322	createCard	{"card": {"name": "Load Prompt Templates"}, "list": {"id": "1626893018537657669", "name": "TODO", "type": "active"}}	2025-10-22 11:27:03.508	\N	1626893018478937409
1626893543815513472	1626893543798736255	1560328737491256322	createCard	{"card": {"name": "Validate META Asset Completeness"}, "list": {"id": "1626893018537657669", "name": "TODO", "type": "active"}}	2025-10-22 11:27:03.533	\N	1626893018478937409
1626893543941342593	1626893542792103287	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "toList": {"id": "1626893018579600710", "name": "READY", "type": "active"}, "fromList": {"id": "1626893018537657669", "name": "TODO", "type": "active"}}	2025-10-22 11:27:03.548	\N	1626893018478937409
1626978457432884681	1626978457390941640	1560328737491256322	createCard	{"card": {"name": "Load Core Procedures for ANALYSIS"}, "list": {"id": "1626978048832177558", "name": "TODO", "type": "active"}}	2025-10-22 14:15:46.025	\N	1626978048739902866
1626978457667765707	1626978457650988490	1560328737491256322	createCard	{"card": {"name": "Load Quality Requirements"}, "list": {"id": "1626978048832177558", "name": "TODO", "type": "active"}}	2025-10-22 14:15:46.053	\N	1626978048739902866
1626978457818760653	1626978457810372044	1560328737491256322	createCard	{"card": {"name": "Load Prompt Templates"}, "list": {"id": "1626978048832177558", "name": "TODO", "type": "active"}}	2025-10-22 14:15:46.071	\N	1626978048739902866
1626978457978144207	1626978457961366990	1560328737491256322	createCard	{"card": {"name": "Validate META Asset Completeness"}, "list": {"id": "1626978048832177558", "name": "TODO", "type": "active"}}	2025-10-22 14:15:46.09	\N	1626978048739902866
1626978458120750544	1626978457390941640	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for ANALYSIS"}, "toList": {"id": "1626978048890897815", "name": "READY", "type": "active"}, "fromList": {"id": "1626978048832177558", "name": "TODO", "type": "active"}}	2025-10-22 14:15:46.106	\N	1626978048739902866
1626995678448190999	1626995678414636566	1560328737491256322	createCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "list": {"id": "1626995071356241380", "name": "TODO", "type": "active"}}	2025-10-22 14:49:58.929	\N	1626995071297521120
1626995678615963161	1626995678599185944	1560328737491256322	createCard	{"card": {"name": "Load Quality Requirements"}, "list": {"id": "1626995071356241380", "name": "TODO", "type": "active"}}	2025-10-22 14:49:58.949	\N	1626995071297521120
1626995678741792283	1626995678725015066	1560328737491256322	createCard	{"card": {"name": "Load Prompt Templates"}, "list": {"id": "1626995071356241380", "name": "TODO", "type": "active"}}	2025-10-22 14:49:58.964	\N	1626995071297521120
1626995678859232797	1626995678842455580	1560328737491256322	createCard	{"card": {"name": "Validate META Asset Completeness"}, "list": {"id": "1626995071356241380", "name": "TODO", "type": "active"}}	2025-10-22 14:49:58.978	\N	1626995071297521120
1626995678985061918	1626995678414636566	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "toList": {"id": "1626995071406573029", "name": "READY", "type": "active"}, "fromList": {"id": "1626995071356241380", "name": "TODO", "type": "active"}}	2025-10-22 14:49:58.993	\N	1626995071297521120
1627093220754196070	1627093220729030245	1560328737491256322	createCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "list": {"id": "1627092980814841395", "name": "TODO", "type": "active"}}	2025-10-22 18:03:46.879	\N	1627092980756121135
1627093221047797352	1627093221022631527	1560328737491256322	createCard	{"card": {"name": "Load Quality Requirements"}, "list": {"id": "1627092980814841395", "name": "TODO", "type": "active"}}	2025-10-22 18:03:46.913	\N	1627092980756121135
1627093221232346730	1627093221223958121	1560328737491256322	createCard	{"card": {"name": "Load Prompt Templates"}, "list": {"id": "1627092980814841395", "name": "TODO", "type": "active"}}	2025-10-22 18:03:46.936	\N	1627092980756121135
1627093221467227756	1627093221450450539	1560328737491256322	createCard	{"card": {"name": "Validate META Asset Completeness"}, "list": {"id": "1627092980814841395", "name": "TODO", "type": "active"}}	2025-10-22 18:03:46.964	\N	1627092980756121135
1627093221626611309	1627093220729030245	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "toList": {"id": "1627092980881950260", "name": "READY", "type": "active"}, "fromList": {"id": "1627092980814841395", "name": "TODO", "type": "active"}}	2025-10-22 18:03:46.982	\N	1627092980756121135
1627548744608122480	1627548744566179439	1560328737491256322	createCard	{"card": {"name": "fwe"}, "list": {"id": "1573201068957894398", "name": "TODO", "type": "active"}}	2025-10-23 09:08:49.553	\N	1573201068874008314
1635621825411024644	1635621824966428401	1560328737491256322	createCard	{"card": {"name": "Template_Card (copy)"}, "list": {"id": "1573201068957894398", "name": "TODO", "type": "active"}}	2025-11-03 12:28:35.78	\N	1573201068874008314
1636624469504034705	1636624469462091664	1560328737491256322	createCard	{"card": {"name": "Analyze enterprise_mcp_server Repository"}, "list": {"id": "1636624466509301623", "name": "TODO", "type": "active"}}	2025-11-04 21:40:40.27	\N	1636624465494280050
1636629176838522821	1636629176813356996	1560328737491256322	createCard	{"card": {"name": "Analyze enterprise_mcp_server Repository"}, "list": {"id": "1636629173902509995", "name": "TODO", "type": "active"}}	2025-11-04 21:50:01.429	\N	1636629173223032742
1636635396001499113	1636635395984721896	1560328737491256322	createCard	{"card": {"name": "Analyze enterprise_mcp_server Repository"}, "list": {"id": "1636635392679610319", "name": "TODO", "type": "active"}}	2025-11-04 22:02:22.81	\N	1636635392016910282
1636639391738758157	1636639391713592332	1560328737491256322	createCard	{"card": {"name": "Analyze enterprise_mcp_server Repository"}, "list": {"id": "1636639388609808371", "name": "TODO", "type": "active"}}	2025-11-04 22:10:19.139	\N	1636639387921942510
1637207033474188346	1637207033390302265	1560328737491256322	createCard	{"card": {"name": "✅ Windmill MCP Integration Test"}, "list": {"id": "1637150844489040942", "name": "To Do", "type": "active"}}	2025-11-05 16:58:07.307	\N	1637150844338045993
1637647748314432574	1637647748255712317	1560328737491256322	createCard	{"card": {"name": "Analyze: Sales_Website"}, "list": {"id": "1637150844489040942", "name": "To Do", "type": "active"}}	2025-11-06 07:33:44.61	\N	1637150844338045993
1637836185172706370	1637836185097208897	1560328737491256322	createCard	{"card": {"name": "Analyze: Sales_Website"}, "list": {"id": "1637150844489040942", "name": "To Do", "type": "active"}}	2025-11-06 13:48:08.034	\N	1637150844338045993
\.


--
-- Data for Name: attachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attachment (id, card_id, creator_user_id, type, data, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: background_image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.background_image (id, project_id, uploaded_file_id, extension, size, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: base_custom_field_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.base_custom_field_group (id, project_id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: board; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board (id, project_id, "position", name, default_view, default_card_type, limit_card_types_to_default_one, always_display_card_creator, created_at, updated_at, expand_task_lists_by_default) FROM stdin;
1573201068874008314	1573201067548608248	1	EXECUTION	kanban	project	f	f	2025-08-09 09:29:41.74	\N	f
1573201069712869127	1573201067548608248	16385	KANBAN	kanban	project	f	f	2025-08-09 09:29:41.841	\N	f
1573201070316848916	1573201067548608248	8193	META	kanban	project	f	f	2025-08-09 09:29:41.912	\N	f
1626139470484997931	1626139469679691560	1	EXECUTION	kanban	project	f	f	2025-10-21 10:28:50.986	\N	f
1626139471911061302	1626139469679691560	8193	META	kanban	project	f	f	2025-10-21 10:28:51.156	\N	f
1626139472775087937	1626139469679691560	16385	KANBAN	kanban	project	f	f	2025-10-21 10:28:51.26	\N	f
1626139473588782924	1626139469679691560	81921	PROJECT	kanban	project	f	f	2025-10-21 10:28:51.357	\N	f
1626143868271462278	1626143867390658435	1	EXECUTION	kanban	project	f	f	2025-10-21 10:37:35.244	\N	f
1626143869236152209	1626143867390658435	8193	META	kanban	project	f	f	2025-10-21 10:37:35.358	\N	f
1626143870267951004	1626143867390658435	16385	KANBAN	kanban	project	f	f	2025-10-21 10:37:35.481	\N	f
1626143871081645991	1626143867390658435	81921	PROJECT	kanban	project	f	f	2025-10-21 10:37:35.578	\N	f
1626762337480345569	1626762336809256926	1	EXECUTION	kanban	project	f	f	2025-10-22 07:06:22.519	\N	f
1626762338814134252	1626762336809256926	8193	META	kanban	project	f	f	2025-10-22 07:06:22.678	\N	f
1626762339703326711	1626762336809256926	16385	KANBAN	kanban	project	f	f	2025-10-22 07:06:22.784	\N	f
1626762340525409282	1626762336809256926	81921	PROJECT	kanban	project	f	f	2025-10-22 07:06:22.882	\N	f
1626777062960268352	1626777062339511357	1	EXECUTION	kanban	project	f	f	2025-10-22 07:35:37.933	\N	f
1626777064243725387	1626777062339511357	8193	META	kanban	project	f	f	2025-10-22 07:35:38.085	\N	f
1626777065636234326	1626777062339511357	16385	KANBAN	kanban	project	f	f	2025-10-22 07:35:38.252	\N	f
1626777066466706529	1626777062339511357	81921	PROJECT	kanban	project	f	f	2025-10-22 07:35:38.35	\N	f
1626840256055608462	1626840254537270411	1	EXECUTION	kanban	project	f	f	2025-10-22 09:41:11.136	\N	f
1626840257347454105	1626840254537270411	8193	META	kanban	project	f	f	2025-10-22 09:41:11.291	\N	f
1626840258337309860	1626840254537270411	16385	KANBAN	kanban	project	f	f	2025-10-22 09:41:11.409	\N	f
1626840259452994735	1626840254537270411	81921	PROJECT	kanban	project	f	f	2025-10-22 09:41:11.541	\N	f
1626853199073772766	1626853198436238555	1	EXECUTION	kanban	project	f	f	2025-10-22 10:06:54.065	\N	f
1626853200231400681	1626853198436238555	8193	META	kanban	project	f	f	2025-10-22 10:06:54.203	\N	f
1626853201078650100	1626853198436238555	16385	KANBAN	kanban	project	f	f	2025-10-22 10:06:54.304	\N	f
1626853202202723583	1626853198436238555	81921	PROJECT	kanban	project	f	f	2025-10-22 10:06:54.438	\N	f
1626893017539413302	1626893016977376563	1	EXECUTION	kanban	project	f	f	2025-10-22 11:26:00.796	\N	f
1626893018478937409	1626893016977376563	8193	META	kanban	project	f	f	2025-10-22 11:26:00.908	\N	f
1626893019468793164	1626893016977376563	16385	KANBAN	kanban	project	f	f	2025-10-22 11:26:01.026	\N	f
1626893020223767895	1626893016977376563	81921	PROJECT	kanban	project	f	f	2025-10-22 11:26:01.116	\N	f
1626978047573886343	1626978046776968580	1	EXECUTION	kanban	project	f	f	2025-10-22 14:14:57.165	\N	f
1626978048739902866	1626978046776968580	8193	META	kanban	project	f	f	2025-10-22 14:14:57.305	\N	f
1626978049587152285	1626978046776968580	16385	KANBAN	kanban	project	f	f	2025-10-22 14:14:57.405	\N	f
1626978050509899176	1626978046776968580	81921	PROJECT	kanban	project	f	f	2025-10-22 14:14:57.516	\N	f
1626995069921789397	1626995069301032402	1	EXECUTION	kanban	project	f	f	2025-10-22 14:48:46.388	\N	f
1626995071297521120	1626995069301032402	8193	META	kanban	project	f	f	2025-10-22 14:48:46.551	\N	f
1626995072127993323	1626995069301032402	16385	KANBAN	kanban	project	f	f	2025-10-22 14:48:46.651	\N	f
1626995072882968054	1626995069301032402	81921	PROJECT	kanban	project	f	f	2025-10-22 14:48:46.741	\N	f
1627092979598493220	1627092978960959009	1	EXECUTION	kanban	project	f	f	2025-10-22 18:03:18.13	\N	f
1627092980756121135	1627092978960959009	8193	META	kanban	project	f	f	2025-10-22 18:03:18.269	\N	f
1627092981636924986	1627092978960959009	16385	KANBAN	kanban	project	f	f	2025-10-22 18:03:18.374	\N	f
1627092982618392133	1627092978960959009	81921	PROJECT	kanban	project	f	f	2025-10-22 18:03:18.491	\N	f
1636194980651337512	1636194979720202021	65536	MLX Inference Analysis - EXECUTION	kanban	project	f	f	2025-11-04 07:27:21.209	\N	f
1636362671643166512	1636362670510704429	65536	mvp_test - EXECUTION	kanban	project	f	f	2025-11-04 13:00:31.534	\N	f
1636366528658016056	1636366527785600821	65536	mvp_test - EXECUTION	kanban	project	f	f	2025-11-04 13:08:11.326	\N	f
1636618543556462424	1636618542491109205	65536	mvp_test - EXECUTION	kanban	project	f	f	2025-11-04 21:28:53.843	\N	f
1636621052396177248	1636621051465041757	65536	mvp_test - EXECUTION	kanban	project	f	f	2025-11-04 21:33:52.92	\N	f
1636622653269739368	1636622652372158309	65536	mvp_test - EXECUTION	kanban	project	f	f	2025-11-04 21:37:03.759	\N	f
1636624465494280050	1636624464672196463	65536	mvp_test - EXECUTION	kanban	project	f	f	2025-11-04 21:40:39.793	\N	f
1636626842364413846	1636626841559107475	65536	mvp_test - EXECUTION	kanban	project	f	f	2025-11-04 21:45:23.138	\N	f
1636629173223032742	1636629172367394723	65536	mvp_test - EXECUTION	kanban	project	f	f	2025-11-04 21:50:00.998	\N	f
1636635392016910282	1636635391161272263	65536	mvp_test - EXECUTION	kanban	project	f	f	2025-11-04 22:02:22.336	\N	f
1636639387921942510	1636639387116636139	65536	mvp_test - EXECUTION	kanban	project	f	f	2025-11-04 22:10:18.685	\N	f
1637150314186408983	1637150313783755797	16384	Development Board	kanban	project	f	f	2025-11-05 15:05:25.834	\N	f
1637150620622259229	1637150620479652891	16384	Development Board	kanban	project	f	f	2025-11-05 15:06:02.372	\N	f
1637150844338045993	1637150844245771303	16384	Development Board	kanban	project	f	f	2025-11-05 15:06:29.041	\N	f
1639163934877418589	1639163934625760347	1	Development Board	kanban	project	f	f	2025-11-08 09:46:08.134	\N	f
\.


--
-- Data for Name: board_membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board_membership (id, project_id, board_id, user_id, role, can_comment, created_at, updated_at) FROM stdin;
1573201068882396923	1573201067548608248	1573201068874008314	1560328737491256322	editor	\N	2025-08-09 09:29:41.742	\N
1573201069377324804	1573201067548608248	1573201068874008314	1560328737491256323	editor	\N	2025-08-09 09:29:41.801	\N
1573201069486376709	1573201067548608248	1573201068874008314	1560328737491256324	viewer	t	2025-08-09 09:29:41.814	\N
1573201069553485574	1573201067548608248	1573201068874008314	1560328737491256325	viewer	t	2025-08-09 09:29:41.822	\N
1573201069721257736	1573201067548608248	1573201069712869127	1560328737491256322	editor	\N	2025-08-09 09:29:41.842	\N
1573201070140688145	1573201067548608248	1573201069712869127	1560328737491256324	editor	\N	2025-08-09 09:29:41.891	\N
1573201070191019794	1573201067548608248	1573201069712869127	1560328737491256323	viewer	t	2025-08-09 09:29:41.897	\N
1573201070241351443	1573201067548608248	1573201069712869127	1560328737491256325	viewer	t	2025-08-09 09:29:41.904	\N
1573201070316848917	1573201067548608248	1573201070316848916	1560328737491256322	editor	\N	2025-08-09 09:29:41.913	\N
1573201070711113502	1573201067548608248	1573201070316848916	1560328737491256325	editor	\N	2025-08-09 09:29:41.96	\N
1573201070761445151	1573201067548608248	1573201070316848916	1560328737491256323	viewer	t	2025-08-09 09:29:41.965	\N
1573201070820165408	1573201067548608248	1573201070316848916	1560328737491256324	viewer	t	2025-08-09 09:29:41.972	\N
1626139470510163756	1626139469679691560	1626139470484997931	1560328737491256322	editor	\N	2025-10-21 10:28:50.989	\N
1626139471911061303	1626139469679691560	1626139471911061302	1560328737491256322	editor	\N	2025-10-21 10:28:51.157	\N
1626139472783476546	1626139469679691560	1626139472775087937	1560328737491256322	editor	\N	2025-10-21 10:28:51.261	\N
1626139473597171533	1626139469679691560	1626139473588782924	1560328737491256322	editor	\N	2025-10-21 10:28:51.358	\N
1626139474863851352	1626139469679691560	1626139470484997931	1560328737491256323	editor	\N	2025-10-21 10:28:51.509	\N
1626139474922571609	1626139469679691560	1626139470484997931	1560328737491256324	viewer	t	2025-10-21 10:28:51.516	\N
1626139474981291866	1626139469679691560	1626139470484997931	1560328737491256325	viewer	t	2025-10-21 10:28:51.522	\N
1626139475073566556	1626139469679691560	1626139471911061302	1560328737491256325	editor	\N	2025-10-21 10:28:51.533	\N
1626139475115509597	1626139469679691560	1626139471911061302	1560328737491256323	viewer	t	2025-10-21 10:28:51.539	\N
1626139475165841246	1626139469679691560	1626139471911061302	1560328737491256324	viewer	t	2025-10-21 10:28:51.545	\N
1626139475266504544	1626139469679691560	1626139472775087937	1560328737491256324	editor	\N	2025-10-21 10:28:51.557	\N
1626139475308447585	1626139469679691560	1626139472775087937	1560328737491256323	viewer	t	2025-10-21 10:28:51.562	\N
1626139475350390626	1626139469679691560	1626139472775087937	1560328737491256325	viewer	t	2025-10-21 10:28:51.567	\N
1626139475459442532	1626139469679691560	1626139473588782924	1560328737491256323	viewer	t	2025-10-21 10:28:51.579	\N
1626139475602048869	1626139469679691560	1626139473588782924	1560328737491256324	viewer	t	2025-10-21 10:28:51.597	\N
1626139475660769126	1626139469679691560	1626139473588782924	1560328737491256325	viewer	t	2025-10-21 10:28:51.603	\N
1626143868279850887	1626143867390658435	1626143868271462278	1560328737491256322	editor	\N	2025-10-21 10:37:35.244	\N
1626143869236152210	1626143867390658435	1626143869236152209	1560328737491256322	editor	\N	2025-10-21 10:37:35.359	\N
1626143870267951005	1626143867390658435	1626143870267951004	1560328737491256322	editor	\N	2025-10-21 10:37:35.482	\N
1626143871081645992	1626143867390658435	1626143871081645991	1560328737491256322	editor	\N	2025-10-21 10:37:35.579	\N
1626143873455622067	1626143867390658435	1626143868271462278	1560328737491256323	editor	\N	2025-10-21 10:37:35.862	\N
1626143873623394228	1626143867390658435	1626143868271462278	1560328737491256324	viewer	t	2025-10-21 10:37:35.881	\N
1626143873749223349	1626143867390658435	1626143868271462278	1560328737491256325	viewer	t	2025-10-21 10:37:35.896	\N
1626143873816332214	1626143867390658435	1626143868271462278	1626139592824457076	viewer	t	2025-10-21 10:37:35.905	\N
1626143873942161336	1626143867390658435	1626143869236152209	1560328737491256325	editor	\N	2025-10-21 10:37:35.92	\N
1626143874017658809	1626143867390658435	1626143869236152209	1560328737491256323	viewer	t	2025-10-21 10:37:35.928	\N
1626143874084767674	1626143867390658435	1626143869236152209	1560328737491256324	viewer	t	2025-10-21 10:37:35.937	\N
1626143874135099323	1626143867390658435	1626143869236152209	1626139592824457076	viewer	t	2025-10-21 10:37:35.943	\N
1626143874235762621	1626143867390658435	1626143870267951004	1560328737491256324	editor	\N	2025-10-21 10:37:35.955	\N
1626143874294482878	1626143867390658435	1626143870267951004	1560328737491256323	viewer	t	2025-10-21 10:37:35.962	\N
1626143874361591743	1626143867390658435	1626143870267951004	1560328737491256325	viewer	t	2025-10-21 10:37:35.97	\N
1626143874470643648	1626143867390658435	1626143870267951004	1626139592824457076	viewer	t	2025-10-21 10:37:35.982	\N
1626143874705524674	1626143867390658435	1626143871081645991	1626139592824457076	editor	\N	2025-10-21 10:37:36.011	\N
1626143874814576579	1626143867390658435	1626143871081645991	1560328737491256323	viewer	t	2025-10-21 10:37:36.023	\N
1626143874890074052	1626143867390658435	1626143871081645991	1560328737491256324	viewer	t	2025-10-21 10:37:36.033	\N
1626143874957182917	1626143867390658435	1626143871081645991	1560328737491256325	viewer	t	2025-10-21 10:37:36.041	\N
1626762337488734178	1626762336809256926	1626762337480345569	1560328737491256322	editor	\N	2025-10-22 07:06:22.519	\N
1626762338822522861	1626762336809256926	1626762338814134252	1560328737491256322	editor	\N	2025-10-22 07:06:22.678	\N
1626762339711715320	1626762336809256926	1626762339703326711	1560328737491256322	editor	\N	2025-10-22 07:06:22.785	\N
1626762340533797891	1626762336809256926	1626762340525409282	1560328737491256322	editor	\N	2025-10-22 07:06:22.883	\N
1626762342379291662	1626762336809256926	1626762337480345569	1560328737491256323	editor	\N	2025-10-22 07:06:23.102	\N
1626762342429623311	1626762336809256926	1626762337480345569	1560328737491256324	viewer	t	2025-10-22 07:06:23.109	\N
1626762342479954960	1626762336809256926	1626762337480345569	1560328737491256325	viewer	t	2025-10-22 07:06:23.115	\N
1626762342530286609	1626762336809256926	1626762337480345569	1626139592824457076	viewer	t	2025-10-22 07:06:23.121	\N
1626762342614172691	1626762336809256926	1626762338814134252	1560328737491256325	editor	\N	2025-10-22 07:06:23.131	\N
1626762342672892948	1626762336809256926	1626762338814134252	1560328737491256323	viewer	t	2025-10-22 07:06:23.137	\N
1626762342723224597	1626762336809256926	1626762338814134252	1560328737491256324	viewer	t	2025-10-22 07:06:23.143	\N
1626762342765167638	1626762336809256926	1626762338814134252	1626139592824457076	viewer	t	2025-10-22 07:06:23.148	\N
1626762342840665112	1626762336809256926	1626762339703326711	1560328737491256324	editor	\N	2025-10-22 07:06:23.158	\N
1626762342890996761	1626762336809256926	1626762339703326711	1560328737491256323	viewer	t	2025-10-22 07:06:23.164	\N
1626762342932939802	1626762336809256926	1626762339703326711	1560328737491256325	viewer	t	2025-10-22 07:06:23.169	\N
1626762342974882843	1626762336809256926	1626762339703326711	1626139592824457076	viewer	t	2025-10-22 07:06:23.174	\N
1626762343050380317	1626762336809256926	1626762340525409282	1626139592824457076	editor	\N	2025-10-22 07:06:23.183	\N
1626762343117489182	1626762336809256926	1626762340525409282	1560328737491256323	viewer	t	2025-10-22 07:06:23.191	\N
1626762343209763871	1626762336809256926	1626762340525409282	1560328737491256324	viewer	t	2025-10-22 07:06:23.201	\N
1626762343251706912	1626762336809256926	1626762340525409282	1560328737491256325	viewer	t	2025-10-22 07:06:23.207	\N
1626777062968656961	1626777062339511357	1626777062960268352	1560328737491256322	editor	\N	2025-10-22 07:35:37.934	\N
1626777064243725388	1626777062339511357	1626777064243725387	1560328737491256322	editor	\N	2025-10-22 07:35:38.086	\N
1626777065636234327	1626777062339511357	1626777065636234326	1560328737491256322	editor	\N	2025-10-22 07:35:38.252	\N
1626777066466706530	1626777062339511357	1626777066466706529	1560328737491256322	editor	\N	2025-10-22 07:35:38.351	\N
1626777067750163565	1626777062339511357	1626777062960268352	1560328737491256323	editor	\N	2025-10-22 07:35:38.503	\N
1626777067800495214	1626777062339511357	1626777062960268352	1560328737491256324	viewer	t	2025-10-22 07:35:38.51	\N
1626777067842438255	1626777062339511357	1626777062960268352	1560328737491256325	viewer	t	2025-10-22 07:35:38.515	\N
1626777067892769904	1626777062339511357	1626777062960268352	1626139592824457076	viewer	t	2025-10-22 07:35:38.521	\N
1626777068001821810	1626777062339511357	1626777064243725387	1560328737491256325	editor	\N	2025-10-22 07:35:38.534	\N
1626777068094096499	1626777062339511357	1626777064243725387	1560328737491256323	viewer	t	2025-10-22 07:35:38.545	\N
1626777068245091444	1626777062339511357	1626777064243725387	1560328737491256324	viewer	t	2025-10-22 07:35:38.563	\N
1626777068295423093	1626777062339511357	1626777064243725387	1626139592824457076	viewer	t	2025-10-22 07:35:38.569	\N
1626777068446418039	1626777062339511357	1626777065636234326	1560328737491256324	editor	\N	2025-10-22 07:35:38.587	\N
1626777068496749688	1626777062339511357	1626777065636234326	1560328737491256323	viewer	t	2025-10-22 07:35:38.592	\N
1626777068538692729	1626777062339511357	1626777065636234326	1560328737491256325	viewer	t	2025-10-22 07:35:38.598	\N
1626777068580635770	1626777062339511357	1626777065636234326	1626139592824457076	viewer	t	2025-10-22 07:35:38.603	\N
1626777068698076284	1626777062339511357	1626777066466706529	1626139592824457076	editor	\N	2025-10-22 07:35:38.617	\N
1626777068756796541	1626777062339511357	1626777066466706529	1560328737491256323	viewer	t	2025-10-22 07:35:38.623	\N
1626777068790350974	1626777062339511357	1626777066466706529	1560328737491256324	viewer	t	2025-10-22 07:35:38.628	\N
1626777068857459839	1626777062339511357	1626777066466706529	1560328737491256325	viewer	t	2025-10-22 07:35:38.636	\N
1626840256063997071	1626840254537270411	1626840256055608462	1560328737491256322	editor	\N	2025-10-22 09:41:11.138	\N
1626840257355842714	1626840254537270411	1626840257347454105	1560328737491256322	editor	\N	2025-10-22 09:41:11.291	\N
1626840258345698469	1626840254537270411	1626840258337309860	1560328737491256322	editor	\N	2025-10-22 09:41:11.409	\N
1626840259452994736	1626840254537270411	1626840259452994735	1560328737491256322	editor	\N	2025-10-22 09:41:11.542	\N
1626840260803560635	1626840254537270411	1626840256055608462	1560328737491256323	editor	\N	2025-10-22 09:41:11.703	\N
1626840260853892284	1626840254537270411	1626840256055608462	1560328737491256324	viewer	t	2025-10-22 09:41:11.709	\N
1626840260921001149	1626840254537270411	1626840256055608462	1560328737491256325	viewer	t	2025-10-22 09:41:11.717	\N
1626840260979721406	1626840254537270411	1626840256055608462	1626139592824457076	viewer	t	2025-10-22 09:41:11.724	\N
1626840261147493568	1626840254537270411	1626840257347454105	1560328737491256325	editor	\N	2025-10-22 09:41:11.743	\N
1626840261206213825	1626840254537270411	1626840257347454105	1560328737491256323	viewer	t	2025-10-22 09:41:11.751	\N
1626840261264934082	1626840254537270411	1626840257347454105	1560328737491256324	viewer	t	2025-10-22 09:41:11.758	\N
1626840261323654339	1626840254537270411	1626840257347454105	1626139592824457076	viewer	t	2025-10-22 09:41:11.764	\N
1626840261432706245	1626840254537270411	1626840258337309860	1560328737491256324	editor	\N	2025-10-22 09:41:11.778	\N
1626840261491426502	1626840254537270411	1626840258337309860	1560328737491256323	viewer	t	2025-10-22 09:41:11.785	\N
1626840261541758151	1626840254537270411	1626840258337309860	1560328737491256325	viewer	t	2025-10-22 09:41:11.791	\N
1626840261608867016	1626840254537270411	1626840258337309860	1626139592824457076	viewer	t	2025-10-22 09:41:11.798	\N
1626840262472893642	1626840254537270411	1626840259452994735	1626139592824457076	editor	\N	2025-10-22 09:41:11.902	\N
1626840262540002507	1626840254537270411	1626840259452994735	1560328737491256323	viewer	t	2025-10-22 09:41:11.91	\N
1626840262598722764	1626840254537270411	1626840259452994735	1560328737491256324	viewer	t	2025-10-22 09:41:11.917	\N
1626840262649054413	1626840254537270411	1626840259452994735	1560328737491256325	viewer	t	2025-10-22 09:41:11.923	\N
1626853199082161375	1626853198436238555	1626853199073772766	1560328737491256322	editor	\N	2025-10-22 10:06:54.066	\N
1626853200239789290	1626853198436238555	1626853200231400681	1560328737491256322	editor	\N	2025-10-22 10:06:54.204	\N
1626853201087038709	1626853198436238555	1626853201078650100	1560328737491256322	editor	\N	2025-10-22 10:06:54.304	\N
1626853202202723584	1626853198436238555	1626853202202723583	1560328737491256322	editor	\N	2025-10-22 10:06:54.438	\N
1626853203351962891	1626853198436238555	1626853199073772766	1560328737491256323	editor	\N	2025-10-22 10:06:54.574	\N
1626853203402294540	1626853198436238555	1626853199073772766	1560328737491256324	viewer	t	2025-10-22 10:06:54.581	\N
1626853203452626189	1626853198436238555	1626853199073772766	1560328737491256325	viewer	t	2025-10-22 10:06:54.587	\N
1626853203511346446	1626853198436238555	1626853199073772766	1626139592824457076	viewer	t	2025-10-22 10:06:54.593	\N
1626853203637175568	1626853198436238555	1626853200231400681	1560328737491256325	editor	\N	2025-10-22 10:06:54.609	\N
1626853203695895825	1626853198436238555	1626853200231400681	1560328737491256323	viewer	t	2025-10-22 10:06:54.616	\N
1626853203737838866	1626853198436238555	1626853200231400681	1560328737491256324	viewer	t	2025-10-22 10:06:54.621	\N
1626853203779781907	1626853198436238555	1626853200231400681	1626139592824457076	viewer	t	2025-10-22 10:06:54.626	\N
1626853203863667989	1626853198436238555	1626853201078650100	1560328737491256324	editor	\N	2025-10-22 10:06:54.635	\N
1626853203913999638	1626853198436238555	1626853201078650100	1560328737491256323	viewer	t	2025-10-22 10:06:54.642	\N
1626853203972719895	1626853198436238555	1626853201078650100	1560328737491256325	viewer	t	2025-10-22 10:06:54.648	\N
1626853204023051544	1626853198436238555	1626853201078650100	1626139592824457076	viewer	t	2025-10-22 10:06:54.654	\N
1626853204123714842	1626853198436238555	1626853202202723583	1626139592824457076	editor	\N	2025-10-22 10:06:54.667	\N
1626853204182435099	1626853198436238555	1626853202202723583	1560328737491256323	viewer	t	2025-10-22 10:06:54.674	\N
1626853204241155356	1626853198436238555	1626853202202723583	1560328737491256324	viewer	t	2025-10-22 10:06:54.681	\N
1626853204308264221	1626853198436238555	1626853202202723583	1560328737491256325	viewer	t	2025-10-22 10:06:54.688	\N
1626893017547801911	1626893016977376563	1626893017539413302	1560328737491256322	editor	\N	2025-10-22 11:26:00.797	\N
1626893018478937410	1626893016977376563	1626893018478937409	1560328737491256322	editor	\N	2025-10-22 11:26:00.908	\N
1626893019468793165	1626893016977376563	1626893019468793164	1560328737491256322	editor	\N	2025-10-22 11:26:01.026	\N
1626893020232156504	1626893016977376563	1626893020223767895	1560328737491256322	editor	\N	2025-10-22 11:26:01.117	\N
1626893021465281891	1626893016977376563	1626893017539413302	1560328737491256323	editor	\N	2025-10-22 11:26:01.264	\N
1626893021515613540	1626893016977376563	1626893017539413302	1560328737491256324	viewer	t	2025-10-22 11:26:01.27	\N
1626893021574333797	1626893016977376563	1626893017539413302	1560328737491256325	viewer	t	2025-10-22 11:26:01.277	\N
1626893021624665446	1626893016977376563	1626893017539413302	1626139592824457076	viewer	t	2025-10-22 11:26:01.283	\N
1626893021716940136	1626893016977376563	1626893018478937409	1560328737491256325	editor	\N	2025-10-22 11:26:01.293	\N
1626893021792437609	1626893016977376563	1626893018478937409	1560328737491256323	viewer	t	2025-10-22 11:26:01.303	\N
1626893021851157866	1626893016977376563	1626893018478937409	1560328737491256324	viewer	t	2025-10-22 11:26:01.31	\N
1626893021893100907	1626893016977376563	1626893018478937409	1626139592824457076	viewer	t	2025-10-22 11:26:01.315	\N
1626893021985375597	1626893016977376563	1626893019468793164	1560328737491256324	editor	\N	2025-10-22 11:26:01.326	\N
1626893022027318638	1626893016977376563	1626893019468793164	1560328737491256323	viewer	t	2025-10-22 11:26:01.331	\N
1626893022069261679	1626893016977376563	1626893019468793164	1560328737491256325	viewer	t	2025-10-22 11:26:01.336	\N
1626893022111204720	1626893016977376563	1626893019468793164	1626139592824457076	viewer	t	2025-10-22 11:26:01.341	\N
1626893022237033842	1626893016977376563	1626893020223767895	1626139592824457076	editor	\N	2025-10-22 11:26:01.355	\N
1626893022304142707	1626893016977376563	1626893020223767895	1560328737491256323	viewer	t	2025-10-22 11:26:01.363	\N
1626893022354474356	1626893016977376563	1626893020223767895	1560328737491256324	viewer	t	2025-10-22 11:26:01.37	\N
1626893022404806005	1626893016977376563	1626893020223767895	1560328737491256325	viewer	t	2025-10-22 11:26:01.376	\N
1626978047607440776	1626978046776968580	1626978047573886343	1560328737491256322	editor	\N	2025-10-22 14:14:57.167	\N
1626978048748291475	1626978046776968580	1626978048739902866	1560328737491256322	editor	\N	2025-10-22 14:14:57.305	\N
1626978049587152286	1626978046776968580	1626978049587152285	1560328737491256322	editor	\N	2025-10-22 14:14:57.406	\N
1626978050518287785	1626978046776968580	1626978050509899176	1560328737491256322	editor	\N	2025-10-22 14:14:57.517	\N
1626978051910796724	1626978046776968580	1626978047573886343	1560328737491256323	editor	\N	2025-10-22 14:14:57.683	\N
1626978052003071413	1626978046776968580	1626978047573886343	1560328737491256324	viewer	t	2025-10-22 14:14:57.694	\N
1626978052061791670	1626978046776968580	1626978047573886343	1560328737491256325	viewer	t	2025-10-22 14:14:57.701	\N
1626978052112123319	1626978046776968580	1626978047573886343	1626139592824457076	viewer	t	2025-10-22 14:14:57.707	\N
1626978052221175225	1626978046776968580	1626978048739902866	1560328737491256325	editor	\N	2025-10-22 14:14:57.72	\N
1626978052279895482	1626978046776968580	1626978048739902866	1560328737491256323	viewer	t	2025-10-22 14:14:57.727	\N
1626978052330227131	1626978046776968580	1626978048739902866	1560328737491256324	viewer	t	2025-10-22 14:14:57.733	\N
1626978052388947388	1626978046776968580	1626978048739902866	1626139592824457076	viewer	t	2025-10-22 14:14:57.74	\N
1626978052506387902	1626978046776968580	1626978049587152285	1560328737491256324	editor	\N	2025-10-22 14:14:57.754	\N
1626978052565108159	1626978046776968580	1626978049587152285	1560328737491256323	viewer	t	2025-10-22 14:14:57.761	\N
1626978052607051200	1626978046776968580	1626978049587152285	1560328737491256325	viewer	t	2025-10-22 14:14:57.766	\N
1626978052648994241	1626978046776968580	1626978049587152285	1626139592824457076	viewer	t	2025-10-22 14:14:57.77	\N
1626978052724491715	1626978046776968580	1626978050509899176	1626139592824457076	editor	\N	2025-10-22 14:14:57.78	\N
1626978052783211972	1626978046776968580	1626978050509899176	1560328737491256323	viewer	t	2025-10-22 14:14:57.786	\N
1626978052825155013	1626978046776968580	1626978050509899176	1560328737491256324	viewer	t	2025-10-22 14:14:57.792	\N
1626978052867098054	1626978046776968580	1626978050509899176	1560328737491256325	viewer	t	2025-10-22 14:14:57.797	\N
1626995069930178006	1626995069301032402	1626995069921789397	1560328737491256322	editor	\N	2025-10-22 14:48:46.389	\N
1626995071297521121	1626995069301032402	1626995071297521120	1560328737491256322	editor	\N	2025-10-22 14:48:46.552	\N
1626995072136381932	1626995069301032402	1626995072127993323	1560328737491256322	editor	\N	2025-10-22 14:48:46.652	\N
1626995072882968055	1626995069301032402	1626995072882968054	1560328737491256322	editor	\N	2025-10-22 14:48:46.741	\N
1626995074124482050	1626995069301032402	1626995069921789397	1560328737491256323	editor	\N	2025-10-22 14:48:46.889	\N
1626995074166425091	1626995069301032402	1626995069921789397	1560328737491256324	viewer	t	2025-10-22 14:48:46.894	\N
1626995074225145348	1626995069301032402	1626995069921789397	1560328737491256325	viewer	t	2025-10-22 14:48:46.9	\N
1626995074283865605	1626995069301032402	1626995069921789397	1626139592824457076	viewer	t	2025-10-22 14:48:46.908	\N
1626995074401306119	1626995069301032402	1626995071297521120	1560328737491256325	editor	\N	2025-10-22 14:48:46.921	\N
1626995074451637768	1626995069301032402	1626995071297521120	1560328737491256323	viewer	t	2025-10-22 14:48:46.928	\N
1626995074493580809	1626995069301032402	1626995071297521120	1560328737491256324	viewer	t	2025-10-22 14:48:46.933	\N
1626995074527135242	1626995069301032402	1626995071297521120	1626139592824457076	viewer	t	2025-10-22 14:48:46.937	\N
1626995074611021324	1626995069301032402	1626995072127993323	1560328737491256324	editor	\N	2025-10-22 14:48:46.947	\N
1626995074644575757	1626995069301032402	1626995072127993323	1560328737491256323	viewer	t	2025-10-22 14:48:46.951	\N
1626995074678130190	1626995069301032402	1626995072127993323	1560328737491256325	viewer	t	2025-10-22 14:48:46.955	\N
1626995074728461839	1626995069301032402	1626995072127993323	1626139592824457076	viewer	t	2025-10-22 14:48:46.96	\N
1626995074845902353	1626995069301032402	1626995072882968054	1626139592824457076	editor	\N	2025-10-22 14:48:46.974	\N
1626995074913011218	1626995069301032402	1626995072882968054	1560328737491256323	viewer	t	2025-10-22 14:48:46.983	\N
1626995074971731475	1626995069301032402	1626995072882968054	1560328737491256324	viewer	t	2025-10-22 14:48:46.99	\N
1626995075013674516	1626995069301032402	1626995072882968054	1560328737491256325	viewer	t	2025-10-22 14:48:46.995	\N
1627092979606881829	1627092978960959009	1627092979598493220	1560328737491256322	editor	\N	2025-10-22 18:03:18.132	\N
1627092980756121136	1627092978960959009	1627092980756121135	1560328737491256322	editor	\N	2025-10-22 18:03:18.269	\N
1627092981645313595	1627092978960959009	1627092981636924986	1560328737491256322	editor	\N	2025-10-22 18:03:18.375	\N
1627092982618392134	1627092978960959009	1627092982618392133	1560328737491256322	editor	\N	2025-10-22 18:03:18.491	\N
1627092984061232721	1627092978960959009	1627092979598493220	1560328737491256323	editor	\N	2025-10-22 18:03:18.662	\N
1627092984128341586	1627092978960959009	1627092979598493220	1560328737491256324	viewer	t	2025-10-22 18:03:18.67	\N
1627092984178673235	1627092978960959009	1627092979598493220	1560328737491256325	viewer	t	2025-10-22 18:03:18.677	\N
1627092984245782100	1627092978960959009	1627092979598493220	1626139592824457076	viewer	t	2025-10-22 18:03:18.685	\N
1627092984354834006	1627092978960959009	1627092980756121135	1560328737491256325	editor	\N	2025-10-22 18:03:18.698	\N
1627092984413554263	1627092978960959009	1627092980756121135	1560328737491256323	viewer	t	2025-10-22 18:03:18.705	\N
1627092984463885912	1627092978960959009	1627092980756121135	1560328737491256324	viewer	t	2025-10-22 18:03:18.711	\N
1627092984522606169	1627092978960959009	1627092980756121135	1626139592824457076	viewer	t	2025-10-22 18:03:18.718	\N
1627092984623269467	1627092978960959009	1627092981636924986	1560328737491256324	editor	\N	2025-10-22 18:03:18.73	\N
1627092984681989724	1627092978960959009	1627092981636924986	1560328737491256323	viewer	t	2025-10-22 18:03:18.736	\N
1627092984732321373	1627092978960959009	1627092981636924986	1560328737491256325	viewer	t	2025-10-22 18:03:18.743	\N
1627092984799430238	1627092978960959009	1627092981636924986	1626139592824457076	viewer	t	2025-10-22 18:03:18.75	\N
1627092984900093536	1627092978960959009	1627092982618392133	1626139592824457076	editor	\N	2025-10-22 18:03:18.763	\N
1627092984958813793	1627092978960959009	1627092982618392133	1560328737491256323	viewer	t	2025-10-22 18:03:18.769	\N
1627092985017534050	1627092978960959009	1627092982618392133	1560328737491256324	viewer	t	2025-10-22 18:03:18.777	\N
1627092985076254307	1627092978960959009	1627092982618392133	1560328737491256325	viewer	t	2025-10-22 18:03:18.784	\N
1636194980668114729	1636194979720202021	1636194980651337512	1560328737491256322	editor	\N	2025-11-04 07:27:21.211	\N
1636362671651555121	1636362670510704429	1636362671643166512	1560328737491256322	editor	\N	2025-11-04 13:00:31.535	\N
1636366528666404665	1636366527785600821	1636366528658016056	1560328737491256322	editor	\N	2025-11-04 13:08:11.326	\N
1636618543581628249	1636618542491109205	1636618543556462424	1560328737491256322	editor	\N	2025-11-04 21:28:53.845	\N
1636621052404565857	1636621051465041757	1636621052396177248	1560328737491256322	editor	\N	2025-11-04 21:33:52.921	\N
1636622653278127977	1636622652372158309	1636622653269739368	1560328737491256322	editor	\N	2025-11-04 21:37:03.76	\N
1636624465502668659	1636624464672196463	1636624465494280050	1560328737491256322	editor	\N	2025-11-04 21:40:39.794	\N
1636626842372802455	1636626841559107475	1636626842364413846	1560328737491256322	editor	\N	2025-11-04 21:45:23.139	\N
1636629173231421351	1636629172367394723	1636629173223032742	1560328737491256322	editor	\N	2025-11-04 21:50:00.999	\N
1636635392025298891	1636635391161272263	1636635392016910282	1560328737491256322	editor	\N	2025-11-04 22:02:22.337	\N
1636639387930331119	1636639387116636139	1636639387921942510	1560328737491256322	editor	\N	2025-11-04 22:10:18.686	\N
1637150314236740632	1637150313783755797	1637150314186408983	1560328737491256322	editor	\N	2025-11-05 15:05:25.846	\N
1637150620630647838	1637150620479652891	1637150620622259229	1560328737491256322	editor	\N	2025-11-05 15:06:02.373	\N
1637150844346434602	1637150844245771303	1637150844338045993	1560328737491256322	editor	\N	2025-11-05 15:06:29.041	\N
1639163934885807198	1639163934625760347	1639163934877418589	1560328737491256322	editor	\N	2025-11-08 09:46:08.134	\N
\.


--
-- Data for Name: board_subscription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board_subscription (id, board_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card (id, board_id, list_id, creator_user_id, prev_list_id, cover_attachment_id, type, "position", name, description, due_date, stopwatch, created_at, updated_at, list_changed_at, comments_total, is_closed, is_due_completed) FROM stdin;
1626139517830301547	1626139471911061302	1626139471978170170	1560328737491256322	\N	\N	project	2	Load Quality Requirements	Load requirements for: code_quality\n\nThis card will select and load quality requirements.	\N	\N	2025-10-21 10:28:56.631	\N	2025-10-21 10:28:56.63	0	f	\N
1626139518014850925	1626139471911061302	1626139471978170170	1560328737491256322	\N	\N	project	3	Extract Repo-Specific Principles	Extract principles from repository analysis.\n\nThis card will analyze the codebase and extract project-specific principles.	\N	\N	2025-10-21 10:28:56.652	\N	2025-10-21 10:28:56.652	0	f	\N
1626139518182623087	1626139471911061302	1626139471978170170	1560328737491256322	\N	\N	project	4	Load Prompt Templates	Prepare prompt templates for project type: CODE_ANALYSIS\n\nThis card will load and prepare prompt templates.	\N	\N	2025-10-21 10:28:56.673	\N	2025-10-21 10:28:56.672	0	f	\N
1626139518316840817	1626139471911061302	1626139471978170170	1560328737491256322	\N	\N	project	5	Validate META Asset Completeness	Validate that all META assets are loaded and ready.\n\nDepends on: 4 previous cards	\N	\N	2025-10-21 10:28:56.689	\N	2025-10-21 10:28:56.689	0	f	\N
1626762360079254562	1626762338814134252	1626762339007072242	1560328737491256322	\N	\N	project	1	Load Core Procedures for CODE_ANALYSIS	Load procedures for: code_analysis\n\nThis card will select and load the necessary procedures from procedure_management.	\N	\N	2025-10-22 07:06:25.213	2025-10-22 07:07:35.622	2025-10-22 07:07:10.654	3	f	\N
1626139517612197737	1626139471911061302	1626139472095610684	1560328737491256322	\N	\N	project	1	Load Core Procedures for CODE_ANALYSIS	Load procedures for: code_analysis\n\nThis card will select and load the necessary procedures from procedure_management.	\N	\N	2025-10-21 10:28:56.605	2025-10-21 10:29:18.876	2025-10-21 10:29:11.276	3	f	\N
1626144083934185417	1626143869236152209	1626143869420701589	1560328737491256322	\N	\N	project	2	Load Quality Requirements	Load requirements for: quality_standards, security_requirements, usability_criteria\n\nThis card will select and load quality requirements.	\N	\N	2025-10-21 10:38:00.953	\N	2025-10-21 10:38:00.953	0	f	\N
1626144084093568971	1626143869236152209	1626143869420701589	1560328737491256322	\N	\N	project	3	Load Prompt Templates	Prepare prompt templates for project type: CLASSIFICATION\n\nThis card will load and prepare prompt templates.	\N	\N	2025-10-21 10:38:00.971	\N	2025-10-21 10:38:00.971	0	f	\N
1626144084236175309	1626143869236152209	1626143869420701589	1560328737491256322	\N	\N	project	4	Validate META Asset Completeness	Validate that all META assets are loaded and ready.\n\nDepends on: 3 previous cards	\N	\N	2025-10-21 10:38:00.989	\N	2025-10-21 10:38:00.988	0	f	\N
1626144083716081607	1626143869236152209	1626143869580085143	1560328737491256322	\N	\N	project	1	Load Core Procedures for CLASSIFICATION	Load procedures for: code_review, testing, deployment\n\nThis card will select and load the necessary procedures from procedure_management.	\N	\N	2025-10-21 10:38:00.926	2025-10-21 10:42:29.804	2025-10-21 10:38:59.606	3	f	\N
1626762360297358372	1626762338814134252	1626762338889631728	1560328737491256322	\N	\N	project	2	Load Quality Requirements	Load requirements for: code_quality\n\nThis card will select and load quality requirements.	\N	\N	2025-10-22 07:06:25.238	\N	2025-10-22 07:06:25.238	0	f	\N
1626762360439964710	1626762338814134252	1626762338889631728	1560328737491256322	\N	\N	project	3	Extract Repo-Specific Principles	Extract principles from repository analysis.\n\nThis card will analyze the codebase and extract project-specific principles.	\N	\N	2025-10-22 07:06:25.256	\N	2025-10-22 07:06:25.256	0	f	\N
1626762360582571048	1626762338814134252	1626762338889631728	1560328737491256322	\N	\N	project	4	Load Prompt Templates	Prepare prompt templates for project type: CODE_ANALYSIS\n\nThis card will load and prepare prompt templates.	\N	\N	2025-10-22 07:06:25.273	\N	2025-10-22 07:06:25.273	0	f	\N
1626762360716788778	1626762338814134252	1626762338889631728	1560328737491256322	\N	\N	project	5	Validate META Asset Completeness	Validate that all META assets are loaded and ready.\n\nDepends on: 4 previous cards	\N	\N	2025-10-22 07:06:25.289	\N	2025-10-22 07:06:25.289	0	f	\N
1626777168497345667	1626777064243725387	1626777064319222863	1560328737491256322	\N	\N	project	2	Load Quality Requirements	Load requirements for: quality_standards, security_requirements, compliance_standards\n\nThis card will select and load quality requirements.	\N	\N	2025-10-22 07:35:50.514	\N	2025-10-22 07:35:50.514	0	f	\N
1626777168690283653	1626777064243725387	1626777064319222863	1560328737491256322	\N	\N	project	3	Load Prompt Templates	Prepare prompt templates for project type: ANALYSIS\n\nThis card will load and prepare prompt templates.	\N	\N	2025-10-22 07:35:50.536	\N	2025-10-22 07:35:50.535	0	f	\N
1626777168866444423	1626777064243725387	1626777064319222863	1560328737491256322	\N	\N	project	4	Validate META Asset Completeness	Validate that all META assets are loaded and ready.\n\nDepends on: 3 previous cards	\N	\N	2025-10-22 07:35:50.558	\N	2025-10-22 07:35:50.558	0	f	\N
1626777168279241857	1626777064243725387	1626777064369554512	1560328737491256322	\N	\N	project	1	Load Core Procedures for ANALYSIS	Load procedures for: architecture_review, requirements_gathering, risk_assessment\n\nThis card will select and load the necessary procedures from procedure_management.	\N	\N	2025-10-22 07:35:50.487	2025-10-22 07:35:50.572	2025-10-22 07:35:50.571	0	f	\N
1626840782256211153	1626840257347454105	1626840257431340189	1560328737491256322	\N	\N	project	2	Load Quality Requirements	Load requirements for: code_quality\n\nThis card will select and load quality requirements.	\N	\N	2025-10-22 09:42:13.864	\N	2025-10-22 09:42:13.864	0	f	\N
1626840782407206099	1626840257347454105	1626840257431340189	1560328737491256322	\N	\N	project	3	Extract Repo-Specific Principles	Extract principles from repository analysis.\n\nThis card will analyze the codebase and extract project-specific principles.	\N	\N	2025-10-22 09:42:13.882	\N	2025-10-22 09:42:13.882	0	f	\N
1626840782541423829	1626840257347454105	1626840257431340189	1560328737491256322	\N	\N	project	4	Load Prompt Templates	Prepare prompt templates for project type: CODE_ANALYSIS\n\nThis card will load and prepare prompt templates.	\N	\N	2025-10-22 09:42:13.899	\N	2025-10-22 09:42:13.899	0	f	\N
1626840782684030167	1626840257347454105	1626840257431340189	1560328737491256322	\N	\N	project	5	Validate META Asset Completeness	Validate that all META assets are loaded and ready.\n\nDepends on: 4 previous cards	\N	\N	2025-10-22 09:42:13.915	\N	2025-10-22 09:42:13.915	0	f	\N
1626840781996164303	1626840257347454105	1626840257506837662	1560328737491256322	\N	\N	project	1	Load Core Procedures for CODE_ANALYSIS	Load procedures for: code_analysis\n\nThis card will select and load the necessary procedures from procedure_management.	\N	\N	2025-10-22 09:42:13.834	2025-10-22 09:42:13.931	2025-10-22 09:42:13.926	0	f	\N
1626853522622383393	1626853200231400681	1626853200306898157	1560328737491256322	\N	\N	project	2	Load Quality Requirements	Load requirements for: code_quality\n\nThis card will select and load quality requirements.	\N	\N	2025-10-22 10:07:32.635	\N	2025-10-22 10:07:32.634	0	f	\N
1626853522773378339	1626853200231400681	1626853200306898157	1560328737491256322	\N	\N	project	3	Extract Repo-Specific Principles	Extract principles from repository analysis.\n\nThis card will analyze the codebase and extract project-specific principles.	\N	\N	2025-10-22 10:07:32.653	\N	2025-10-22 10:07:32.652	0	f	\N
1626853522915984677	1626853200231400681	1626853200306898157	1560328737491256322	\N	\N	project	4	Load Prompt Templates	Prepare prompt templates for project type: CODE_ANALYSIS\n\nThis card will load and prepare prompt templates.	\N	\N	2025-10-22 10:07:32.67	\N	2025-10-22 10:07:32.67	0	f	\N
1626853523050202407	1626853200231400681	1626853200306898157	1560328737491256322	\N	\N	project	5	Validate META Asset Completeness	Validate that all META assets are loaded and ready.\n\nDepends on: 4 previous cards	\N	\N	2025-10-22 10:07:32.686	\N	2025-10-22 10:07:32.686	0	f	\N
1626853522404279583	1626853200231400681	1626853200365618414	1560328737491256322	\N	\N	project	1	Load Core Procedures for CODE_ANALYSIS	Load procedures for: code_analysis\n\nThis card will select and load the necessary procedures from procedure_management.	\N	\N	2025-10-22 10:07:32.609	2025-10-22 10:07:32.696	2025-10-22 10:07:32.695	0	f	\N
1626893543035372921	1626893018478937409	1626893018537657669	1560328737491256322	\N	\N	project	2	Load Quality Requirements	Load requirements for: code_quality\n\nThis card will select and load quality requirements.	\N	\N	2025-10-22 11:27:03.439	\N	2025-10-22 11:27:03.439	0	f	\N
1626893543169590651	1626893018478937409	1626893018537657669	1560328737491256322	\N	\N	project	3	Extract Repo-Specific Principles	Extract principles from repository analysis.\n\nThis card will analyze the codebase and extract project-specific principles.	\N	\N	2025-10-22 11:27:03.456	\N	2025-10-22 11:27:03.455	0	f	\N
1626893543597409661	1626893018478937409	1626893018537657669	1560328737491256322	\N	\N	project	4	Load Prompt Templates	Prepare prompt templates for project type: CODE_ANALYSIS\n\nThis card will load and prepare prompt templates.	\N	\N	2025-10-22 11:27:03.507	\N	2025-10-22 11:27:03.506	0	f	\N
1626893543798736255	1626893018478937409	1626893018537657669	1560328737491256322	\N	\N	project	5	Validate META Asset Completeness	Validate that all META assets are loaded and ready.\n\nDepends on: 4 previous cards	\N	\N	2025-10-22 11:27:03.531	\N	2025-10-22 11:27:03.531	0	f	\N
1626893542792103287	1626893018478937409	1626893018579600710	1560328737491256322	\N	\N	project	1	Load Core Procedures for CODE_ANALYSIS	Load procedures for: code_analysis\n\nThis card will select and load the necessary procedures from procedure_management.	\N	\N	2025-10-22 11:27:03.411	2025-10-22 11:27:03.546	2025-10-22 11:27:03.543	0	f	\N
1626978457650988490	1626978048739902866	1626978048832177558	1560328737491256322	\N	\N	project	2	Load Quality Requirements	Load requirements for: quality_standards, security_requirements, compliance_standards, performance_benchmarks\n\nThis card will select and load quality requirements.	\N	\N	2025-10-22 14:15:46.051	\N	2025-10-22 14:15:46.051	0	f	\N
1626978457810372044	1626978048739902866	1626978048832177558	1560328737491256322	\N	\N	project	3	Load Prompt Templates	Prepare prompt templates for project type: ANALYSIS\n\nThis card will load and prepare prompt templates.	\N	\N	2025-10-22 14:15:46.07	\N	2025-10-22 14:15:46.07	0	f	\N
1626978457961366990	1626978048739902866	1626978048832177558	1560328737491256322	\N	\N	project	4	Validate META Asset Completeness	Validate that all META assets are loaded and ready.\n\nDepends on: 3 previous cards	\N	\N	2025-10-22 14:15:46.088	\N	2025-10-22 14:15:46.087	0	f	\N
1626978457390941640	1626978048739902866	1626978048890897815	1560328737491256322	\N	\N	project	1	Load Core Procedures for ANALYSIS	Load procedures for: code_review, testing, deployment, requirements_analysis, architecture_review, design_review\n\nThis card will select and load the necessary procedures from procedure_management.	\N	\N	2025-10-22 14:15:46.02	2025-10-22 14:15:46.104	2025-10-22 14:15:46.102	0	f	\N
1626995678599185944	1626995071297521120	1626995071356241380	1560328737491256322	\N	\N	project	2	Load Quality Requirements	Load requirements for: quality_standards, security_requirements, compliance, documentation_requirements\n\nThis card will select and load quality requirements.	\N	\N	2025-10-22 14:49:58.948	\N	2025-10-22 14:49:58.948	0	f	\N
1626995678725015066	1626995071297521120	1626995071356241380	1560328737491256322	\N	\N	project	3	Load Prompt Templates	Prepare prompt templates for project type: CODE_ANALYSIS\n\nThis card will load and prepare prompt templates.	\N	\N	2025-10-22 14:49:58.963	\N	2025-10-22 14:49:58.963	0	f	\N
1626995678842455580	1626995071297521120	1626995071356241380	1560328737491256322	\N	\N	project	4	Validate META Asset Completeness	Validate that all META assets are loaded and ready.\n\nDepends on: 3 previous cards	\N	\N	2025-10-22 14:49:58.977	\N	2025-10-22 14:49:58.977	0	f	\N
1626995678414636566	1626995071297521120	1626995071406573029	1560328737491256322	\N	\N	project	1	Load Core Procedures for CODE_ANALYSIS	Load procedures for: code_review, testing, documentation\n\nThis card will select and load the necessary procedures from procedure_management.	\N	\N	2025-10-22 14:49:58.926	2025-10-22 14:49:58.99	2025-10-22 14:49:58.987	0	f	\N
1627093221022631527	1627092980756121135	1627092980814841395	1560328737491256322	\N	\N	project	2	Load Quality Requirements	Load requirements for: quality_standards, security_requirements, performance_requirements, compliance_requirements\n\nThis card will select and load quality requirements.	\N	\N	2025-10-22 18:03:46.909	\N	2025-10-22 18:03:46.909	0	f	\N
1627093221223958121	1627092980756121135	1627092980814841395	1560328737491256322	\N	\N	project	3	Load Prompt Templates	Prepare prompt templates for project type: CODE_ANALYSIS\n\nThis card will load and prepare prompt templates.	\N	\N	2025-10-22 18:03:46.934	\N	2025-10-22 18:03:46.934	0	f	\N
1627093221450450539	1627092980756121135	1627092980814841395	1560328737491256322	\N	\N	project	4	Validate META Asset Completeness	Validate that all META assets are loaded and ready.\n\nDepends on: 3 previous cards	\N	\N	2025-10-22 18:03:46.962	\N	2025-10-22 18:03:46.962	0	f	\N
1627093220729030245	1627092980756121135	1627092980881950260	1560328737491256322	\N	\N	project	1	Load Core Procedures for CODE_ANALYSIS	Load procedures for: code_review, testing, deployment, architecture_analysis\n\nThis card will select and load the necessary procedures from procedure_management.	\N	\N	2025-10-22 18:03:46.875	2025-10-22 18:03:46.98	2025-10-22 18:03:46.978	0	f	\N
1627548744566179439	1573201068874008314	1573201068957894398	1560328737491256322	\N	\N	project	65536	Template_Card	Context: This card template serves to inform card creation in order to standardize cards so that card quality can be more easily assessed and card content can be processed programmatically.\n\nObjective: The objective of this card template is to inform the structure and intended use of a card.\n\nAcceptance Criteria:\n\n```gherkin\nFeature: Standard Kanban Card Template Definition\nThe card template defines the structure and guidance for creating Kanban cards.\nIt must be sufficient, extensible, usable, and unambiguous.\n```\n\n```gherkin\nScenario: Template defines required structure to inform card creation\n  Given the card template is available\n  When I review the template document\n  Then I see the template provides:\n    """\n    - A clear declaration of each field’s name\n    - For each field: whether it is mandatory or optional\n    - For each field: a description of its purpose (what information the card creator should provide)\n    - For each field: any constraints or formats (e.g., “must be one of …”, “date/time in UTC”, etc.)\n    - A note of fields which are type-specific (placeholders/extensions) vs base fields\n    - Guidance that the template is to be used for all card types (or to be extended by type-specific templates)\n    """\n```\n\n```gherkin\nScenario: Template supports extensibility for different card types\n  Given the template is defined as the base card template\n  When I consider future card types (e.g., flow-cards, task-cards, procedure-cards)\n  Then the template must allow for extension\n  And the base fields remain consistent while type-specific fields may be added\n  And the template must indicate how to add or mark type-specific placeholders\n  And the template must clearly distinguish which fields are universal and which are optional or type-specific\n```\n\n```gherkin\nScenario: Template is usable as a checklist by card creators\n  Given someone is about to create a new card using the template\n  When they open the template document\n  Then they should be able to use it as a checklist to ensure they supply all required information for the card\n  And they should clearly see which fields can be left blank and which must be filled\n  And they should clearly understand what goes into each required field\n```\n\n```gherkin\nScenario: Template is unambiguous and testable\n  Given the template defines the fields and structure\n  When I assess it as a reviewer\n  Then none of the field descriptions shall be ambiguous\n  And the constraints and formats must be specific enough to validate later\n  And the template must use consistent language and style so that any card creator or reviewer can interpret it the same way\n```\n\n```gherkin\nScenario: Template acceptance decision\n  Given the template is ready for review by stakeholders\n  When all criteria (structure definition, extensibility, usability, and clarity) are satisfied\n  Then the template shall be accepted as the standard base template for all Kanban cards\n  And this acceptance shall be recorded and versioned\n```	\N	\N	2025-10-23 09:08:49.548	2025-11-03 12:22:32.151	2025-10-23 09:08:49.548	2	f	\N
1635621824966428401	1573201068874008314	1573201068957894398	1560328737491256322	\N	\N	project	131072	Example-Card	Context: This card is an example card.\n\nObjective: The objective of this card is to be an example for the creation of other cards\n\nAcceptance Criteria:\n\n```gherkin\nFeature: Kanban Card Example\nThe card example card provides guidance for creating other Kanban cards.\nIt must be sufficient, extensible, usable, and unambiguous.\n```\n\n```gherkin\nScenario: Example card provides an interpretation of the template to inform card creation\n  Given the card example is available\n  When I review the card example\n  Then I see the card example provides:\n    """\n    - A clear example of each field’s name\n    - For each field: an example\n    - For each field: an indication of the type of content that is expected\n    """\n```\n\n```gherkin\nScenario: Card example is usable as an example by card creators\n  Given someone is about to create a new card using the card template\n  When they open the card template\n  Then they should be able to use it as a reference of what information to supply in what location on the card\n```	\N	\N	2025-11-03 12:28:35.703	2025-11-03 12:34:59.795	2025-11-03 12:28:35.702	0	f	\N
1636624469462091664	1636624465494280050	1636624466509301623	1560328737491256322	\N	\N	project	65536	Analyze enterprise_mcp_server Repository	Initial analysis of the https://github.com/georgiedekker/enterprise_mcp_server codebase to identify issues and opportunities for improvement.\n\nRepository: https://github.com/georgiedekker/enterprise_mcp_server\nBranch: main	\N	\N	2025-11-04 21:40:40.266	\N	2025-11-04 21:40:40.265	0	f	\N
1636629176813356996	1636629173223032742	1636629173902509995	1560328737491256322	\N	\N	project	65536	Analyze enterprise_mcp_server Repository	Initial analysis of the https://github.com/georgiedekker/enterprise_mcp_server codebase to identify issues and opportunities for improvement.\n\nRepository: https://github.com/georgiedekker/enterprise_mcp_server\nBranch: main	\N	\N	2025-11-04 21:50:01.426	\N	2025-11-04 21:50:01.426	0	f	\N
1636635395984721896	1636635392016910282	1636635392679610319	1560328737491256322	\N	\N	project	65536	Analyze enterprise_mcp_server Repository	Initial analysis of the https://github.com/georgiedekker/enterprise_mcp_server codebase to identify issues and opportunities for improvement.\n\nRepository: https://github.com/georgiedekker/enterprise_mcp_server\nBranch: main	\N	\N	2025-11-04 22:02:22.808	\N	2025-11-04 22:02:22.808	0	f	\N
1636639391713592332	1636639387921942510	1636639388609808371	1560328737491256322	\N	\N	project	65536	Analyze enterprise_mcp_server Repository	Initial analysis of the https://github.com/georgiedekker/enterprise_mcp_server codebase to identify issues and opportunities for improvement.\n\nRepository: https://github.com/georgiedekker/enterprise_mcp_server\nBranch: main	\N	\N	2025-11-04 22:10:19.137	\N	2025-11-04 22:10:19.136	0	f	\N
1637207033390302265	1637150844338045993	1637150844489040942	1560328737491256322	\N	\N	project	65535	✅ Windmill MCP Integration Test	This card was created via Windmill MCP to verify write operations are working correctly!	\N	\N	2025-11-05 16:58:07.295	\N	2025-11-05 16:58:07.293	0	f	\N
1637647748255712317	1637150844338045993	1637150844489040942	1560328737491256322	\N	\N	project	131071	Analyze: Sales_Website	\N	\N	\N	2025-11-06 07:33:44.6	\N	2025-11-06 07:33:44.599	0	f	\N
1637836185097208897	1637150844338045993	1637150844489040942	1560328737491256322	\N	\N	project	196607	Analyze: Sales_Website	\N	\N	\N	2025-11-06 13:48:08.022	2025-11-06 13:50:51.569	2025-11-06 13:48:08.021	1	f	\N
\.


--
-- Data for Name: card_label; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_label (id, card_id, label_id, created_at, updated_at) FROM stdin;
1634823372326045403	1627548744566179439	1634823372175050458	2025-11-02 10:02:12.756	\N
1635621825092257522	1635621824966428401	1634823372175050458	2025-11-03 12:28:35.741	\N
1636639391797478414	1636639391713592332	1636639389675161594	2025-11-04 22:10:19.147	\N
1637839912667448394	1637836185097208897	1637150844765865011	2025-11-06 13:55:32.383	\N
\.


--
-- Data for Name: card_membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_membership (id, card_id, user_id, created_at, updated_at) FROM stdin;
1626890447882290476	1626139517612197737	1560328737491256325	2025-10-22 11:20:54.465	\N
\.


--
-- Data for Name: card_subscription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_subscription (id, card_id, user_id, is_permanent, created_at, updated_at) FROM stdin;
1626139639649666935	1626139517612197737	1560328737491256322	t	2025-10-21 10:29:11.153	\N
1626144574911023058	1626144083716081607	1560328737491256322	t	2025-10-21 10:38:59.481	\N
1626762740284523568	1626762360079254562	1560328737491256322	t	2025-10-22 07:07:10.537	\N
1626890447949399341	1626139517612197737	1560328737491256325	f	2025-10-22 11:20:54.476	\N
1634801900509464274	1627548744566179439	1560328737491256322	t	2025-11-02 09:19:33.116	\N
1634802288759408342	1627548744566179439	1560328737491256323	t	2025-11-02 09:20:19.399	\N
1637837557188265033	1637836185097208897	1560328737491256322	t	2025-11-06 13:50:51.59	\N
\.


--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comment (id, card_id, user_id, text, created_at, updated_at) FROM stdin;
1626139639616112502	1626139517612197737	1560328737491256322	🚀 **Card Ready for Execution**\n\n**Status**: Initiated\n**Timestamp**: 2025-10-21T10:29:11.087090+00:00\n**Next**: Moving to DOING state for execution\n\nAll prerequisites satisfied, beginning execution process.	2025-10-21 10:29:11.149	\N
1626139641268668284	1626139517612197737	1560328737491256322	✅ **Batch batch_1761042551_approval** completed\n\n**Status**: Success\n**Duration**: 0.250657s\n**Timestamp**: 2025-10-21 10:29:11 UTC\n\n**Results**:\n- meta-ready: 0.25s\n	2025-10-21 10:29:11.346	\N
1626139704434886528	1626139517612197737	1560328737491256322	✅ **Batch batch_1761042555_approval** completed\n\n**Status**: Success\n**Duration**: 3.358137s\n**Timestamp**: 2025-10-21 10:29:18 UTC\n\n**Results**:\n- meta-doing: 3.36s\n	2025-10-21 10:29:18.876	\N
1626144574860691409	1626144083716081607	1560328737491256322	🚀 **Card Ready for Execution**\n\n**Status**: Initiated\n**Timestamp**: 2025-10-21T10:38:59.388658+00:00\n**Next**: Moving to DOING state for execution\n\nAll prerequisites satisfied, beginning execution process.	2025-10-21 10:38:59.476	\N
1626144576555190231	1626144083716081607	1560328737491256322	✅ **Batch batch_1761043139_approval** completed\n\n**Status**: Success\n**Duration**: 0.323186s\n**Timestamp**: 2025-10-21 10:38:59 UTC\n\n**Results**:\n- meta-ready: 0.32s\n	2025-10-21 10:38:59.678	\N
1626146339211446234	1626144083716081607	1560328737491256322	✅ **Batch batch_1761043149_approval** completed\n\n**Status**: Success\n**Duration**: 200.296554s\n**Timestamp**: 2025-10-21 10:42:29 UTC\n\n**Results**:\n- meta-doing: 200.30s\n	2025-10-21 10:42:29.803	\N
1626762740242580527	1626762360079254562	1560328737491256322	🚀 **Card Ready for Execution**\n\n**Status**: Initiated\n**Timestamp**: 2025-10-22T07:07:10.472275+00:00\n**Next**: Moving to DOING state for execution\n\nAll prerequisites satisfied, beginning execution process.	2025-10-22 07:07:10.532	\N
1626762741853193269	1626762360079254562	1560328737491256322	✅ **Batch batch_1761116830_approval** completed\n\n**Status**: Success\n**Duration**: 0.24141s\n**Timestamp**: 2025-10-22 07:07:10 UTC\n\n**Results**:\n- meta-ready: 0.24s\n	2025-10-22 07:07:10.724	\N
1626762950712755256	1626762360079254562	1560328737491256322	✅ **Batch batch_1761116835_approval** completed\n\n**Status**: Success\n**Duration**: 20.128342s\n**Timestamp**: 2025-10-22 07:07:35 UTC\n\n**Results**:\n- meta-doing: 20.13s\n	2025-10-22 07:07:35.622	\N
1634802288608413396	1627548744566179439	1560328737491256323	@[admin_agent](1560328737491256322) you	2025-11-02 09:20:19.377	\N
1634801900140365520	1627548744566179439	1560328737491256322	@[admin_agent](1560328737491256322) who can help me?	2025-11-02 09:19:33.071	2025-11-03 12:23:12.268
1637837556961772616	1637836185097208897	1560328737491256322	I added Details ad a custom field group and repository_url and branch as custom fields. We should also use Label for the "analyze" directive of the card.	2025-11-06 13:50:51.555	\N
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.config (id, is_initialized, created_at, updated_at, smtp_host, smtp_port, smtp_name, smtp_secure, smtp_tls_reject_unauthorized, smtp_user, smtp_password, smtp_from) FROM stdin;
1	t	2025-11-07 08:29:22.464	\N	\N	\N	\N	f	t	\N	\N	\N
\.


--
-- Data for Name: custom_field; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_field (id, base_custom_field_group_id, custom_field_group_id, "position", name, show_on_front_of_card, created_at, updated_at) FROM stdin;
1635422730473965284	\N	1635422566837389027	65536	Requirement 1	t	2025-11-03 05:53:01.812	2025-11-03 05:53:40.003
1635423419665221352	\N	1635423337154873063	65536	Principle 1	t	2025-11-03 05:54:23.973	\N
1635424561790977774	\N	1635424505201428205	65536	Decision 1	t	2025-11-03 05:56:40.125	\N
1635621825192920826	\N	1635621825192920823	65536	Requirement 1	t	2025-11-03 12:28:35.768	\N
1635621825192920827	\N	1635621825192920824	65536	Principle 1	t	2025-11-03 12:28:35.768	\N
1635621825192920828	\N	1635621825192920825	65536	Decision 1	t	2025-11-03 12:28:35.768	\N
1636624468346406787	\N	1636624468262520706	16384	repository_url	t	2025-11-04 21:40:40.133	\N
1636624468413515652	\N	1636624468262520706	65536	branch	t	2025-11-04 21:40:40.141	\N
1636624468463847301	\N	1636624468262520706	131072	project_id	t	2025-11-04 21:40:40.146	\N
1636624468547733383	\N	1636624468505790342	16384	file_path	t	2025-11-04 21:40:40.157	\N
1636624468589676424	\N	1636624468505790342	65536	issue_description	f	2025-11-04 21:40:40.162	\N
1636624468631619465	\N	1636624468505790342	131072	analysis_card_id	f	2025-11-04 21:40:40.167	\N
1636624468673562506	\N	1636624468505790342	196608	project_id	f	2025-11-04 21:40:40.171	\N
1636624468740671372	\N	1636624468707116939	16384	fix_card_id	f	2025-11-04 21:40:40.18	\N
1636624468774225805	\N	1636624468707116939	65536	test_command	f	2025-11-04 21:40:40.184	\N
1636624468816168846	\N	1636624468707116939	131072	project_id	f	2025-11-04 21:40:40.189	\N
1636629175731226551	\N	1636629175680894902	16384	repository_url	t	2025-11-04 21:50:01.297	\N
1636629175806724024	\N	1636629175680894902	65536	branch	t	2025-11-04 21:50:01.305	\N
1636629175873832889	\N	1636629175680894902	131072	project_id	t	2025-11-04 21:50:01.314	\N
1636629175949330363	\N	1636629175907387322	16384	file_path	t	2025-11-04 21:50:01.322	\N
1636629175982884796	\N	1636629175907387322	65536	issue_description	f	2025-11-04 21:50:01.327	\N
1636629176024827837	\N	1636629175907387322	131072	analysis_card_id	f	2025-11-04 21:50:01.331	\N
1636629176058382270	\N	1636629175907387322	196608	project_id	f	2025-11-04 21:50:01.336	\N
1636629176125491136	\N	1636629176091936703	16384	fix_card_id	f	2025-11-04 21:50:01.344	\N
1636629176159045569	\N	1636629176091936703	65536	test_command	f	2025-11-04 21:50:01.348	\N
1636629176192600002	\N	1636629176091936703	131072	project_id	f	2025-11-04 21:50:01.352	\N
1636635394634155995	\N	1636635394575435738	16384	repository_url	t	2025-11-04 22:02:22.648	\N
1636635394684487644	\N	1636635394575435738	65536	branch	t	2025-11-04 22:02:22.654	\N
1636635394759985117	\N	1636635394575435738	131072	project_id	t	2025-11-04 22:02:22.663	\N
1636635394827093983	\N	1636635394793539550	16384	file_path	t	2025-11-04 22:02:22.671	\N
1636635394860648416	\N	1636635394793539550	65536	issue_description	f	2025-11-04 22:02:22.675	\N
1636635394894202849	\N	1636635394793539550	131072	analysis_card_id	f	2025-11-04 22:02:22.679	\N
1636635394986477538	\N	1636635394793539550	196608	project_id	f	2025-11-04 22:02:22.689	\N
1636635395246524388	\N	1636635395112306659	16384	fix_card_id	f	2025-11-04 22:02:22.721	\N
1636635395280078821	\N	1636635395112306659	65536	test_command	f	2025-11-04 22:02:22.725	\N
1636635395330410470	\N	1636635395112306659	131072	project_id	f	2025-11-04 22:02:22.731	\N
1636639390413359103	\N	1636639390371416062	16384	repository_url	t	2025-11-04 22:10:18.982	\N
1636639390463689728	\N	1636639390371416062	65536	branch	t	2025-11-04 22:10:18.988	\N
1636639390505632769	\N	1636639390371416062	131072	project_id	t	2025-11-04 22:10:18.992	\N
1636639390572741635	\N	1636639390539187202	16384	file_path	t	2025-11-04 22:10:19.001	\N
1636639390606296068	\N	1636639390539187202	65536	issue_description	f	2025-11-04 22:10:19.005	\N
1636639390639850501	\N	1636639390539187202	131072	analysis_card_id	f	2025-11-04 22:10:19.009	\N
1636639390673404934	\N	1636639390539187202	196608	project_id	f	2025-11-04 22:10:19.013	\N
1636639390849565704	\N	1636639390715347975	16384	fix_card_id	f	2025-11-04 22:10:19.033	\N
1636639390891508745	\N	1636639390715347975	65536	test_command	f	2025-11-04 22:10:19.038	\N
1636639390941840394	\N	1636639390715347975	131072	project_id	f	2025-11-04 22:10:19.044	\N
1637836358238078020	\N	1637836264243725379	65536	repository_url	f	2025-11-06 13:48:28.662	\N
1637837148881159238	\N	1637836264243725379	131072	branch	t	2025-11-06 13:50:02.914	\N
\.


--
-- Data for Name: custom_field_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_field_group (id, board_id, card_id, base_custom_field_group_id, "position", name, created_at, updated_at) FROM stdin;
1635422566837389027	\N	1627548744566179439	\N	65536	Requirements	2025-11-03 05:52:42.289	\N
1635423337154873063	\N	1627548744566179439	\N	131072	Principles	2025-11-03 05:54:14.135	\N
1635424505201428205	\N	1627548744566179439	\N	196608	Decisions	2025-11-03 05:56:33.376	\N
1635621825192920823	\N	1635621824966428401	\N	65536	Requirements	2025-11-03 12:28:35.766	\N
1635621825192920824	\N	1635621824966428401	\N	131072	Principles	2025-11-03 12:28:35.766	\N
1635621825192920825	\N	1635621824966428401	\N	196608	Decisions	2025-11-03 12:28:35.766	\N
1636624468262520706	1636624465494280050	\N	\N	16384	Repository Info	2025-11-04 21:40:40.123	\N
1636624468505790342	1636624465494280050	\N	\N	1	Fix Details	2025-11-04 21:40:40.152	\N
1636624468707116939	1636624465494280050	\N	\N	2	Validation Info	2025-11-04 21:40:40.176	\N
1636629175680894902	1636629173223032742	\N	\N	16384	Repository Info	2025-11-04 21:50:01.291	\N
1636629175907387322	1636629173223032742	\N	\N	1	Fix Details	2025-11-04 21:50:01.318	\N
1636629176091936703	1636629173223032742	\N	\N	2	Validation Info	2025-11-04 21:50:01.34	\N
1636635394575435738	1636635392016910282	\N	\N	16384	Repository Info	2025-11-04 22:02:22.641	\N
1636635394793539550	1636635392016910282	\N	\N	1	Fix Details	2025-11-04 22:02:22.667	\N
1636635395112306659	1636635392016910282	\N	\N	2	Validation Info	2025-11-04 22:02:22.705	\N
1636639390371416062	1636639387921942510	\N	\N	16384	Repository Info	2025-11-04 22:10:18.977	\N
1636639390539187202	1636639387921942510	\N	\N	1	Fix Details	2025-11-04 22:10:18.997	\N
1636639390715347975	1636639387921942510	\N	\N	2	Validation Info	2025-11-04 22:10:19.018	\N
1637836264243725379	\N	1637836185097208897	\N	65536	Details	2025-11-06 13:48:17.453	2025-11-06 13:48:55.718
\.


--
-- Data for Name: custom_field_value; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_field_value (id, card_id, custom_field_group_id, custom_field_id, content, created_at, updated_at) FROM stdin;
1635422809402377957	1627548744566179439	1635422566837389027	1635422730473965284	Some requirement text	2025-11-03 05:53:11.22	2025-11-03 05:53:46.947
1635423497805104873	1627548744566179439	1635423337154873063	1635423419665221352	Some principle text	2025-11-03 05:54:33.287	\N
1635424605235578607	1627548744566179439	1635424505201428205	1635424561790977774	Some decision text	2025-11-03 05:56:45.304	\N
1635621825360692993	1635621824966428401	1635621825192920823	1635621825192920826	Cards inform all behavior related to the card	2025-11-03 12:28:35.774	2025-11-03 12:35:42.713
1635621825377470210	1635621824966428401	1635621825192920824	1635621825192920827	Cards are the Single Source Of Truth	2025-11-03 12:28:35.774	2025-11-03 12:36:30.302
1635621825377470211	1635621824966428401	1635621825192920825	1635621825192920828	Any information that does not fit on the card needs to be stored in the state store	2025-11-03 12:28:35.774	2025-11-03 12:36:56.344
1637836912104309829	1637836185097208897	1637836264243725379	1637836358238078020	https://github.com/georgiedekker/enterprise_mcp_server	2025-11-06 13:49:34.688	\N
1637837197627360327	1637836185097208897	1637836264243725379	1637837148881159238	main	2025-11-06 13:50:08.727	\N
\.


--
-- Data for Name: identity_provider_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.identity_provider_user (id, user_id, issuer, sub, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.label (id, board_id, "position", name, color, created_at, updated_at) FROM stdin;
1634823372175050458	1573201068874008314	65536	TEMPLATE	pirate-gold	2025-11-02 10:02:12.734	\N
1636624467507545982	1636624465494280050	16384	analysis	summer-sky	2025-11-04 21:40:40.033	\N
1636624467566266239	1636624465494280050	65536	fix	orange-peel	2025-11-04 21:40:40.04	\N
1636624467608209280	1636624465494280050	131072	validation	fresh-salad	2025-11-04 21:40:40.045	\N
1636629174900754354	1636629173223032742	16384	analysis	summer-sky	2025-11-04 21:50:01.198	\N
1636629174951086003	1636629173223032742	65536	fix	orange-peel	2025-11-04 21:50:01.204	\N
1636629175009806260	1636629173223032742	131072	validation	fresh-salad	2025-11-04 21:50:01.21	\N
1636635393820461014	1636635392016910282	16384	analysis	summer-sky	2025-11-04 22:02:22.551	\N
1636635393887569879	1636635392016910282	65536	fix	orange-peel	2025-11-04 22:02:22.559	\N
1636635393937901528	1636635392016910282	131072	validation	fresh-salad	2025-11-04 22:02:22.565	\N
1636639389675161594	1636639387921942510	16384	analysis	summer-sky	2025-11-04 22:10:18.894	\N
1636639389725493243	1636639387921942510	65536	fix	orange-peel	2025-11-04 22:10:18.9	\N
1636639389759047676	1636639387921942510	131072	validation	fresh-salad	2025-11-04 22:10:18.904	\N
1637150844765865011	1637150844338045993	16384	analysis	morning-sky	2025-11-05 15:06:29.092	\N
1637150844807808052	1637150844338045993	1	fix	light-orange	2025-11-05 15:06:29.096	\N
1637150844832973877	1637150844338045993	2	validation	sunny-grass	2025-11-05 15:06:29.1	\N
1637150844874916918	1637150844338045993	3	blocked	berry-red	2025-11-05 15:06:29.104	\N
1637150844908471351	1637150844338045993	4	enhancement	sugar-plum	2025-11-05 15:06:29.109	\N
\.


--
-- Data for Name: list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.list (id, board_id, type, "position", name, color, created_at, updated_at) FROM stdin;
1573201068890785532	1573201068874008314	archive	\N	\N	\N	2025-08-09 09:29:41.743	\N
1573201068890785533	1573201068874008314	trash	\N	\N	\N	2025-08-09 09:29:41.743	\N
1573201068957894398	1573201068874008314	active	65536	TODO	\N	2025-08-09 09:29:41.751	\N
1573201069058557695	1573201068874008314	active	131072	READY	\N	2025-08-09 09:29:41.762	\N
1573201069100500736	1573201068874008314	active	196608	DOING	\N	2025-08-09 09:29:41.768	\N
1573201069150832385	1573201068874008314	active	262144	QA	\N	2025-08-09 09:29:41.774	\N
1573201069226329858	1573201068874008314	active	327680	BLOCKED	\N	2025-08-09 09:29:41.783	\N
1573201069268272899	1573201068874008314	active	393216	DONE	\N	2025-08-09 09:29:41.788	\N
1573201069729646345	1573201069712869127	archive	\N	\N	\N	2025-08-09 09:29:41.843	\N
1573201069729646346	1573201069712869127	trash	\N	\N	\N	2025-08-09 09:29:41.843	\N
1573201069788366603	1573201069712869127	active	65536	TODO	\N	2025-08-09 09:29:41.85	\N
1573201069872252684	1573201069712869127	active	131072	READY	\N	2025-08-09 09:29:41.859	\N
1573201069922584333	1573201069712869127	active	196608	DOING	\N	2025-08-09 09:29:41.866	\N
1573201069972915982	1573201069712869127	active	262144	QA	\N	2025-08-09 09:29:41.872	\N
1573201070014859023	1573201069712869127	active	327680	BLOCKED	\N	2025-08-09 09:29:41.877	\N
1573201070056802064	1573201069712869127	active	393216	DONE	\N	2025-08-09 09:29:41.882	\N
1573201070325237526	1573201070316848916	archive	\N	\N	\N	2025-08-09 09:29:41.914	\N
1573201070325237527	1573201070316848916	trash	\N	\N	\N	2025-08-09 09:29:41.914	\N
1573201070425900824	1573201070316848916	active	65536	TODO	\N	2025-08-09 09:29:41.925	\N
1573201070476232473	1573201070316848916	active	131072	READY	\N	2025-08-09 09:29:41.932	\N
1573201070518175514	1573201070316848916	active	196608	DOING	\N	2025-08-09 09:29:41.937	\N
1573201070560118555	1573201070316848916	active	262144	QA	\N	2025-08-09 09:29:41.942	\N
1573201070602061596	1573201070316848916	active	327680	BLOCKED	\N	2025-08-09 09:29:41.947	\N
1573201070644004637	1573201070316848916	active	393216	DONE	\N	2025-08-09 09:29:41.952	\N
1626139470543718189	1626139470484997931	archive	\N	\N	\N	2025-10-21 10:28:50.992	\N
1626139470543718190	1626139470484997931	trash	\N	\N	\N	2025-10-21 10:28:50.992	\N
1626139470669547311	1626139470484997931	active	65536	TODO	\N	2025-10-21 10:28:51.009	\N
1626139470912816944	1626139470484997931	active	131072	READY	\N	2025-10-21 10:28:51.037	\N
1626139471021868849	1626139470484997931	active	196608	DOING	\N	2025-10-21 10:28:51.05	\N
1626139471248361266	1626139470484997931	active	262144	QA	\N	2025-10-21 10:28:51.077	\N
1626139471323858739	1626139470484997931	active	327680	BLOCKED	\N	2025-10-21 10:28:51.087	\N
1626139471390967604	1626139470484997931	active	393216	DONE	\N	2025-10-21 10:28:51.095	\N
1626139471919449912	1626139471911061302	archive	\N	\N	\N	2025-10-21 10:28:51.158	\N
1626139471919449913	1626139471911061302	trash	\N	\N	\N	2025-10-21 10:28:51.158	\N
1626139471978170170	1626139471911061302	active	65536	TODO	\N	2025-10-21 10:28:51.165	\N
1626139472045279035	1626139471911061302	active	131072	READY	\N	2025-10-21 10:28:51.172	\N
1626139472095610684	1626139471911061302	active	196608	DOING	\N	2025-10-21 10:28:51.179	\N
1626139472171108157	1626139471911061302	active	262144	QA	\N	2025-10-21 10:28:51.188	\N
1626139472229828414	1626139471911061302	active	327680	BLOCKED	\N	2025-10-21 10:28:51.195	\N
1626139472288548671	1626139471911061302	active	393216	DONE	\N	2025-10-21 10:28:51.202	\N
1626139472791865155	1626139472775087937	archive	\N	\N	\N	2025-10-21 10:28:51.261	\N
1626139472791865156	1626139472775087937	trash	\N	\N	\N	2025-10-21 10:28:51.261	\N
1626139472842196805	1626139472775087937	active	65536	TODO	\N	2025-10-21 10:28:51.268	\N
1626139472892528454	1626139472775087937	active	131072	READY	\N	2025-10-21 10:28:51.274	\N
1626139472942860103	1626139472775087937	active	196608	DOING	\N	2025-10-21 10:28:51.28	\N
1626139473001580360	1626139472775087937	active	262144	QA	\N	2025-10-21 10:28:51.286	\N
1626139473051912009	1626139472775087937	active	327680	BLOCKED	\N	2025-10-21 10:28:51.293	\N
1626139473110632266	1626139472775087937	active	393216	DONE	\N	2025-10-21 10:28:51.3	\N
1626139473605560142	1626139473588782924	archive	\N	\N	\N	2025-10-21 10:28:51.358	\N
1626139473605560143	1626139473588782924	trash	\N	\N	\N	2025-10-21 10:28:51.358	\N
1626139473655891792	1626139473588782924	active	65536	TODO	\N	2025-10-21 10:28:51.365	\N
1626139473714612049	1626139473588782924	active	131072	READY	\N	2025-10-21 10:28:51.372	\N
1626139473773332306	1626139473588782924	active	196608	DOING	\N	2025-10-21 10:28:51.378	\N
1626139473832052563	1626139473588782924	active	262144	QA	\N	2025-10-21 10:28:51.385	\N
1626139473882384212	1626139473588782924	active	327680	BLOCKED	\N	2025-10-21 10:28:51.391	\N
1626139473941104469	1626139473588782924	active	393216	DONE	\N	2025-10-21 10:28:51.399	\N
1626143868288239496	1626143868271462278	archive	\N	\N	\N	2025-10-21 10:37:35.245	\N
1626143868288239497	1626143868271462278	trash	\N	\N	\N	2025-10-21 10:37:35.245	\N
1626143868355348362	1626143868271462278	active	65536	TODO	\N	2025-10-21 10:37:35.254	\N
1626143868430845835	1626143868271462278	active	131072	READY	\N	2025-10-21 10:37:35.263	\N
1626143868489566092	1626143868271462278	active	196608	DOING	\N	2025-10-21 10:37:35.269	\N
1626143868556674957	1626143868271462278	active	262144	QA	\N	2025-10-21 10:37:35.278	\N
1626143868615395214	1626143868271462278	active	327680	BLOCKED	\N	2025-10-21 10:37:35.285	\N
1626143868690892687	1626143868271462278	active	393216	DONE	\N	2025-10-21 10:37:35.294	\N
1626143869244540819	1626143869236152209	archive	\N	\N	\N	2025-10-21 10:37:35.36	\N
1626143869244540820	1626143869236152209	trash	\N	\N	\N	2025-10-21 10:37:35.36	\N
1626143869420701589	1626143869236152209	active	65536	TODO	\N	2025-10-21 10:37:35.381	\N
1626143869512976278	1626143869236152209	active	131072	READY	\N	2025-10-21 10:37:35.392	\N
1626143869580085143	1626143869236152209	active	196608	DOING	\N	2025-10-21 10:37:35.4	\N
1626143869638805400	1626143869236152209	active	262144	QA	\N	2025-10-21 10:37:35.407	\N
1626143869697525657	1626143869236152209	active	327680	BLOCKED	\N	2025-10-21 10:37:35.414	\N
1626143869756245914	1626143869236152209	active	393216	DONE	\N	2025-10-21 10:37:35.421	\N
1626143870276339614	1626143870267951004	archive	\N	\N	\N	2025-10-21 10:37:35.483	\N
1626143870276339615	1626143870267951004	trash	\N	\N	\N	2025-10-21 10:37:35.483	\N
1626143870326671264	1626143870267951004	active	65536	TODO	\N	2025-10-21 10:37:35.489	\N
1626143870393780129	1626143870267951004	active	131072	READY	\N	2025-10-21 10:37:35.497	\N
1626143870444111778	1626143870267951004	active	196608	DOING	\N	2025-10-21 10:37:35.502	\N
1626143870494443427	1626143870267951004	active	262144	QA	\N	2025-10-21 10:37:35.508	\N
1626143870536386468	1626143870267951004	active	327680	BLOCKED	\N	2025-10-21 10:37:35.514	\N
1626143870586718117	1626143870267951004	active	393216	DONE	\N	2025-10-21 10:37:35.52	\N
1626143871090034601	1626143871081645991	archive	\N	\N	\N	2025-10-21 10:37:35.58	\N
1626143871090034602	1626143871081645991	trash	\N	\N	\N	2025-10-21 10:37:35.58	\N
1626143871157143467	1626143871081645991	active	65536	TODO	\N	2025-10-21 10:37:35.588	\N
1626143871215863724	1626143871081645991	active	131072	READY	\N	2025-10-21 10:37:35.594	\N
1626143871299749805	1626143871081645991	active	196608	DOING	\N	2025-10-21 10:37:35.603	\N
1626143871408801710	1626143871081645991	active	262144	QA	\N	2025-10-21 10:37:35.618	\N
1626143871459133359	1626143871081645991	active	327680	BLOCKED	\N	2025-10-21 10:37:35.624	\N
1626143871501076400	1626143871081645991	active	393216	DONE	\N	2025-10-21 10:37:35.629	\N
1626762337522288611	1626762337480345569	archive	\N	\N	\N	2025-10-22 07:06:22.523	\N
1626762337530677220	1626762337480345569	trash	\N	\N	\N	2025-10-22 07:06:22.523	\N
1626762337614563301	1626762337480345569	active	65536	TODO	\N	2025-10-22 07:06:22.534	\N
1626762337882998758	1626762337480345569	active	131072	READY	\N	2025-10-22 07:06:22.566	\N
1626762337950107623	1626762337480345569	active	196608	DOING	\N	2025-10-22 07:06:22.575	\N
1626762338008827880	1626762337480345569	active	262144	QA	\N	2025-10-22 07:06:22.582	\N
1626762338176600041	1626762337480345569	active	327680	BLOCKED	\N	2025-10-22 07:06:22.602	\N
1626762338294040554	1626762337480345569	active	393216	DONE	\N	2025-10-22 07:06:22.616	\N
1626762338830911470	1626762338814134252	archive	\N	\N	\N	2025-10-22 07:06:22.679	\N
1626762338830911471	1626762338814134252	trash	\N	\N	\N	2025-10-22 07:06:22.679	\N
1626762338889631728	1626762338814134252	active	65536	TODO	\N	2025-10-22 07:06:22.687	\N
1626762338956740593	1626762338814134252	active	131072	READY	\N	2025-10-22 07:06:22.695	\N
1626762339007072242	1626762338814134252	active	196608	DOING	\N	2025-10-22 07:06:22.701	\N
1626762339074181107	1626762338814134252	active	262144	QA	\N	2025-10-22 07:06:22.709	\N
1626762339132901364	1626762338814134252	active	327680	BLOCKED	\N	2025-10-22 07:06:22.716	\N
1626762339183233013	1626762338814134252	active	393216	DONE	\N	2025-10-22 07:06:22.722	\N
1626762339720103929	1626762339703326711	archive	\N	\N	\N	2025-10-22 07:06:22.786	\N
1626762339720103930	1626762339703326711	trash	\N	\N	\N	2025-10-22 07:06:22.786	\N
1626762339778824187	1626762339703326711	active	65536	TODO	\N	2025-10-22 07:06:22.793	\N
1626762339837544444	1626762339703326711	active	131072	READY	\N	2025-10-22 07:06:22.799	\N
1626762339879487485	1626762339703326711	active	196608	DOING	\N	2025-10-22 07:06:22.805	\N
1626762339929819134	1626762339703326711	active	262144	QA	\N	2025-10-22 07:06:22.811	\N
1626762339980150783	1626762339703326711	active	327680	BLOCKED	\N	2025-10-22 07:06:22.817	\N
1626762340030481408	1626762339703326711	active	393216	DONE	\N	2025-10-22 07:06:22.823	\N
1626762340533797892	1626762340525409282	archive	\N	\N	\N	2025-10-22 07:06:22.883	\N
1626762340533797893	1626762340525409282	trash	\N	\N	\N	2025-10-22 07:06:22.883	\N
1626762340584129542	1626762340525409282	active	65536	TODO	\N	2025-10-22 07:06:22.889	\N
1626762340634461191	1626762340525409282	active	131072	READY	\N	2025-10-22 07:06:22.895	\N
1626762340693181448	1626762340525409282	active	196608	DOING	\N	2025-10-22 07:06:22.902	\N
1626762340777067529	1626762340525409282	active	262144	QA	\N	2025-10-22 07:06:22.912	\N
1626762341246829578	1626762340525409282	active	327680	BLOCKED	\N	2025-10-22 07:06:22.968	\N
1626762341297161227	1626762340525409282	active	393216	DONE	\N	2025-10-22 07:06:22.973	\N
1626777062993822786	1626777062960268352	archive	\N	\N	\N	2025-10-22 07:35:37.936	\N
1626777063002211395	1626777062960268352	trash	\N	\N	\N	2025-10-22 07:35:37.936	\N
1626777063086097476	1626777062960268352	active	65536	TODO	\N	2025-10-22 07:35:37.947	\N
1626777063312589893	1626777062960268352	active	131072	READY	\N	2025-10-22 07:35:37.975	\N
1626777063379698758	1626777062960268352	active	196608	DOING	\N	2025-10-22 07:35:37.983	\N
1626777063446807623	1626777062960268352	active	262144	QA	\N	2025-10-22 07:35:37.99	\N
1626777063530693704	1626777062960268352	active	327680	BLOCKED	\N	2025-10-22 07:35:38	\N
1626777063706854473	1626777062960268352	active	393216	DONE	\N	2025-10-22 07:35:38.022	\N
1626777064252113997	1626777064243725387	archive	\N	\N	\N	2025-10-22 07:35:38.086	\N
1626777064252113998	1626777064243725387	trash	\N	\N	\N	2025-10-22 07:35:38.086	\N
1626777064319222863	1626777064243725387	active	65536	TODO	\N	2025-10-22 07:35:38.094	\N
1626777064369554512	1626777064243725387	active	131072	READY	\N	2025-10-22 07:35:38.101	\N
1626777064419886161	1626777064243725387	active	196608	DOING	\N	2025-10-22 07:35:38.107	\N
1626777064537326674	1626777064243725387	active	262144	QA	\N	2025-10-22 07:35:38.12	\N
1626777065074197587	1626777064243725387	active	327680	BLOCKED	\N	2025-10-22 07:35:38.185	\N
1626777065132917844	1626777064243725387	active	393216	DONE	\N	2025-10-22 07:35:38.192	\N
1626777065644622936	1626777065636234326	archive	\N	\N	\N	2025-10-22 07:35:38.253	\N
1626777065644622937	1626777065636234326	trash	\N	\N	\N	2025-10-22 07:35:38.253	\N
1626777065694954586	1626777065636234326	active	65536	TODO	\N	2025-10-22 07:35:38.259	\N
1626777065745286235	1626777065636234326	active	131072	READY	\N	2025-10-22 07:35:38.265	\N
1626777065795617884	1626777065636234326	active	196608	DOING	\N	2025-10-22 07:35:38.271	\N
1626777065871115357	1626777065636234326	active	262144	QA	\N	2025-10-22 07:35:38.279	\N
1626777065921447006	1626777065636234326	active	327680	BLOCKED	\N	2025-10-22 07:35:38.286	\N
1626777065963390047	1626777065636234326	active	393216	DONE	\N	2025-10-22 07:35:38.291	\N
1626777066475095139	1626777066466706529	archive	\N	\N	\N	2025-10-22 07:35:38.352	\N
1626777066483483748	1626777066466706529	trash	\N	\N	\N	2025-10-22 07:35:38.352	\N
1626777066542204005	1626777066466706529	active	65536	TODO	\N	2025-10-22 07:35:38.36	\N
1626777066592535654	1626777066466706529	active	131072	READY	\N	2025-10-22 07:35:38.366	\N
1626777066634478695	1626777066466706529	active	196608	DOING	\N	2025-10-22 07:35:38.371	\N
1626777066693198952	1626777066466706529	active	262144	QA	\N	2025-10-22 07:35:38.378	\N
1626777066751919209	1626777066466706529	active	327680	BLOCKED	\N	2025-10-22 07:35:38.385	\N
1626777066802250858	1626777066466706529	active	393216	DONE	\N	2025-10-22 07:35:38.391	\N
1626840256114328720	1626840256055608462	archive	\N	\N	\N	2025-10-22 09:41:11.142	\N
1626840256131105937	1626840256055608462	trash	\N	\N	\N	2025-10-22 09:41:11.142	\N
1626840256231769234	1626840256055608462	active	65536	TODO	\N	2025-10-22 09:41:11.157	\N
1626840256391152787	1626840256055608462	active	131072	READY	\N	2025-10-22 09:41:11.176	\N
1626840256475038868	1626840256055608462	active	196608	DOING	\N	2025-10-22 09:41:11.186	\N
1626840256567313557	1626840256055608462	active	262144	QA	\N	2025-10-22 09:41:11.197	\N
1626840256642811030	1626840256055608462	active	327680	BLOCKED	\N	2025-10-22 09:41:11.206	\N
1626840256743474327	1626840256055608462	active	393216	DONE	\N	2025-10-22 09:41:11.219	\N
1626840257364231323	1626840257347454105	archive	\N	\N	\N	2025-10-22 09:41:11.293	\N
1626840257364231324	1626840257347454105	trash	\N	\N	\N	2025-10-22 09:41:11.293	\N
1626840257431340189	1626840257347454105	active	65536	TODO	\N	2025-10-22 09:41:11.301	\N
1626840257506837662	1626840257347454105	active	131072	READY	\N	2025-10-22 09:41:11.31	\N
1626840257590723743	1626840257347454105	active	196608	DOING	\N	2025-10-22 09:41:11.319	\N
1626840257674609824	1626840257347454105	active	262144	QA	\N	2025-10-22 09:41:11.329	\N
1626840257724941473	1626840257347454105	active	327680	BLOCKED	\N	2025-10-22 09:41:11.336	\N
1626840257766884514	1626840257347454105	active	393216	DONE	\N	2025-10-22 09:41:11.341	\N
1626840258345698470	1626840258337309860	archive	\N	\N	\N	2025-10-22 09:41:11.41	\N
1626840258345698471	1626840258337309860	trash	\N	\N	\N	2025-10-22 09:41:11.41	\N
1626840258421195944	1626840258337309860	active	65536	TODO	\N	2025-10-22 09:41:11.419	\N
1626840258588968105	1626840258337309860	active	131072	READY	\N	2025-10-22 09:41:11.438	\N
1626840258773517482	1626840258337309860	active	196608	DOING	\N	2025-10-22 09:41:11.461	\N
1626840258832237739	1626840258337309860	active	262144	QA	\N	2025-10-22 09:41:11.468	\N
1626840258882569388	1626840258337309860	active	327680	BLOCKED	\N	2025-10-22 09:41:11.474	\N
1626840258932901037	1626840258337309860	active	393216	DONE	\N	2025-10-22 09:41:11.48	\N
1626840259461383345	1626840259452994735	archive	\N	\N	\N	2025-10-22 09:41:11.542	\N
1626840259461383346	1626840259452994735	trash	\N	\N	\N	2025-10-22 09:41:11.542	\N
1626840259503326387	1626840259452994735	active	65536	TODO	\N	2025-10-22 09:41:11.548	\N
1626840259562046644	1626840259452994735	active	131072	READY	\N	2025-10-22 09:41:11.555	\N
1626840259620766901	1626840259452994735	active	196608	DOING	\N	2025-10-22 09:41:11.562	\N
1626840259662709942	1626840259452994735	active	262144	QA	\N	2025-10-22 09:41:11.567	\N
1626840259713041591	1626840259452994735	active	327680	BLOCKED	\N	2025-10-22 09:41:11.573	\N
1626840259746596024	1626840259452994735	active	393216	DONE	\N	2025-10-22 09:41:11.577	\N
1626853199098938592	1626853199073772766	archive	\N	\N	\N	2025-10-22 10:06:54.067	\N
1626853199107327201	1626853199073772766	trash	\N	\N	\N	2025-10-22 10:06:54.067	\N
1626853199233156322	1626853199073772766	active	65536	TODO	\N	2025-10-22 10:06:54.084	\N
1626853199350596835	1626853199073772766	active	131072	READY	\N	2025-10-22 10:06:54.097	\N
1626853199442871524	1626853199073772766	active	196608	DOING	\N	2025-10-22 10:06:54.108	\N
1626853199560312037	1626853199073772766	active	262144	QA	\N	2025-10-22 10:06:54.122	\N
1626853199644198118	1626853199073772766	active	327680	BLOCKED	\N	2025-10-22 10:06:54.133	\N
1626853199702918375	1626853199073772766	active	393216	DONE	\N	2025-10-22 10:06:54.14	\N
1626853200239789291	1626853200231400681	archive	\N	\N	\N	2025-10-22 10:06:54.204	\N
1626853200248177900	1626853200231400681	trash	\N	\N	\N	2025-10-22 10:06:54.204	\N
1626853200306898157	1626853200231400681	active	65536	TODO	\N	2025-10-22 10:06:54.211	\N
1626853200365618414	1626853200231400681	active	131072	READY	\N	2025-10-22 10:06:54.219	\N
1626853200415950063	1626853200231400681	active	196608	DOING	\N	2025-10-22 10:06:54.225	\N
1626853200474670320	1626853200231400681	active	262144	QA	\N	2025-10-22 10:06:54.231	\N
1626853200516613361	1626853200231400681	active	327680	BLOCKED	\N	2025-10-22 10:06:54.237	\N
1626853200583722226	1626853200231400681	active	393216	DONE	\N	2025-10-22 10:06:54.245	\N
1626853201087038710	1626853201078650100	archive	\N	\N	\N	2025-10-22 10:06:54.305	\N
1626853201087038711	1626853201078650100	trash	\N	\N	\N	2025-10-22 10:06:54.305	\N
1626853201145758968	1626853201078650100	active	65536	TODO	\N	2025-10-22 10:06:54.312	\N
1626853201321919737	1626853201078650100	active	131072	READY	\N	2025-10-22 10:06:54.332	\N
1626853201456137466	1626853201078650100	active	196608	DOING	\N	2025-10-22 10:06:54.349	\N
1626853201523246331	1626853201078650100	active	262144	QA	\N	2025-10-22 10:06:54.357	\N
1626853201607132412	1626853201078650100	active	327680	BLOCKED	\N	2025-10-22 10:06:54.366	\N
1626853201665852669	1626853201078650100	active	393216	DONE	\N	2025-10-22 10:06:54.374	\N
1626853202211112193	1626853202202723583	archive	\N	\N	\N	2025-10-22 10:06:54.438	\N
1626853202211112194	1626853202202723583	trash	\N	\N	\N	2025-10-22 10:06:54.438	\N
1626853202253055235	1626853202202723583	active	65536	TODO	\N	2025-10-22 10:06:54.443	\N
1626853202303386884	1626853202202723583	active	131072	READY	\N	2025-10-22 10:06:54.45	\N
1626853202345329925	1626853202202723583	active	196608	DOING	\N	2025-10-22 10:06:54.455	\N
1626853202395661574	1626853202202723583	active	262144	QA	\N	2025-10-22 10:06:54.461	\N
1626853202445993223	1626853202202723583	active	327680	BLOCKED	\N	2025-10-22 10:06:54.466	\N
1626853202487936264	1626853202202723583	active	393216	DONE	\N	2025-10-22 10:06:54.472	\N
1626893017564579128	1626893017539413302	archive	\N	\N	\N	2025-10-22 11:26:00.798	\N
1626893017572967737	1626893017539413302	trash	\N	\N	\N	2025-10-22 11:26:00.798	\N
1626893017631687994	1626893017539413302	active	65536	TODO	\N	2025-10-22 11:26:00.807	\N
1626893017698796859	1626893017539413302	active	131072	READY	\N	2025-10-22 11:26:00.815	\N
1626893017749128508	1626893017539413302	active	196608	DOING	\N	2025-10-22 11:26:00.82	\N
1626893017799460157	1626893017539413302	active	262144	QA	\N	2025-10-22 11:26:00.827	\N
1626893017849791806	1626893017539413302	active	327680	BLOCKED	\N	2025-10-22 11:26:00.833	\N
1626893017900123455	1626893017539413302	active	393216	DONE	\N	2025-10-22 11:26:00.839	\N
1626893018487326019	1626893018478937409	archive	\N	\N	\N	2025-10-22 11:26:00.909	\N
1626893018487326020	1626893018478937409	trash	\N	\N	\N	2025-10-22 11:26:00.909	\N
1626893018537657669	1626893018478937409	active	65536	TODO	\N	2025-10-22 11:26:00.914	\N
1626893018579600710	1626893018478937409	active	131072	READY	\N	2025-10-22 11:26:00.92	\N
1626893018646709575	1626893018478937409	active	196608	DOING	\N	2025-10-22 11:26:00.927	\N
1626893018822870344	1626893018478937409	active	262144	QA	\N	2025-10-22 11:26:00.948	\N
1626893018923533641	1626893018478937409	active	327680	BLOCKED	\N	2025-10-22 11:26:00.961	\N
1626893018973865290	1626893018478937409	active	393216	DONE	\N	2025-10-22 11:26:00.967	\N
1626893019477181774	1626893019468793164	archive	\N	\N	\N	2025-10-22 11:26:01.027	\N
1626893019477181775	1626893019468793164	trash	\N	\N	\N	2025-10-22 11:26:01.027	\N
1626893019527513424	1626893019468793164	active	65536	TODO	\N	2025-10-22 11:26:01.033	\N
1626893019569456465	1626893019468793164	active	131072	READY	\N	2025-10-22 11:26:01.038	\N
1626893019611399506	1626893019468793164	active	196608	DOING	\N	2025-10-22 11:26:01.043	\N
1626893019653342547	1626893019468793164	active	262144	QA	\N	2025-10-22 11:26:01.048	\N
1626893019695285588	1626893019468793164	active	327680	BLOCKED	\N	2025-10-22 11:26:01.053	\N
1626893019737228629	1626893019468793164	active	393216	DONE	\N	2025-10-22 11:26:01.058	\N
1626893020232156505	1626893020223767895	archive	\N	\N	\N	2025-10-22 11:26:01.117	\N
1626893020232156506	1626893020223767895	trash	\N	\N	\N	2025-10-22 11:26:01.117	\N
1626893020282488155	1626893020223767895	active	65536	TODO	\N	2025-10-22 11:26:01.122	\N
1626893020324431196	1626893020223767895	active	131072	READY	\N	2025-10-22 11:26:01.128	\N
1626893020383151453	1626893020223767895	active	196608	DOING	\N	2025-10-22 11:26:01.135	\N
1626893020433483102	1626893020223767895	active	262144	QA	\N	2025-10-22 11:26:01.141	\N
1626893020467037535	1626893020223767895	active	327680	BLOCKED	\N	2025-10-22 11:26:01.145	\N
1626893020517369184	1626893020223767895	active	393216	DONE	\N	2025-10-22 11:26:01.15	\N
1626978047682938249	1626978047573886343	archive	\N	\N	\N	2025-10-22 14:14:57.175	\N
1626978047691326858	1626978047573886343	trash	\N	\N	\N	2025-10-22 14:14:57.175	\N
1626978047909430667	1626978047573886343	active	65536	TODO	\N	2025-10-22 14:14:57.206	\N
1626978047993316748	1626978047573886343	active	131072	READY	\N	2025-10-22 14:14:57.216	\N
1626978048043648397	1626978047573886343	active	196608	DOING	\N	2025-10-22 14:14:57.222	\N
1626978048119145870	1626978047573886343	active	262144	QA	\N	2025-10-22 14:14:57.231	\N
1626978048177866127	1626978047573886343	active	327680	BLOCKED	\N	2025-10-22 14:14:57.237	\N
1626978048228197776	1626978047573886343	active	393216	DONE	\N	2025-10-22 14:14:57.244	\N
1626978048756680084	1626978048739902866	archive	\N	\N	\N	2025-10-22 14:14:57.306	\N
1626978048756680085	1626978048739902866	trash	\N	\N	\N	2025-10-22 14:14:57.306	\N
1626978048832177558	1626978048739902866	active	65536	TODO	\N	2025-10-22 14:14:57.316	\N
1626978048890897815	1626978048739902866	active	131072	READY	\N	2025-10-22 14:14:57.322	\N
1626978048949618072	1626978048739902866	active	196608	DOING	\N	2025-10-22 14:14:57.33	\N
1626978048999949721	1626978048739902866	active	262144	QA	\N	2025-10-22 14:14:57.336	\N
1626978049050281370	1626978048739902866	active	327680	BLOCKED	\N	2025-10-22 14:14:57.341	\N
1626978049083835803	1626978048739902866	active	393216	DONE	\N	2025-10-22 14:14:57.346	\N
1626978049595540895	1626978049587152285	archive	\N	\N	\N	2025-10-22 14:14:57.406	\N
1626978049595540896	1626978049587152285	trash	\N	\N	\N	2025-10-22 14:14:57.406	\N
1626978049645872545	1626978049587152285	active	65536	TODO	\N	2025-10-22 14:14:57.413	\N
1626978049704592802	1626978049587152285	active	131072	READY	\N	2025-10-22 14:14:57.42	\N
1626978049754924451	1626978049587152285	active	196608	DOING	\N	2025-10-22 14:14:57.426	\N
1626978049805256100	1626978049587152285	active	262144	QA	\N	2025-10-22 14:14:57.432	\N
1626978049855587749	1626978049587152285	active	327680	BLOCKED	\N	2025-10-22 14:14:57.438	\N
1626978049897530790	1626978049587152285	active	393216	DONE	\N	2025-10-22 14:14:57.443	\N
1626978050518287786	1626978050509899176	archive	\N	\N	\N	2025-10-22 14:14:57.517	\N
1626978050518287787	1626978050509899176	trash	\N	\N	\N	2025-10-22 14:14:57.517	\N
1626978050577008044	1626978050509899176	active	65536	TODO	\N	2025-10-22 14:14:57.524	\N
1626978050660894125	1626978050509899176	active	131072	READY	\N	2025-10-22 14:14:57.534	\N
1626978050769946030	1626978050509899176	active	196608	DOING	\N	2025-10-22 14:14:57.547	\N
1626978050820277679	1626978050509899176	active	262144	QA	\N	2025-10-22 14:14:57.553	\N
1626978050870609328	1626978050509899176	active	327680	BLOCKED	\N	2025-10-22 14:14:57.558	\N
1626978050904163761	1626978050509899176	active	393216	DONE	\N	2025-10-22 14:14:57.563	\N
1626995069946955223	1626995069921789397	archive	\N	\N	\N	2025-10-22 14:48:46.39	\N
1626995069946955224	1626995069921789397	trash	\N	\N	\N	2025-10-22 14:48:46.39	\N
1626995070014064089	1626995069921789397	active	65536	TODO	\N	2025-10-22 14:48:46.399	\N
1626995070097950170	1626995069921789397	active	131072	READY	\N	2025-10-22 14:48:46.408	\N
1626995070207002075	1626995069921789397	active	196608	DOING	\N	2025-10-22 14:48:46.422	\N
1626995070517380572	1626995069921789397	active	262144	QA	\N	2025-10-22 14:48:46.459	\N
1626995070634821085	1626995069921789397	active	327680	BLOCKED	\N	2025-10-22 14:48:46.472	\N
1626995070718707166	1626995069921789397	active	393216	DONE	\N	2025-10-22 14:48:46.483	\N
1626995071305909730	1626995071297521120	archive	\N	\N	\N	2025-10-22 14:48:46.553	\N
1626995071305909731	1626995071297521120	trash	\N	\N	\N	2025-10-22 14:48:46.553	\N
1626995071356241380	1626995071297521120	active	65536	TODO	\N	2025-10-22 14:48:46.559	\N
1626995071406573029	1626995071297521120	active	131072	READY	\N	2025-10-22 14:48:46.565	\N
1626995071448516070	1626995071297521120	active	196608	DOING	\N	2025-10-22 14:48:46.57	\N
1626995071515624935	1626995071297521120	active	262144	QA	\N	2025-10-22 14:48:46.578	\N
1626995071591122408	1626995071297521120	active	327680	BLOCKED	\N	2025-10-22 14:48:46.587	\N
1626995071641454057	1626995071297521120	active	393216	DONE	\N	2025-10-22 14:48:46.593	\N
1626995072144770541	1626995072127993323	archive	\N	\N	\N	2025-10-22 14:48:46.652	\N
1626995072144770542	1626995072127993323	trash	\N	\N	\N	2025-10-22 14:48:46.652	\N
1626995072186713583	1626995072127993323	active	65536	TODO	\N	2025-10-22 14:48:46.658	\N
1626995072228656624	1626995072127993323	active	131072	READY	\N	2025-10-22 14:48:46.663	\N
1626995072262211057	1626995072127993323	active	196608	DOING	\N	2025-10-22 14:48:46.667	\N
1626995072312542706	1626995072127993323	active	262144	QA	\N	2025-10-22 14:48:46.672	\N
1626995072346097139	1626995072127993323	active	327680	BLOCKED	\N	2025-10-22 14:48:46.677	\N
1626995072379651572	1626995072127993323	active	393216	DONE	\N	2025-10-22 14:48:46.681	\N
1626995072891356664	1626995072882968054	archive	\N	\N	\N	2025-10-22 14:48:46.742	\N
1626995072891356665	1626995072882968054	trash	\N	\N	\N	2025-10-22 14:48:46.742	\N
1626995072941688314	1626995072882968054	active	65536	TODO	\N	2025-10-22 14:48:46.748	\N
1626995072992019963	1626995072882968054	active	131072	READY	\N	2025-10-22 14:48:46.754	\N
1626995073084294652	1626995072882968054	active	196608	DOING	\N	2025-10-22 14:48:46.765	\N
1626995073126237693	1626995072882968054	active	262144	QA	\N	2025-10-22 14:48:46.77	\N
1626995073168180734	1626995072882968054	active	327680	BLOCKED	\N	2025-10-22 14:48:46.775	\N
1626995073210123775	1626995072882968054	active	393216	DONE	\N	2025-10-22 14:48:46.78	\N
1627092979632047654	1627092979598493220	archive	\N	\N	\N	2025-10-22 18:03:18.135	\N
1627092979648824871	1627092979598493220	trash	\N	\N	\N	2025-10-22 18:03:18.135	\N
1627092979724322344	1627092979598493220	active	65536	TODO	\N	2025-10-22 18:03:18.145	\N
1627092979808208425	1627092979598493220	active	131072	READY	\N	2025-10-22 18:03:18.156	\N
1627092979875317290	1627092979598493220	active	196608	DOING	\N	2025-10-22 18:03:18.164	\N
1627092979950814763	1627092979598493220	active	262144	QA	\N	2025-10-22 18:03:18.173	\N
1627092980026312236	1627092979598493220	active	327680	BLOCKED	\N	2025-10-22 18:03:18.181	\N
1627092980168918573	1627092979598493220	active	393216	DONE	\N	2025-10-22 18:03:18.199	\N
1627092980764509745	1627092980756121135	archive	\N	\N	\N	2025-10-22 18:03:18.27	\N
1627092980764509746	1627092980756121135	trash	\N	\N	\N	2025-10-22 18:03:18.27	\N
1627092980814841395	1627092980756121135	active	65536	TODO	\N	2025-10-22 18:03:18.275	\N
1627092980881950260	1627092980756121135	active	131072	READY	\N	2025-10-22 18:03:18.283	\N
1627092980932281909	1627092980756121135	active	196608	DOING	\N	2025-10-22 18:03:18.29	\N
1627092980991002166	1627092980756121135	active	262144	QA	\N	2025-10-22 18:03:18.297	\N
1627092981058111031	1627092980756121135	active	327680	BLOCKED	\N	2025-10-22 18:03:18.305	\N
1627092981125219896	1627092980756121135	active	393216	DONE	\N	2025-10-22 18:03:18.312	\N
1627092981662090812	1627092981636924986	archive	\N	\N	\N	2025-10-22 18:03:18.376	\N
1627092981662090813	1627092981636924986	trash	\N	\N	\N	2025-10-22 18:03:18.376	\N
1627092981704033854	1627092981636924986	active	65536	TODO	\N	2025-10-22 18:03:18.382	\N
1627092981821474367	1627092981636924986	active	131072	READY	\N	2025-10-22 18:03:18.395	\N
1627092981922137664	1627092981636924986	active	196608	DOING	\N	2025-10-22 18:03:18.407	\N
1627092981989246529	1627092981636924986	active	262144	QA	\N	2025-10-22 18:03:18.416	\N
1627092982047966786	1627092981636924986	active	327680	BLOCKED	\N	2025-10-22 18:03:18.423	\N
1627092982115075651	1627092981636924986	active	393216	DONE	\N	2025-10-22 18:03:18.43	\N
1627092982626780743	1627092982618392133	archive	\N	\N	\N	2025-10-22 18:03:18.492	\N
1627092982626780744	1627092982618392133	trash	\N	\N	\N	2025-10-22 18:03:18.492	\N
1627092982685501001	1627092982618392133	active	65536	TODO	\N	2025-10-22 18:03:18.499	\N
1627092982744221258	1627092982618392133	active	131072	READY	\N	2025-10-22 18:03:18.506	\N
1627092982802941515	1627092982618392133	active	196608	DOING	\N	2025-10-22 18:03:18.513	\N
1627092982870050380	1627092982618392133	active	262144	QA	\N	2025-10-22 18:03:18.52	\N
1627092982928770637	1627092982618392133	active	327680	BLOCKED	\N	2025-10-22 18:03:18.528	\N
1627092982979102286	1627092982618392133	active	393216	DONE	\N	2025-10-22 18:03:18.534	\N
1636194980693280554	1636194980651337512	archive	\N	\N	\N	2025-11-04 07:27:21.214	\N
1636194980701669163	1636194980651337512	trash	\N	\N	\N	2025-11-04 07:27:21.214	\N
1636362671676720946	1636362671643166512	archive	\N	\N	\N	2025-11-04 13:00:31.537	\N
1636362671685109555	1636362671643166512	trash	\N	\N	\N	2025-11-04 13:00:31.537	\N
1636366528683181882	1636366528658016056	archive	\N	\N	\N	2025-11-04 13:08:11.328	\N
1636366528683181883	1636366528658016056	trash	\N	\N	\N	2025-11-04 13:08:11.328	\N
1636618543615182682	1636618543556462424	archive	\N	\N	\N	2025-11-04 21:28:53.848	\N
1636618543615182683	1636618543556462424	trash	\N	\N	\N	2025-11-04 21:28:53.848	\N
1636621052412954466	1636621052396177248	archive	\N	\N	\N	2025-11-04 21:33:52.922	\N
1636621052421343075	1636621052396177248	trash	\N	\N	\N	2025-11-04 21:33:52.922	\N
1636622653286516586	1636622653269739368	archive	\N	\N	\N	2025-11-04 21:37:03.761	\N
1636622653294905195	1636622653269739368	trash	\N	\N	\N	2025-11-04 21:37:03.761	\N
1636622653974382445	1636622653269739368	active	16384	TODO	\N	2025-11-04 21:37:03.843	\N
1636624465511057268	1636624465494280050	archive	\N	\N	\N	2025-11-04 21:40:39.795	\N
1636624465511057269	1636624465494280050	trash	\N	\N	\N	2025-11-04 21:40:39.795	\N
1636624466509301623	1636624465494280050	active	16384	TODO	\N	2025-11-04 21:40:39.914	\N
1636624466635130744	1636624465494280050	active	1	READY	\N	2025-11-04 21:40:39.929	\N
1636624466702239609	1636624465494280050	active	2	DOING	\N	2025-11-04 21:40:39.937	\N
1636624466760959866	1636624465494280050	active	3	QA	\N	2025-11-04 21:40:39.944	\N
1636624466819680123	1636624465494280050	active	4	BLOCKED	\N	2025-11-04 21:40:39.951	\N
1636624466870011772	1636624465494280050	active	5	DONE	\N	2025-11-04 21:40:39.957	\N
1636626842381191064	1636626842364413846	archive	\N	\N	\N	2025-11-04 21:45:23.139	\N
1636626842381191065	1636626842364413846	trash	\N	\N	\N	2025-11-04 21:45:23.139	\N
1636626843127777179	1636626842364413846	active	16384	TODO	\N	2025-11-04 21:45:23.229	\N
1636626843220051868	1636626842364413846	active	1	READY	\N	2025-11-04 21:45:23.239	\N
1636626843278772125	1636626842364413846	active	2	DOING	\N	2025-11-04 21:45:23.246	\N
1636626843329103774	1636626842364413846	active	3	QA	\N	2025-11-04 21:45:23.253	\N
1636626843387824031	1636626842364413846	active	4	BLOCKED	\N	2025-11-04 21:45:23.26	\N
1636626843438155680	1636626842364413846	active	5	DONE	\N	2025-11-04 21:45:23.266	\N
1636629173239809960	1636629173223032742	archive	\N	\N	\N	2025-11-04 21:50:01	\N
1636629173239809961	1636629173223032742	trash	\N	\N	\N	2025-11-04 21:50:01	\N
1636629173902509995	1636629173223032742	active	16384	TODO	\N	2025-11-04 21:50:01.078	\N
1636629174011561900	1636629173223032742	active	1	READY	\N	2025-11-04 21:50:01.092	\N
1636629174070282157	1636629173223032742	active	2	DOING	\N	2025-11-04 21:50:01.098	\N
1636629174137391022	1636629173223032742	active	3	QA	\N	2025-11-04 21:50:01.106	\N
1636629174187722671	1636629173223032742	active	4	BLOCKED	\N	2025-11-04 21:50:01.113	\N
1636629174263220144	1636629173223032742	active	5	DONE	\N	2025-11-04 21:50:01.122	\N
1636635392033687500	1636635392016910282	archive	\N	\N	\N	2025-11-04 22:02:22.338	\N
1636635392033687501	1636635392016910282	trash	\N	\N	\N	2025-11-04 22:02:22.338	\N
1636635392679610319	1636635392016910282	active	16384	TODO	\N	2025-11-04 22:02:22.415	\N
1636635392822216656	1636635392016910282	active	1	READY	\N	2025-11-04 22:02:22.431	\N
1636635392897714129	1636635392016910282	active	2	DOING	\N	2025-11-04 22:02:22.441	\N
1636635392964822994	1636635392016910282	active	3	QA	\N	2025-11-04 22:02:22.449	\N
1636635393040320467	1636635392016910282	active	4	BLOCKED	\N	2025-11-04 22:02:22.458	\N
1636635393115817940	1636635392016910282	active	5	DONE	\N	2025-11-04 22:02:22.466	\N
1636639387938719728	1636639387921942510	archive	\N	\N	\N	2025-11-04 22:10:18.687	\N
1636639387947108337	1636639387921942510	trash	\N	\N	\N	2025-11-04 22:10:18.687	\N
1636639388609808371	1636639387921942510	active	16384	TODO	\N	2025-11-04 22:10:18.766	\N
1636639388769191924	1636639387921942510	active	1	READY	\N	2025-11-04 22:10:18.785	\N
1636639388827912181	1636639387921942510	active	2	DOING	\N	2025-11-04 22:10:18.793	\N
1636639388895021046	1636639387921942510	active	3	QA	\N	2025-11-04 22:10:18.801	\N
1636639388953741303	1636639387921942510	active	4	BLOCKED	\N	2025-11-04 22:10:18.808	\N
1636639389004072952	1636639387921942510	active	5	DONE	\N	2025-11-04 22:10:18.814	\N
1637150314312238105	1637150314186408983	archive	\N	\N	\N	2025-11-05 15:05:25.851	\N
1637150314320626714	1637150314186408983	trash	\N	\N	\N	2025-11-05 15:05:25.851	\N
1637150620655813663	1637150620622259229	archive	\N	\N	\N	2025-11-05 15:06:02.375	\N
1637150620655813664	1637150620622259229	trash	\N	\N	\N	2025-11-05 15:06:02.375	\N
1637150620823585825	1637150620622259229	active	16384	Backlog	\N	2025-11-05 15:06:02.396	\N
1637150620932637730	1637150620622259229	active	1	To Do	\N	2025-11-05 15:06:02.409	\N
1637150621016523811	1637150620622259229	active	2	Doing	\N	2025-11-05 15:06:02.418	\N
1637150621075244068	1637150620622259229	active	3	Review	\N	2025-11-05 15:06:02.426	\N
1637150621159130149	1637150620622259229	active	4	Done	\N	2025-11-05 15:06:02.435	\N
1637150621209461798	1637150620622259229	closed	5	Archived	\N	2025-11-05 15:06:02.442	\N
1637150844363211819	1637150844338045993	archive	\N	\N	\N	2025-11-05 15:06:29.043	\N
1637150844363211820	1637150844338045993	trash	\N	\N	\N	2025-11-05 15:06:29.043	\N
1637150844438709293	1637150844338045993	active	16384	Backlog	\N	2025-11-05 15:06:29.052	\N
1637150844489040942	1637150844338045993	active	1	To Do	\N	2025-11-05 15:06:29.059	\N
1637150844547761199	1637150844338045993	active	2	Doing	\N	2025-11-05 15:06:29.065	\N
1637150844598092848	1637150844338045993	active	3	Review	\N	2025-11-05 15:06:29.072	\N
1637150844673590321	1637150844338045993	active	4	Done	\N	2025-11-05 15:06:29.08	\N
1637150844723921970	1637150844338045993	closed	5	Archived	\N	2025-11-05 15:06:29.086	\N
1639163934894195807	1639163934877418589	archive	\N	\N	\N	2025-11-08 09:46:08.136	\N
1639163934894195808	1639163934877418589	trash	\N	\N	\N	2025-11-08 09:46:08.136	\N
\.


--
-- Data for Name: migration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migration (id, name, batch, migration_time) FROM stdin;
1	20250228000022_version_2.js	1	2025-07-22 13:35:14.35+00
2	20250522151122_add_board_activity_log.js	1	2025-07-22 13:35:14.352+00
3	20250523131647_add_comments_counter.js	1	2025-07-22 13:35:14.353+00
4	20250603102521_canonicalize_locale_codes.js	1	2025-07-22 13:35:14.354+00
5	20250703122452_move_webhooks_configuration_from_environment_variable_to_ui.js	2	2025-11-07 08:29:22.424+00
6	20250708200908_persist_closed_state_per_card.js	2	2025-11-07 08:29:22.447+00
7	20250709160208_add_ability_to_link_tasks_to_cards.js	2	2025-11-07 08:29:22.45+00
8	20250721132312_add_ability_to_hide_completed_tasks.js	2	2025-11-07 08:29:22.454+00
9	20250728105713_add_legal_requirements.js	2	2025-11-07 08:29:22.469+00
10	20250820144730_track_storage_usage.js	2	2025-11-07 08:29:22.489+00
11	20250905101408_restore_toggleable_due_dates.js	2	2025-11-07 08:29:22.49+00
12	20250905205438_add_board_setting_to_expand_task_lists_by_default.js	2	2025-11-07 08:29:22.491+00
13	20250917123048_add_ability_to_configure_smtp_via_ui.js	2	2025-11-07 08:29:22.494+00
14	20251105104948_add_api_key_authentication.js	2	2025-11-07 08:29:22.496+00
\.


--
-- Data for Name: migration_lock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migration_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification (id, user_id, creator_user_id, board_id, card_id, comment_id, action_id, type, data, is_read, created_at, updated_at) FROM stdin;
1626890448008119599	1560328737491256325	1560328737491256322	1626139471911061302	1626139517612197737	\N	1626890447974565166	addMemberToCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "user": {"id": "1560328737491256325", "name": "Meta Agent"}}	f	2025-10-22 11:20:54.484	\N
1634801900475909841	1560328737491256322	1560328737491256322	1573201068874008314	1627548744566179439	1634801900140365520	\N	mentionInComment	{"card": {"name": "fwe"}, "text": "@[admin_agent](1560328737491256322) hi"}	t	2025-11-02 09:19:33.112	2025-11-02 09:19:33.133
1634802288725853909	1560328737491256322	1560328737491256323	1573201068874008314	1627548744566179439	1634802288608413396	\N	mentionInComment	{"card": {"name": "fwe"}, "text": "@[admin_agent](1560328737491256322) you"}	t	2025-11-02 09:20:19.395	2025-11-02 09:20:29.296
\.


--
-- Data for Name: notification_service; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_service (id, user_id, board_id, url, format, created_at, updated_at) FROM stdin;
1565999542187328521	1560278692305830913	\N	json://mini2.local:8634/api/v1/flow-events/webhook	markdown	2025-07-30 11:01:32.859	\N
1566022531410822231	\N	1541385320996537361	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:13.388652	2025-07-30 12:08:07.365
1566022531410822232	\N	1541386488111957023	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:13.388652	2025-07-30 12:08:15.742
1566022531410822233	\N	1541386853553275948	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:13.388652	2025-07-30 12:08:23.596
1566033706831840358	\N	1566019210167977028	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 12:09:25.602	\N
1566033750276441191	\N	1566019210167977027	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 12:09:30.782	\N
1566033792991233128	\N	1565999911277691916	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 12:09:35.874	\N
1566022633139471450	\N	1565999911277691916	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:25.515868	2025-07-30 11:47:25.515868
1566022633139471451	\N	1566019210167977027	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:25.515868	2025-07-30 11:47:25.515868
1566022633139471452	\N	1566019210167977028	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:25.515868	2025-07-30 11:47:25.515868
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project (id, owner_project_manager_id, background_image_id, name, description, background_type, background_gradient, is_hidden, created_at, updated_at) FROM stdin;
1573201067548608248	\N	\N	Core Repository - Rearchitecture	\N	\N	\N	f	2025-08-09 09:29:41.572	\N
1626139469679691560	\N	\N	enterprise_mcp_server	\N	\N	\N	f	2025-10-21 10:28:50.891	\N
1626143867390658435	\N	\N	enterprise_mcp_server	\N	\N	\N	f	2025-10-21 10:37:35.139	\N
1626762336809256926	\N	\N	enterprise_mcp_server	\N	\N	\N	f	2025-10-22 07:06:22.438	\N
1626777062339511357	\N	\N	enterprise_mcp_server	\N	\N	\N	f	2025-10-22 07:35:37.858	\N
1626840254537270411	\N	\N	enterprise_mcp_server	\N	\N	\N	f	2025-10-22 09:41:10.955	\N
1626853198436238555	\N	\N	enterprise_mcp_server	\N	\N	\N	f	2025-10-22 10:06:53.988	\N
1626893016977376563	\N	\N	enterprise_mcp_server	\N	\N	\N	f	2025-10-22 11:26:00.728	\N
1626978046776968580	\N	\N	enterprise_mcp_server	\N	\N	\N	f	2025-10-22 14:14:57.071	\N
1626995069301032402	\N	\N	enterprise_mcp_server	\N	\N	\N	f	2025-10-22 14:48:46.314	\N
1627092978960959009	\N	\N	enterprise_mcp_server	\N	\N	\N	f	2025-10-22 18:03:18.054	\N
1636194979720202021	1636194979728590630	\N	MLX Inference Analysis	\N	\N	\N	f	2025-11-04 07:27:21.099	2025-11-04 07:27:21.102
1636362670510704429	1636362670535870254	\N	mvp_test	\N	\N	\N	f	2025-11-04 13:00:31.399	2025-11-04 13:00:31.405
1636366527785600821	1636366527793989430	\N	mvp_test	\N	\N	\N	f	2025-11-04 13:08:11.222	2025-11-04 13:08:11.225
1636423058925291326	1636423058933679935	\N	mvp_test	\N	\N	\N	f	2025-11-04 15:00:30.259	2025-11-04 15:00:30.262
1636543759116142404	1636543759124531013	\N	mvp_test	\N	\N	\N	f	2025-11-04 19:00:18.842	2025-11-04 19:00:18.849
1636582546923849551	1636582546940626768	\N	mvp_test	\N	\N	\N	f	2025-11-04 20:17:22.709	2025-11-04 20:17:22.715
1636602006615361362	1636602006623749971	\N	mvp_test	\N	\N	\N	f	2025-11-04 20:56:02.484	2025-11-04 20:56:02.489
1636618542491109205	1636618542507886422	\N	mvp_test	\N	\N	\N	f	2025-11-04 21:28:53.715	2025-11-04 21:28:53.719
1636621051465041757	1636621051481818974	\N	mvp_test	\N	\N	\N	f	2025-11-04 21:33:52.808	2025-11-04 21:33:52.816
1636622652372158309	1636622652388935526	\N	mvp_test	\N	\N	\N	f	2025-11-04 21:37:03.652	2025-11-04 21:37:03.655
1636624464672196463	1636624464672196464	\N	mvp_test	\N	\N	\N	f	2025-11-04 21:40:39.694	2025-11-04 21:40:39.697
1636626841559107475	1636626841559107476	\N	mvp_test	\N	\N	\N	f	2025-11-04 21:45:23.041	2025-11-04 21:45:23.044
1636629172367394723	1636629172384171940	\N	mvp_test	\N	\N	\N	f	2025-11-04 21:50:00.895	2025-11-04 21:50:00.9
1636635391161272263	1636635391169660872	\N	mvp_test	\N	\N	\N	f	2025-11-04 22:02:22.234	2025-11-04 22:02:22.237
1636639387116636139	1636639387141801964	\N	mvp_test	\N	\N	\N	f	2025-11-04 22:10:18.589	2025-11-04 22:10:18.595
1637150031993635857	1637150032010413074	\N	Test MVP Project	Testing project_setup_flow - Layer 2 business flow	\N	\N	f	2025-11-05 15:04:52.199	2025-11-05 15:04:52.206
1637150110125130771	1637150110133519380	\N	Debug Test Project 1762355101503	\N	\N	\N	f	2025-11-05 15:05:01.516	2025-11-05 15:05:01.518
1637150313783755797	1637150313800533014	\N	MVP Test Project	First complete Layer 2 flow test!	\N	\N	f	2025-11-05 15:05:25.789	2025-11-05 15:05:25.799
1637150620479652891	1637150620496430108	\N	MVP Complete Test	First successful Layer 2 project_setup_flow!	\N	\N	f	2025-11-05 15:06:02.351	2025-11-05 15:06:02.358
1637150844245771303	1637150844245771304	\N	🎉 MVP Success!	First complete Layer 2 project_setup_flow execution!	\N	\N	f	2025-11-05 15:06:29.028	2025-11-05 15:06:29.032
1639163934332159065	1639163934348936282	\N	n8n Test Project	Integration testing	\N	\N	f	2025-11-08 09:46:08.064	2025-11-08 09:46:08.073
1639163934625760347	1639163934634148956	\N	n8n Test Project	\N	\N	\N	f	2025-11-08 09:46:08.103	2025-11-08 09:46:08.105
\.


--
-- Data for Name: project_favorite; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_favorite (id, project_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project_manager; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_manager (id, project_id, user_id, created_at, updated_at) FROM stdin;
1573201067573774073	1573201067548608248	1560328737491256322	2025-08-09 09:29:41.586	\N
1626139469688080169	1626139469679691560	1560328737491256322	2025-10-21 10:28:50.892	\N
1626143867407435652	1626143867390658435	1560328737491256322	2025-10-21 10:37:35.14	\N
1626762336826034143	1626762336809256926	1560328737491256322	2025-10-22 07:06:22.44	\N
1626777062347899966	1626777062339511357	1560328737491256322	2025-10-22 07:35:37.86	\N
1626840254570824844	1626840254537270411	1560328737491256322	2025-10-22 09:41:10.957	\N
1626853198444627164	1626853198436238555	1560328737491256322	2025-10-22 10:06:53.99	\N
1626893016985765172	1626893016977376563	1560328737491256322	2025-10-22 11:26:00.729	\N
1626978046793745797	1626978046776968580	1560328737491256322	2025-10-22 14:14:57.072	\N
1626995069309421011	1626995069301032402	1560328737491256322	2025-10-22 14:48:46.315	\N
1627092978960959010	1627092978960959009	1560328737491256322	2025-10-22 18:03:18.055	\N
1636194979728590630	1636194979720202021	1560328737491256322	2025-11-04 07:27:21.1	\N
1636362670535870254	1636362670510704429	1560328737491256322	2025-11-04 13:00:31.401	\N
1636366527793989430	1636366527785600821	1560328737491256322	2025-11-04 13:08:11.223	\N
1636423058933679935	1636423058925291326	1560328737491256322	2025-11-04 15:00:30.26	\N
1636543759124531013	1636543759116142404	1560328737491256322	2025-11-04 19:00:18.844	\N
1636582546940626768	1636582546923849551	1560328737491256322	2025-11-04 20:17:22.711	\N
1636602006623749971	1636602006615361362	1560328737491256322	2025-11-04 20:56:02.487	\N
1636618542507886422	1636618542491109205	1560328737491256322	2025-11-04 21:28:53.717	\N
1636621051481818974	1636621051465041757	1560328737491256322	2025-11-04 21:33:52.811	\N
1636622652388935526	1636622652372158309	1560328737491256322	2025-11-04 21:37:03.653	\N
1636624464672196464	1636624464672196463	1560328737491256322	2025-11-04 21:40:39.695	\N
1636626841559107476	1636626841559107475	1560328737491256322	2025-11-04 21:45:23.042	\N
1636629172384171940	1636629172367394723	1560328737491256322	2025-11-04 21:50:00.897	\N
1636635391169660872	1636635391161272263	1560328737491256322	2025-11-04 22:02:22.235	\N
1636639387141801964	1636639387116636139	1560328737491256322	2025-11-04 22:10:18.59	\N
1637150032010413074	1637150031993635857	1560328737491256322	2025-11-05 15:04:52.204	\N
1637150110133519380	1637150110125130771	1560328737491256322	2025-11-05 15:05:01.517	\N
1637150313800533014	1637150313783755797	1560328737491256322	2025-11-05 15:05:25.796	\N
1637150620496430108	1637150620479652891	1560328737491256322	2025-11-05 15:06:02.356	\N
1637150844245771304	1637150844245771303	1560328737491256322	2025-11-05 15:06:29.03	\N
1639163934348936282	1639163934332159065	1560328737491256322	2025-11-08 09:46:08.07	\N
1639163934634148956	1639163934625760347	1560328737491256322	2025-11-08 09:46:08.104	\N
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session (id, user_id, access_token, http_only_token, remote_address, user_agent, created_at, updated_at, deleted_at, pending_token) FROM stdin;
1565996599279092742	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImIxMDJmZjE3LWU4MjgtNDJhZC05ZDk4LTVlMDFmNjgxNWY4ZiJ9.eyJpYXQiOjE3NTM4NzI5NDIsImV4cCI6MTc4NTQwODk0Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ml3BmWfjj03jomVI2uJdJLlqj8F2fIQkuT5c6CBtNLA	b153c63b-4562-49ca-8cee-2727a4dc051d	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 10:55:42.036	2025-07-30 11:00:11.817	2025-07-30 11:00:11.816	\N
1565998904820892680	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjE3ZDFhYTk1LTM1MmUtNDMwNS04NjZjLTdmMjA0MTY1MjU4ZCJ9.eyJpYXQiOjE3NTM4NzMyMTYsImV4cCI6MTc4NTQwOTIxNiwic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.wxOtFDkb6tEuB-e-G87QBgIFe98EKxESq2uc6vxbvdU	6bfaa4a3-4721-4086-ba63-b0cab1c19a18	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:00:16.878	2025-07-30 11:11:25.3	2025-07-30 11:11:25.298	\N
1566004531731366934	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjBmYmM0ODk2LTI4MWYtNDViOC04NzAyLTNmMGIyMGM4Y2RiZiJ9.eyJpYXQiOjE3NTM4NzM4ODcsImV4cCI6MTc4NTQwOTg4Nywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.8DAHLMniUdCG8eMZkrVi6xM6P0vbTmcx8LYuLbSKAmU	c8d09b71-a2f6-4a6f-927c-fd894eeda38b	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:11:27.659	2025-07-30 11:23:34.744	2025-07-30 11:23:34.743	\N
1566010658535769148	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjkxODMwNWZmLWMzYzMtNDkxMy05YmJkLWZhODkwYWQ0N2UxMiJ9.eyJpYXQiOjE3NTM4NzQ2MTgsImV4cCI6MTc4NTQxMDYxOCwic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.TM6KEQJQBuXsZ7ffjVjcRKrFcArXVaelDHBjgVuxunI	606003c2-c924-4b8f-bae4-f45c63da76ff	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:23:38.032	2025-07-30 11:29:54.912	2025-07-30 11:29:54.91	\N
1634801807093925583	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImUwOWNmMDVkLTY3MTctNGNkYy05MWMxLWNhMjI5MzViODliNyJ9.eyJpYXQiOjE3NjIwNzUxNjEsImV4cCI6NDkxNTY3NTE2MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ioMN0sQftO0EiaNssOllAmuKAejAYb4yJUK_vDyQRt4	3ee4b2cd-07b7-4287-bb47-2c1e587007ba	172.18.0.20	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-11-02 09:19:21.932	2025-11-02 09:19:48.779	2025-11-02 09:19:48.778	\N
1634802098757437139	1560328737491256323	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjIzZTRiODVlLWJlMDgtNDc2Yi1iMmUyLTdlYTkxZDQ0OGEwNSJ9.eyJpYXQiOjE3NjIwNzUxOTYsImV4cCI6NDkxNTY3NTE5Niwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMyJ9.ZeZFTik0r-aL6H_YOPrYOKbOvxIBrabJ0ujV0U2PVpQ	c1aa9a8a-c909-49a2-a11e-2a69aa445f76	172.18.0.20	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-11-02 09:19:56.748	2025-11-02 09:20:24.938	2025-11-02 09:20:24.935	\N
1626995069854680532	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjY0ZmI3ZDliLTA4M2UtNGNiMC1hMjAzLTYzMTQ2NmZjMmQ4NyJ9.eyJpYXQiOjE3NjExNDQ1MjYsImV4cCI6NDkxNDc0NDUyNiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Zbpl10pcpxdHUl-BBCrUqISoEXpA_TwYvKQ0TRMBPeo	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 14:48:46.379	\N	2025-11-07 08:29:22.465	\N
1630689136950118091	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjkwMTY1MjI0LTY3NzAtNDA2NC1iMTJiLWJlZTk5MGVlMWU0MSJ9.eyJpYXQiOjE3NjE1ODQ4OTMsImV4cCI6NDkxNTE4NDg5Mywic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.hxknv2Lfbx94zYtV4H7O5dLC8OsebMLABkZBfPBTOf0	cd69872a-24fb-4b0b-bb89-492be2106a26	172.18.0.20	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 OPR/122.0.0.0	2025-10-27 17:08:13.491	2025-11-06 11:39:29.56	2025-11-06 11:39:29.559	\N
1560294586092356611	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjAzN2Y4YjIyLTU0YzMtNDVhMi04Mzk2LTM2N2FiZWI0M2U2YiJ9.eyJpYXQiOjE3NTMxOTMyMDksImV4cCI6MTc4NDcyOTIwOSwic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.B9YaJbWEbGLo5wG6UuGgeFKDtcixTiCLeCQ0Z462oIs	fcd4dc85-2b9d-4125-81bb-1f21c400d3c6	151.101.128.223	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 14:06:49.095	\N	2025-11-07 08:29:22.465	\N
1560328737491256326	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjllZDg4ODgzLWI0Y2MtNDI0NS1iOTZjLTVkZWZmZTk0ZTg1YSJ9.eyJpYXQiOjE3NTM4NzI2ODMsImV4cCI6MTc4NTQwODY4Mywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.q02RBVLTM2Ald69pfn8xBcUCATBdqAFcFP-ndN-_hF4	\N	127.0.0.1	API Client	2025-07-30 10:51:29.898679	2025-07-30 10:51:29.898679	2025-11-07 08:29:22.465	\N
1566013844503921729	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjcyZmQyYzM1LWVhNjItNDZkYy1iYjA4LTk2MDgzOTUyYmFkMCJ9.eyJpYXQiOjE3NTM4NzQ5OTcsImV4cCI6MTc4NTQxMDk5Nywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Ut1GIjkn2kdZ_OFTubbZTlm7VWgfrycsHTGkORENfXs	49686d2f-d3b0-4688-8979-9ee345e3db01	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:29:57.829	\N	2025-11-07 08:29:22.465	\N
1572105354811016308	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQzYWMyMTcxLTQ0YmEtNDQ0Yi05YzU0LTVhYzU5NDMzY2Y2YSJ9.eyJpYXQiOjE3NTQ2MDExNjIsImV4cCI6MTc4NjEzNzE2Miwic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.wqarkYGmWGchfdqW2CCtNpDL4JXLYAPL4SkDN6ryTnE	019fe815-6f03-496c-ac49-6cab12d4014e	142.250.179.187	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15	2025-08-07 21:12:42.443	\N	2025-11-07 08:29:22.465	\N
1572120589982762101	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg2M2FiMDMwLTUwZjEtNDJmNy1iYTUyLTU3MmEzMzUwMzJkYSJ9.eyJpYXQiOjE3NTQ2MDI5NzgsImV4cCI6MTc4NjEzODk3OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.hIi2r_oad-oBu-zclw2ZvaxaS0W11NLeorH-cKTSJY8	\N	142.250.179.187	Python-urllib/3.13	2025-08-07 21:42:58.618	\N	2025-11-07 08:29:22.465	\N
1572120638863180918	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjY0Y2YxMDM5LTQ3YTAtNDgwNC1iNWE4LWNjZGNmOTgzODdlZSJ9.eyJpYXQiOjE3NTQ2MDI5ODQsImV4cCI6MTc4NjEzODk4NCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Yuq7g116ACd5kml5HP0ayS9FiniAig3gUSC2-gerVE4	\N	142.250.179.187	Python-urllib/3.13	2025-08-07 21:43:04.447	\N	2025-11-07 08:29:22.465	\N
1572120709486871671	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImQ3YzIyOTQxLTkyYTQtNDA4NC1iYTc4LWMxNTVmOTE1ZWYzMSJ9.eyJpYXQiOjE3NTQ2MDI5OTIsImV4cCI6MTc4NjEzODk5Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.e-vOn0G3GnL7PS98X8qmv0QusZxIk1fi_oXHW7fa3WM	\N	142.250.179.187	Python-urllib/3.13	2025-08-07 21:43:12.866	\N	2025-11-07 08:29:22.465	\N
1572120946196612216	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQyM2MzYjlkLTNmZGItNDZhYS04NDc0LTJlNzBlMjJiNTNhYiJ9.eyJpYXQiOjE3NTQ2MDMwMjEsImV4cCI6MTc4NjEzOTAyMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.LmOR5Htz6wICxT-Ek1aRWKUS6YkSIZqrtFmt7WcDV5k	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:43:41.082	\N	2025-11-07 08:29:22.465	\N
1572121045853275257	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg4OTQ3NGI0LTRmODctNDdhMi04YzUzLTZhMWZmMzQ4NzY4NyJ9.eyJpYXQiOjE3NTQ2MDMwMzIsImV4cCI6MTc4NjEzOTAzMiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Os9ISwVNBNLUjGJE29ZKBh30-KZkxoBqxM7Y07lg8dI	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:43:52.963	\N	2025-11-07 08:29:22.465	\N
1572121901784892538	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjI3NGQxNzJkLTA2ZTktNDA4Zi05ZWIxLWFhODAxZTRkMWI5YiJ9.eyJpYXQiOjE3NTQ2MDMxMzQsImV4cCI6MTc4NjEzOTEzNCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.qqoOOaAnQXVUv_Szc4r9WMa0fN-jC18zZl0QdCQyEXc	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:45:34.998	\N	2025-11-07 08:29:22.465	\N
1572122394867270779	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImU4YjM1OWZkLTk4Y2ItNGUyMy05NjU0LTM1MDUyMTBmZTBmNSJ9.eyJpYXQiOjE3NTQ2MDMxOTMsImV4cCI6MTc4NjEzOTE5Mywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.46DwZc1MK9h2tD2wBgE-nOADpdG9w-Zu7IY4_ZdsMIk	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:46:33.778	\N	2025-11-07 08:29:22.465	\N
1572122796731925628	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjE0YTMzM2YzLTI2NTgtNDAyYy05Y2Q4LTFmZjRiNGZlOTM3OSJ9.eyJpYXQiOjE3NTQ2MDMyNDEsImV4cCI6MTc4NjEzOTI0MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.2lAOwYbTlPAZS3K6D6qhpe9h2xX7ffgg1VzOIciD2Bw	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:47:21.683	\N	2025-11-07 08:29:22.465	\N
1572123028853097599	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjFkNWFmMzBmLTM1YzAtNGZiNy1iY2EwLWE5YzczNDg1YzQ3OCJ9.eyJpYXQiOjE3NTQ2MDMyNjksImV4cCI6MTc4NjEzOTI2OSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.37eztz7Z_VmsL8CNsvm_-Qr80vXvglVlVZtc7S90RZI	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:47:49.355	\N	2025-11-07 08:29:22.465	\N
1572130827263804546	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjJjM2VkODc2LTJkNmMtNDAwNi04MWFkLWExMTEyZmM0NjM5OCJ9.eyJpYXQiOjE3NTQ2MDQxOTgsImV4cCI6MTc4NjE0MDE5OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.4rSidu_0MEvWHb36QnCIESkr0urZO4ZYw2J8472hXRU	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:03:18.996	\N	2025-11-07 08:29:22.465	\N
1572131155786859665	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjVmZjA1NzY0LTk0ZTQtNGExNi1hNjBhLWI0OWYzNzFhY2YwNSJ9.eyJpYXQiOjE3NTQ2MDQyMzgsImV4cCI6MTc4NjE0MDIzOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.cIifhdg3RiuPw7BSOdLRKqm4903UZt7OqOOGoVhCU6w	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:03:58.161	\N	2025-11-07 08:29:22.465	\N
1572131313291363488	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjlhZGU5YjQ0LTkyM2MtNDNiYi1hYzczLTE2ZmFiZDkyNGMyMiJ9.eyJpYXQiOjE3NTQ2MDQyNTYsImV4cCI6MTc4NjE0MDI1Niwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.9jrwy4HYjcfDmV3jBvQLhrEROKzo5GWvii12RA8bmQo	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:04:16.937	\N	2025-11-07 08:29:22.465	\N
1572131367280444591	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImVhNmYyZDNlLTk4ZGUtNDg4ZC04ODhkLWFhMDhjMGUyZGI0NiJ9.eyJpYXQiOjE3NTQ2MDQyNjMsImV4cCI6MTc4NjE0MDI2Mywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Lb110Bgwgd-uvPpHOBj8d2JftFhUwaLg-AuUmdnm3bI	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:04:23.374	\N	2025-11-07 08:29:22.465	\N
1572131515842692286	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjllZTRkZjc5LTZlODAtNGFhNC04OGRlLWE3MWZlM2RkYjBiOCJ9.eyJpYXQiOjE3NTQ2MDQyODEsImV4cCI6MTc4NjE0MDI4MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.7t0D8fRszB2hRqnlo2HV_n0A65YB-BpTy-AzwIt7zWY	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:04:41.082	\N	2025-11-07 08:29:22.465	\N
1572132139728635103	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImFjMmM4Yzc1LTU1YTUtNDUzZi05NTg1LTVmYmRlYWM5Y2Q4MCJ9.eyJpYXQiOjE3NTQ2MDQzNTUsImV4cCI6MTc4NjE0MDM1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.33sXLWxXv5OqxPc7w6wYEWyMKVRtvfTShfqWLDmXRDE	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:05:55.455	\N	2025-11-07 08:29:22.465	\N
1572132307601458432	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjZiN2FlMDlkLWJhNzYtNGRmNC1hZTU2LWJhNmVkNGVlMjQyZSJ9.eyJpYXQiOjE3NTQ2MDQzNzUsImV4cCI6MTc4NjE0MDM3NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.BlgzsB6XtVucEjzOPudMcjrry0LSoZqdt80V03rC6Jo	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:06:15.467	\N	2025-11-07 08:29:22.465	\N
1572132506755400961	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImUzMjE4YjkyLTA2MTUtNGEwNi05ODgyLThjMTdjNDlmN2Y4MiJ9.eyJpYXQiOjE3NTQ2MDQzOTksImV4cCI6MTc4NjE0MDM5OSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.5nrfWnMwyYMcZhMA5KopAvEPSxh875YAWCsfCvU7PhM	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:06:39.208	\N	2025-11-07 08:29:22.465	\N
1572133168926950658	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc0YmMzMTE4LTExNDUtNDk4NS1hOTY0LTM5OWNjNmNhMDM5NCJ9.eyJpYXQiOjE3NTQ2MDQ0NzgsImV4cCI6MTc4NjE0MDQ3OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ktDc75UculROzIG6FKvUfetBEW4amYDaLbqCk_eZPkw	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:07:58.145	\N	2025-11-07 08:29:22.465	\N
1572139607955342627	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg4NDNiNTAwLTg4M2QtNDExNS1hOTc1LTU5ZDU3OWU4ZTYwYSJ9.eyJpYXQiOjE3NTQ2MDUyNDUsImV4cCI6MTc4NjE0MTI0NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.eVskS1Lq74Or76EMZjQ2_XPOW-OYImmxuOkCnlaLPVo	4ed8dc5c-8393-44ba-a459-4063f96f4eb3	142.250.179.187	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-07 22:20:45.737	\N	2025-11-07 08:29:22.465	\N
1572140517012014373	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImNhNWFkMTM4LTJiYjgtNGIzZi1iNDRkLTI0ZmFiZGViZGNmMSJ9.eyJpYXQiOjE3NTQ2MDUzNTQsImV4cCI6MTc4NjE0MTM1NCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Xue2Vaqs0sEhuZ4Hn8L8CnOUdaJBYuN7i8iC8_iy8ek	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:22:34.105	\N	2025-11-07 08:29:22.465	\N
1572141597875766607	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjliOTM5ZjhiLWE4NmMtNGM5Ny1iYmVmLWY2NzQ5NGIzYTk2MyJ9.eyJpYXQiOjE3NTQ2MDU0ODIsImV4cCI6MTc4NjE0MTQ4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Dw5urJY2zYUd29uI46VFo-ms_V0kfeA7QE54qiO2xds	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:24:42.955	\N	2025-11-07 08:29:22.465	\N
1573185207350068570	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjI2ZDlkY2U5LWQ4NGYtNGMwZC1iY2E1LThhN2RjMzc1ZGVkOCJ9.eyJpYXQiOjE3NTQ3Mjk4OTAsImV4cCI6MTc4NjI2NTg5MCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.zhOJNh-CKHIMbB30xPt_YWPW6jdCYLbsIEDCm0e9Las	924a3417-bc5d-4a68-a961-f928e9ca1d8c	172.66.128.70	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-09 08:58:10.898	\N	2025-11-07 08:29:22.465	\N
1573191082949215580	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjMwZGU2ZWYzLTExY2MtNDE3Yy05Y2EzLTY3MzQyYWQ4ZWU0YSJ9.eyJpYXQiOjE3NTQ3MzA1OTEsImV4cCI6MTc4NjI2NjU5MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.U1DIW7L6FlObNkU6Zp2-ZPs4fyYKYXqPUJeDK_Yd3Zk	\N	172.26.0.2	Python/3.12 aiohttp/3.12.15	2025-08-09 09:09:51.316	\N	2025-11-07 08:29:22.465	\N
1573193974946989610	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJhNzM1ZDlhLThkZTgtNGRkMy04NWYyLWM5Y2U1N2I0NzYyZiJ9.eyJpYXQiOjE3NTQ3MzA5MzYsImV4cCI6MTc4NjI2NjkzNiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.SOIem_vkR5aL54QKRn5z_eZKHJzXC4uCM9HP6ryKsIA	\N	172.26.0.2	python-requests/2.32.4	2025-08-09 09:15:36.078	\N	2025-11-07 08:29:22.465	\N
1573201460772996897	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImI4Nzg0MzhkLTM0ZDktNDEwNi05NzdkLWVkZWU3MDIwZjBjOSJ9.eyJpYXQiOjE3NTQ3MzE4MjgsImV4cCI6MTc4NjI2NzgyOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.MhMuJaIsQi6hClay_-6VXQfR1jDTxyx6rUQdygkAUkc	\N	172.26.0.2	python-requests/2.32.4	2025-08-09 09:30:28.457	\N	2025-11-07 08:29:22.465	\N
1573203893385430818	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImVkZDcwZGY0LTc0MjItNGE0ZS04Y2U2LTBhMmQ5ZGI0ODkzMCJ9.eyJpYXQiOjE3NTQ3MzIxMTgsImV4cCI6MTc4NjI2ODExOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Q_3kWuwevvjPzTSY7-TCoBt6OxLoKS-VYosldUtI7fE	\N	172.26.0.2	python-requests/2.32.4	2025-08-09 09:35:18.448	\N	2025-11-07 08:29:22.465	\N
1573216175389673253	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImMyZWNjZWE2LWU2MTAtNDFiMi1hNjRiLTY2MGRmZGQ2ZTgzMyJ9.eyJpYXQiOjE3NTQ3MzM1ODIsImV4cCI6MTc4NjI2OTU4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.PtDpuG9BxXuAK8oXmKJQCTXayN0TwgCSU7VhnjNIuGo	228dd350-bd34-480c-9982-9189f989fa29	172.66.128.70	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-09 09:59:42.574	\N	2025-11-07 08:29:22.465	\N
1626139469595805479	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjE2MmRlNWNhLWEzZmQtNGI1MC1hMjY5LTAyYTY3MGY5OWVkYSJ9.eyJpYXQiOjE3NjEwNDI1MzAsImV4cCI6NDkxNDY0MjUzMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.HBIFYso2NmSdW4hM8ddE0o9BbJ87gVHrLxec-1jximQ	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:28:50.878	\N	2025-11-07 08:29:22.465	\N
1626139470241728298	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjcyMzVhYWQyLTFkZjktNDU0ZS04MjU3LTVlMGMwNDUxNDA2OCJ9.eyJpYXQiOjE3NjEwNDI1MzAsImV4cCI6NDkxNDY0MjUzMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.1V6vuNlKVIjtJQTglmLS99WYr6masL4kQ_rRK-hjZsc	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:28:50.957	\N	2025-11-07 08:29:22.465	\N
1626139471852341045	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImYyMDhjZmVmLTIzNmQtNDdiZS04MzI2LWZkYzlhYzkyODIzNyJ9.eyJpYXQiOjE3NjEwNDI1MzEsImV4cCI6NDkxNDY0MjUzMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.TB13IWVmMKL87IYp1EcA-2JkolS0CxBIC958xpx1JpM	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:28:51.15	\N	2025-11-07 08:29:22.465	\N
1637642448693888060	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImQwMDAyNDFmLWY0MTctNDEzMS1iMzEyLTQxYTEzMzc2NWE0YiJ9.eyJpYXQiOjE3NjI0MTM3OTIsImV4cCI6NDkxNjAxMzc5Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.F51Rl0YPwhLo7M8iCM3Yru6VyGV7dP1cwML4r1BA8pE	\N	172.18.0.6	curl/8.7.1	2025-11-06 07:23:12.842	\N	2025-11-07 08:29:22.465	\N
1626139472733144896	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjdlMmE1NjFjLTUzNmEtNDE0NC1hZTRhLWUyYzk5NGYwNTg1ZSJ9.eyJpYXQiOjE3NjEwNDI1MzEsImV4cCI6NDkxNDY0MjUzMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.3Zn0HgmxoLpiXXO2OobtJwfUGEhFNu_lC5lSMO2i7Sk	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:28:51.255	\N	2025-11-07 08:29:22.465	\N
1626139473546839883	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImE4YzRmYjExLWFiNWUtNGQxYy1hNTBkLTBmNWEwN2VmNThhYSJ9.eyJpYXQiOjE3NjEwNDI1MzEsImV4cCI6NDkxNDY0MjUzMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.vDkuaUusY6WgmGypxmjNZvIwxRG1zlePKMjCZ-fyYY8	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:28:51.352	\N	2025-11-07 08:29:22.465	\N
1626139474545084246	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImVjNmM4NzZiLTZhNTItNDc2NC04MGVkLTFiNTIxMWVlODBkOCJ9.eyJpYXQiOjE3NjEwNDI1MzEsImV4cCI6NDkxNDY0MjUzMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.acXSkKej7Ifi0hzllWFHjJMoRXzS0mQ0uzlD8Qqcco8	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:28:51.47	\N	2025-11-07 08:29:22.465	\N
1626139476818397031	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjEyYTM2Y2ZhLTlmNjEtNDI1NC1hODUwLWNjZTUyMmEyZDQ3MSJ9.eyJpYXQiOjE3NjEwNDI1MzEsImV4cCI6NDkxNDY0MjUzMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.oJnAEkKRu7xSYshkQrJXuqNohQfKgbhecopBba8fAIA	f8fa67dd-c779-491c-931f-3be780d26de1	172.18.0.13	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-21 10:28:51.741	\N	2025-11-07 08:29:22.465	\N
1626139517461202792	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjIwMTUwMjFlLTdmODAtNGFlZS1iNjU3LWE0ZDQ0NDJlOGQ1NSJ9.eyJpYXQiOjE3NjEwNDI1MzYsImV4cCI6NDkxNDY0MjUzNiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.NPw8DM8cKlKtO9uVQfT9Vtp4CIIXDWyy0FjUoRp42xA	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:28:56.587	\N	2025-11-07 08:29:22.465	\N
1626139639549003637	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjNmMjk1OWQ2LTZjODYtNDkwYy1iMzdmLTFhZjgwODEzMjYzZiJ9.eyJpYXQiOjE3NjEwNDI1NTEsImV4cCI6NDkxNDY0MjU1MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.8i2kP6VllzIZN3A6PlFKpErmh4lT4M4zZSQmh0848uA	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:29:11.14	\N	2025-11-07 08:29:22.465	\N
1626139640060708728	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImZkMjQxMTE2LTQzOGMtNDcwMC04YTQ5LTkyYzRmNDAxMGRlYiJ9.eyJpYXQiOjE3NjEwNDI1NTEsImV4cCI6NDkxNDY0MjU1MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.F4DPnzV2wo0kU8CjYFDrRYtKO0G2mA2ykZtsOjZLdxc	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:29:11.202	\N	2025-11-07 08:29:22.465	\N
1626139640597579641	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjdjMjgyZjEzLWNkMjMtNDZhZS1iNGIyLTNhZDI4M2I3NzU1NCJ9.eyJpYXQiOjE3NjEwNDI1NTEsImV4cCI6NDkxNDY0MjU1MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.2zOV2jiU5oHtug4PZXtQ0aOzUc1TqFvcGwuuN3G0NKg	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:29:11.266	\N	2025-11-07 08:29:22.465	\N
1626139641226725243	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjEzMDQ0YTFkLTQ4MjktNGVhNC04YjQyLTJiZjU1MmM2NGE4MCJ9.eyJpYXQiOjE3NjEwNDI1NTEsImV4cCI6NDkxNDY0MjU1MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.-EaEdaNMfZ0CSl3tPvC5MpKwB3G5VgKuCPG0M9bUOtI	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:29:11.34	\N	2025-11-07 08:29:22.465	\N
1626139703705077630	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjUyMGMxYzkwLTNlNjktNDIwZS1iZWYxLWQ2NDY4M2Q1MGEzNCJ9.eyJpYXQiOjE3NjEwNDI1NTgsImV4cCI6NDkxNDY0MjU1OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.BiJs1f-4m2OSTJwzXuqQP-L2M1R3EPtG2h-pQIpVKF8	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:29:18.788	\N	2025-11-07 08:29:22.465	\N
1626139704342611839	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjI3YTAzNmRlLTQwNmEtNGQwMS1iNDlhLTkwNjAxYmRjOTc2OCJ9.eyJpYXQiOjE3NjEwNDI1NTgsImV4cCI6NDkxNDY0MjU1OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.s97pmKX-gmlsvXDsJFxwXkOsSm2BY4sulNuXeypPa9s	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:29:18.865	\N	2025-11-07 08:29:22.465	\N
1626143867289995138	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImRmYzUxZWZlLTA4YWUtNDBkNy1hYmQ4LWZhM2U5Y2Q2ZWJhNiJ9.eyJpYXQiOjE3NjEwNDMwNTUsImV4cCI6NDkxNDY0MzA1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.o7s2TTc7H9jIiGqpbTuTN34sVRefCQLD21Kf1AHFEEA	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:37:35.124	\N	2025-11-07 08:29:22.465	\N
1626143868187576197	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjM3NmU2YzFhLTc1NjUtNDAwOC1hYjFiLWIxOTU1OWM4ZWJhNSJ9.eyJpYXQiOjE3NjEwNDMwNTUsImV4cCI6NDkxNDY0MzA1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9._iJ4k6mBQcwnQGO2lWO_i4bGZfEGBABbW9_1ubW5kmM	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:37:35.234	\N	2025-11-07 08:29:22.465	\N
1626143869177431952	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjEwNmJkMWY0LWU2YzUtNDVjYy04NzkwLTQ2YzBjOTNhMmRjNSJ9.eyJpYXQiOjE3NjEwNDMwNTUsImV4cCI6NDkxNDY0MzA1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Xi6yM_38ln7zEq5gGfIROzCGlGPRfV0SmvqB-YnUhPE	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:37:35.352	\N	2025-11-07 08:29:22.465	\N
1626143870209230747	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjBiZTI1MzI5LWEwN2YtNDNiMy1hNDE2LTQ2ZmFmZTU3Y2UwMSJ9.eyJpYXQiOjE3NjEwNDMwNTUsImV4cCI6NDkxNDY0MzA1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.6zUfecnQ0os6_8jtyQRt7ktbgskjAJlLYWdbNxUlWrc	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:37:35.474	\N	2025-11-07 08:29:22.465	\N
1626143871031314342	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjZiOTQ2OGQ5LWI3MDctNDViMy05YjZiLTVlNDY3ODA3N2Y1YiJ9.eyJpYXQiOjE3NjEwNDMwNTUsImV4cCI6NDkxNDY0MzA1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.0zv4RYbRDABS59_QYImY7L6sKpxOoSwuRNJBENi4-Vk	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:37:35.572	\N	2025-11-07 08:29:22.465	\N
1626143872499320753	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjEwYzIwOTJkLTg2ODctNGUxMy1hNTcxLTNkYmZlMTFiMzdiNiJ9.eyJpYXQiOjE3NjEwNDMwNTUsImV4cCI6NDkxNDY0MzA1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9._gk9f1T0RroW5vk5mjHiA1NGjNwAutVlz8lXzsBW5KE	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:37:35.743	\N	2025-11-07 08:29:22.465	\N
1626144083355371462	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImM3ZjA3MDI5LWM1MWYtNGNkNC05NDkxLTViZGQzYjA1NWZjOSJ9.eyJpYXQiOjE3NjEwNDMwODAsImV4cCI6NDkxNDY0MzA4MCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.4j_Nq0B33FaLAC-tj4aAljLhri2vxMslt9ai59L8tg0	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:38:00.881	\N	2025-11-07 08:29:22.465	\N
1626144574768416720	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjZhMDMzZTA3LWVhY2EtNDY0Ny1iYjYyLWI0ZTViZTUwODBkNSJ9.eyJpYXQiOjE3NjEwNDMxMzksImV4cCI6NDkxNDY0MzEzOSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.J7Zlnd0504HEZzmURL5a0jBxDrNNwFmbeYiLc4rtzU8	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:38:59.462	\N	2025-11-07 08:29:22.465	\N
1626144575347230675	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjkwNTNmMTFiLTI2ZDQtNDY5MS1hMTQ5LWQ4MWZlYzFmYTM1YSJ9.eyJpYXQiOjE3NjEwNDMxMzksImV4cCI6NDkxNDY0MzEzOSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Y2nUBiO5ZhE_eqOOVAgVCzNxBgybyV6sD7T48zXPaQo	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:38:59.533	\N	2025-11-07 08:29:22.465	\N
1626144575875712980	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImE3Yzg5ZDM1LTJiZDktNDAyOC1hMjU0LTFlYTNkZjUxMWE5NCJ9.eyJpYXQiOjE3NjEwNDMxMzksImV4cCI6NDkxNDY0MzEzOSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.rsasVGizICIW5Fo80hX-bDBHZyk1IvvHatK1dNelmyo	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:38:59.597	\N	2025-11-07 08:29:22.465	\N
1626144576496469974	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjExNDA5OGVlLTc2MGItNGJiYS04YWI0LWU1YzkxZTgwMWI1MSJ9.eyJpYXQiOjE3NjEwNDMxMzksImV4cCI6NDkxNDY0MzEzOSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.R5bt08JiktsGcUW0qgMZnG6mxKTs2-jAIH_H5vFHSl4	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:38:59.67	\N	2025-11-07 08:29:22.465	\N
1626146339102394329	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjM3Zjg2MTNkLTMzOTktNDg3NS1iMjliLTk5OTk5NWIwNjVjOCJ9.eyJpYXQiOjE3NjEwNDMzNDksImV4cCI6NDkxNDY0MzM0OSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.5rTfTrhj9gRP9egP-VBpV90jQyvUrTDYPyer-HVM54I	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:42:29.787	\N	2025-11-07 08:29:22.465	\N
1626762336658261981	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImVmMmRkZGI1LWU5ODEtNDIyNi1iOTE0LTdlYjZiZDhlYzk4NyJ9.eyJpYXQiOjE3NjExMTY3ODIsImV4cCI6NDkxNDcxNjc4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.FOgr81iWAmb5HipwePmXjvWR3aZFugjsRwTEcmg0K98	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:06:22.414	\N	2025-11-07 08:29:22.465	\N
1626762337388070880	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjU4MWFmOTk3LTMwNzUtNDlkYS1hOGZkLTY5NDUzMjkzZTdiYyJ9.eyJpYXQiOjE3NjExMTY3ODIsImV4cCI6NDkxNDcxNjc4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.IX0rAJ8DdW_WTwgwe7uLHFDJ9vl8Sn_k4OARvcdS8Y4	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:06:22.507	\N	2025-11-07 08:29:22.465	\N
1626762338763802603	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImEyOTYwOGYxLTExNmEtNGUyMS05N2MwLWQ5ODZjYmE2MzA1ZCJ9.eyJpYXQiOjE3NjExMTY3ODIsImV4cCI6NDkxNDcxNjc4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.iGNur6M4qKEWZAcXnQfzu1-BzLMj21QIK-SwqdcD-SY	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:06:22.672	\N	2025-11-07 08:29:22.465	\N
1626762339661383670	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImZiYTc0M2YyLTUxMDEtNDVlZi05ZjdhLTc1OWEzNGIwZGMxNCJ9.eyJpYXQiOjE3NjExMTY3ODIsImV4cCI6NDkxNDcxNjc4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ZdUfW8_xzYRQ_t_reYxdEwZ7OisMvbFgpzhji8N4G7k	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:06:22.778	\N	2025-11-07 08:29:22.465	\N
1626762340475077633	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjIzOWQ3OWM3LTRjNmItNGNmYS1iNDY2LWVmNWYyOTQyNGMzMCJ9.eyJpYXQiOjE3NjExMTY3ODIsImV4cCI6NDkxNDcxNjc4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.IbL8maFkmYnb7m4VlU9W8HZAjN6AP1mH02_C1Koa4DE	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:06:22.876	\N	2025-11-07 08:29:22.465	\N
1626762341993415692	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjUyMDgyODY0LWQyM2YtNDc5ZC04MDI4LTRkNzkzNmVmZTJiMyJ9.eyJpYXQiOjE3NjExMTY3ODMsImV4cCI6NDkxNDcxNjc4Mywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Vg5DxlwHucDqfwY8eN3PVGmOMgsJHIM5niPU8J10rnE	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:06:23.057	\N	2025-11-07 08:29:22.465	\N
1626762359903093793	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjliZTFiMThmLWI3YTgtNGI5OC1iNzc2LWM1ZGMyNjdkNGUyZSJ9.eyJpYXQiOjE3NjExMTY3ODUsImV4cCI6NDkxNDcxNjc4NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.VPAzWP1XxznkLOHpshA65MbhHW6AEt8DUMBu_GDI2c4	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:06:25.192	\N	2025-11-07 08:29:22.465	\N
1626762564148921389	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQ3ZjZiZWFmLTBkMGItNDBiZC04ZjM1LTM1NTM2OGI0MTZlNCJ9.eyJpYXQiOjE3NjExMTY4MDksImV4cCI6NDkxNDcxNjgwOSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.CSlYyMY4ML23Kq6O3KpoRjyslHEM3q7P3tatTvbYPgo	edfe8e4e-fda2-4e4b-976d-17b32b8cd3bd	172.18.0.3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-22 07:06:49.539	\N	2025-11-07 08:29:22.465	\N
1626762740183860270	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjJhNjUzOWRjLTFhMGItNDlkZS1hNDYwLTdkMTE3ODA5ZDI3ZCJ9.eyJpYXQiOjE3NjExMTY4MzAsImV4cCI6NDkxNDcxNjgzMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.4xhLIRWoNyma-HXNReJanl8JPUUO10njLow64WDpol4	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:07:10.524	\N	2025-11-07 08:29:22.465	\N
1626762740695565361	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImZjZWVhMmQ4LTQ5YmItNDU4OS1iN2I1LWFlYThlNjZhYjQ0YyJ9.eyJpYXQiOjE3NjExMTY4MzAsImV4cCI6NDkxNDcxNjgzMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Skmdgd9mPKq-IvN1gXGn2mZSp5GvTT4TTIRkO0zpTHM	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:07:10.586	\N	2025-11-07 08:29:22.465	\N
1626762741207270450	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImRhNTc5NTY0LWRkMDItNDgzYS1hOTY1LTRmYzExZDIxZTc3YyJ9.eyJpYXQiOjE3NjExMTY4MzAsImV4cCI6NDkxNDcxNjgzMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.XTuea1-J66v7mdK7r0q3Z6Gc4C3CPK6lrVuZgYD70t8	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:07:10.647	\N	2025-11-07 08:29:22.465	\N
1626762741811250228	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjdhYjFkOWE1LThiYjQtNDAyZC04MzFkLTdkMTI3YzY4NjBmZiJ9.eyJpYXQiOjE3NjExMTY4MzAsImV4cCI6NDkxNDcxNjgzMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.kWoM07kWHJYnQpYKIEDgHtn3kE8BnopZZTJ3dCG6RoY	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:07:10.719	\N	2025-11-07 08:29:22.465	\N
1626762950654034999	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjdjZGM3NjE3LThjZmQtNDgxMC1iMWEyLWRkYTU2Y2QwYWM5YSJ9.eyJpYXQiOjE3NjExMTY4NTUsImV4cCI6NDkxNDcxNjg1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.oRBxGdp0C2jNE6LKlRBiJjgpsR5ySrN479z5OydU-r0	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:07:35.613	\N	2025-11-07 08:29:22.465	\N
1626776935344374843	1626139592824457076	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImU0NDk0ZDUzLWZiNDItNGVmMi1iMWU5LWVkZTg0MDEyYjdkZSJ9.eyJpYXQiOjE3NjExMTg1MjIsImV4cCI6NDkxNDcxODUyMiwic3ViIjoiMTYyNjEzOTU5MjgyNDQ1NzA3NiJ9.EU0NsfM2j23zR-XZK8jq7F0xsLxn735oLduuxOy8w5g	17f2a673-3bb5-4f00-8fc7-4dda16ee2ee9	172.18.0.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-22 07:35:22.718	\N	2025-11-07 08:29:22.465	\N
1626777062280791100	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImZhYWIzN2Q2LTg2OWItNGM0NS05ZDRmLWNiNDQxNWEyYzQxMiJ9.eyJpYXQiOjE3NjExMTg1MzcsImV4cCI6NDkxNDcxODUzNywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.EHeurSb3CgGk2WbAKathO6LzMT41T_yGLblOMVMVOIU	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 07:35:37.85	\N	2025-11-07 08:29:22.465	\N
1626777062901548095	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjhlNmVmN2Q5LTljNWItNGIzYi04NzRhLWI1M2YzMzkxNjRjZCJ9.eyJpYXQiOjE3NjExMTg1MzcsImV4cCI6NDkxNDcxODUzNywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Llcr4ON1SSYH-fZ9YztY0Ogkzwy0MBQ0ptBbax_OZuU	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 07:35:37.925	\N	2025-11-07 08:29:22.465	\N
1626777064185005130	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjJiODQ2ZDQ1LTFlYTMtNGM1NS04NjFkLTBmOGVjYTFmZTczZSJ9.eyJpYXQiOjE3NjExMTg1MzgsImV4cCI6NDkxNDcxODUzOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.HKD77xO2jMND24w7IS6d_4nyogQDrVPvTZBWb4lZnRY	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 07:35:38.079	\N	2025-11-07 08:29:22.465	\N
1626777065585902677	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQzMDM0ZGY4LTE2ZDMtNGRiOC1iYzQxLTI5ODhjM2ViMmUzNyJ9.eyJpYXQiOjE3NjExMTg1MzgsImV4cCI6NDkxNDcxODUzOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.rFl7Q1u6t3ikzYh1YzcA3rkZt8DiwyR4nRRwkULh3wk	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 07:35:38.246	\N	2025-11-07 08:29:22.465	\N
1626777066416374880	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg5ZjNmYTZlLTU4NzAtNDU2MC04NzQ1LTc4YTFiODExZmZjZiJ9.eyJpYXQiOjE3NjExMTg1MzgsImV4cCI6NDkxNDcxODUzOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.vqtffRgSSvcWMkj8qyRiae86GSy9_ctRta7L-krqMzE	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 07:35:38.345	\N	2025-11-07 08:29:22.465	\N
1626777067406230635	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjhhYWQwMGU4LTdkNzYtNDMzNi05MWFjLTI4MzI3MGY5MTFhMSJ9.eyJpYXQiOjE3NjExMTg1MzgsImV4cCI6NDkxNDcxODUzOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.o_GV51Lj1sZ76VdMG8kMXxzndAF6MocND98moE74nhk	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 07:35:38.463	\N	2025-11-07 08:29:22.465	\N
1626777168111469696	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjJkZmUyOWM5LWYzNmQtNDhkNy04N2RhLTQ2YTg3ZDU3NzQ3ZCJ9.eyJpYXQiOjE3NjExMTg1NTAsImV4cCI6NDkxNDcxODU1MCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.6eD09vVD7HZfvKgSiVIRAV-nVfx4Z8wUA7a2kPtTD14	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 07:35:50.466	\N	2025-11-07 08:29:22.465	\N
1626840254361109642	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjM1NTdiM2M1LWNmZTAtNGIzOS05MjM3LWMzOTczNTk3OTk4MCJ9.eyJpYXQiOjE3NjExMjYwNzAsImV4cCI6NDkxNDcyNjA3MCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.a12SGChQqTKv_CjjYuZ_lvKHmcG5u2TdZ2JU-RU_Zw0	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 09:41:10.93	\N	2025-11-07 08:29:22.465	\N
1626840255954945165	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjkxZmYxZWUyLWEzYmUtNDhmMS1iZDA0LWI4MzFkOGZhNTI4ZCJ9.eyJpYXQiOjE3NjExMjYwNzEsImV4cCI6NDkxNDcyNjA3MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.J_ZZ_1uUY1UwbOP6_iZz5BBXvQblfIgoJIvEQq-XmRc	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 09:41:11.124	\N	2025-11-07 08:29:22.465	\N
1626840257297122456	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImZhY2ZjMGViLTU1NDYtNDI5OS1hM2Y2LWUyY2I2M2FlMjIwYyJ9.eyJpYXQiOjE3NjExMjYwNzEsImV4cCI6NDkxNDcyNjA3MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.lNh0WrJGkxUIYUbM5n8KzP8KsxnA0N1bkBxzMbJ-m8E	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 09:41:11.284	\N	2025-11-07 08:29:22.465	\N
1626840258286978211	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjRiZDg3YjI0LTJkYmUtNDhjNC05NDgxLTk2YWUzMGI4ODM4MCJ9.eyJpYXQiOjE3NjExMjYwNzEsImV4cCI6NDkxNDcyNjA3MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.MpIAa4iXJgnfEOQ9sadORjHzGDiJPmitDC-LSrCxWFI	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 09:41:11.402	\N	2025-11-07 08:29:22.465	\N
1626840259402663086	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjIxYzYyYTFjLWRhNzktNGZkMC04YzQwLTI3ZjVlMjkyZjBjMCJ9.eyJpYXQiOjE3NjExMjYwNzEsImV4cCI6NDkxNDcyNjA3MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.CWMg-vKNhd9fFf7b1BK28m5keVvdFnPK4e6A4oS3aF8	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 09:41:11.536	\N	2025-11-07 08:29:22.465	\N
1626840260459627705	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjVlYzYxZmI5LThiNWMtNDc0Ny1iMGU5LWNiMmIzMTY1ZDQ4YyJ9.eyJpYXQiOjE3NjExMjYwNzEsImV4cCI6NDkxNDcyNjA3MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.7lS08pZQlsSz33hWJ7pBGuoUTVfqRVYNHYYTPwBx5ls	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 09:41:11.661	\N	2025-11-07 08:29:22.465	\N
1626840781727728846	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImY5OWFlNmNlLWY2YTYtNDk1OS1hYzdkLTg1NWQzOGVlNGVjMyJ9.eyJpYXQiOjE3NjExMjYxMzMsImV4cCI6NDkxNDcyNjEzMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.DrR9lXPhy0xEA-2C8BaWO2v6_v-mpF604DrhObujNI0	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 09:42:13.799	\N	2025-11-07 08:29:22.465	\N
1626853198293632218	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjkxN2FkNDc2LTMzNjAtNGNmNS04MmI4LWUyZjAyMGE2OTUyMCJ9.eyJpYXQiOjE3NjExMjc2MTMsImV4cCI6NDkxNDcyNzYxMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.I6VMtLUTJpJbquK2q89YtCQHddtxO5LS4Zc9fPol5GM	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 10:06:53.964	\N	2025-11-07 08:29:22.465	\N
1626853198989886685	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImU2YTk2YzA3LTVjMmUtNDc5NS1iNzMwLTJjMDhkZmRhNDllYSJ9.eyJpYXQiOjE3NjExMjc2MTQsImV4cCI6NDkxNDcyNzYxNCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.wZ6PLkBxwf8i2BoIcobx4nKwq9WzWJTlKZdQSN9saLY	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 10:06:54.055	\N	2025-11-07 08:29:22.465	\N
1626853200181069032	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjZjMmU3OGRmLWRjYzEtNGQ3MC05ZWE4LTljMTk1YTIwMjYwMiJ9.eyJpYXQiOjE3NjExMjc2MTQsImV4cCI6NDkxNDcyNzYxNCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.lXXOzuuCXlhItqHgnwFPOZ3EgXDsEMh9mPFrHzziKJk	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 10:06:54.196	\N	2025-11-07 08:29:22.465	\N
1626853201036707059	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc5MTgxMGFhLWEzY2EtNGY5Zi1iMjc0LTVjM2IxZmFiYjRmZSJ9.eyJpYXQiOjE3NjExMjc2MTQsImV4cCI6NDkxNDcyNzYxNCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.vrDF2kKQj13GCbouBtfZbj3rEpspE2F7kJI5P60bZp4	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 10:06:54.298	\N	2025-11-07 08:29:22.465	\N
1626853202152391934	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjgyMGRiOThiLTg4NGQtNDQ0Mi05MTYzLTNjM2RmZGNmNjIyOSJ9.eyJpYXQiOjE3NjExMjc2MTQsImV4cCI6NDkxNDcyNzYxNCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Ryzuo_3Jg1iz1Ill6bYC09RIJ2dpzSJxkYCoiRoEgUc	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 10:06:54.431	\N	2025-11-07 08:29:22.465	\N
1626853203100304649	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjJhMDkzNzMxLTM4MDktNGZlYi05MWQ5LTI4YjczZTQ5MGExYSJ9.eyJpYXQiOjE3NjExMjc2MTQsImV4cCI6NDkxNDcyNzYxNCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.BjTYJvz6H1QpTpMdByFmuYGbsmmcUXAUvEXE1gY-0Rk	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 10:06:54.545	\N	2025-11-07 08:29:22.465	\N
1626853521842242846	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjZmYTEzYTMxLWExYzAtNGQyYi1hMzY3LTMyMTk5YTg3ZTNlMSJ9.eyJpYXQiOjE3NjExMjc2NTIsImV4cCI6NDkxNDcyNzY1Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Pgw80Egthavw4hcon4XASP0a03z0IWMRXWkE5aFWtxI	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 10:07:32.539	\N	2025-11-07 08:29:22.465	\N
1626870949351523626	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQ1YjU4MTgzLTczZmUtNDI5YS1iMjU5LTVjYzVkMmI3MjgzNSJ9.eyJpYXQiOjE3NjExMjk3MzAsImV4cCI6NDkxNDcyOTczMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ZMjj2869pPDu5KwdrLp6_6mCI1BtRNFP5sANlEYAGZk	3b5a09f8-e232-48b7-9212-a3b3c1ba3edd	172.18.0.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.1 Safari/605.1.15	2025-10-22 10:42:10.059	\N	2025-11-07 08:29:22.465	\N
1626885881862292779	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjRiMDNiNDczLTY3ZTUtNGE0YS04ZDM0LWIyMDVjMmU2YTg1MCJ9.eyJpYXQiOjE3NjExMzE1MTAsImV4cCI6NDkxNDczMTUxMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.YgCl-VkZQroSW_nx8exYjElORP1YhIpDxRQ0--W42h8	81cf3169-5a76-4034-b09e-0b58b03292ff	172.18.0.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-22 11:11:50.151	\N	2025-11-07 08:29:22.465	\N
1626893016901879090	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQ2MmZhZjU3LWEwZDMtNGFlOC04OTBjLTJjNmQ1ZmVjNzg3ZiJ9.eyJpYXQiOjE3NjExMzIzNjAsImV4cCI6NDkxNDczMjM2MCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.O7ooD8rZSqwZYJPRI_UHWcapmJlMkoq5wvc8-mIz_Gs	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 11:26:00.718	\N	2025-11-07 08:29:22.465	\N
1626893017489081653	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjE3ODdiYmE2LWY0NjMtNDEzYy1hZDU1LTI0M2JjOWFlNTU4NyJ9.eyJpYXQiOjE3NjExMzIzNjAsImV4cCI6NDkxNDczMjM2MCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Szi9uG7Uyf7vmxuiL5ESk9QNutyGmJekPtCOkVUjYOQ	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 11:26:00.789	\N	2025-11-07 08:29:22.465	\N
1626893018428605760	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjkyZjZjMDg5LWZlNTAtNDk3My04Y2Y3LTAwODc5NzQ3NWYyMyJ9.eyJpYXQiOjE3NjExMzIzNjAsImV4cCI6NDkxNDczMjM2MCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ekmE24kOwLkfDmfOadu1zsjDzzZjDEDwA953vGHWxe4	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 11:26:00.902	\N	2025-11-07 08:29:22.465	\N
1626893019418461515	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjgyMWYxNmYzLTZjZmUtNDdlYy1iYzc5LTljYWUxZGRkODYyMSJ9.eyJpYXQiOjE3NjExMzIzNjEsImV4cCI6NDkxNDczMjM2MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.MeYGuWhVlwB4g6MIgnBklA1SGio3y4oOJIP7YZvLaFo	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 11:26:01.02	\N	2025-11-07 08:29:22.465	\N
1626893020190213462	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQ2YWRiMDc1LWYzOGUtNDY2OS04NzVlLTQ1ZTNhNDBkYTQ0MCJ9.eyJpYXQiOjE3NjExMzIzNjEsImV4cCI6NDkxNDczMjM2MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.NQTx1WndR9-h2_GbfLyWQoWQdugBnXvuEgO9wzeJ-oY	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 11:26:01.112	\N	2025-11-07 08:29:22.465	\N
1626893021205235041	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjFmNWFlNDZjLTllY2MtNDNlMS04MTE0LTU1NTE5ZTdjM2VkMyJ9.eyJpYXQiOjE3NjExMzIzNjEsImV4cCI6NDkxNDczMjM2MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.qM7PXMSYxbGX_9_MsIhAeQnlFgOvKbBTq5hZ4vVat8A	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 11:26:01.232	\N	2025-11-07 08:29:22.465	\N
1626893542515279222	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjM1NWE1NWYxLTM5ZWMtNDJmYi05MjZlLWI5ZDJmZTJlNjVhOSJ9.eyJpYXQiOjE3NjExMzI0MjMsImV4cCI6NDkxNDczMjQyMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.qUH7pjc7r61JMrZu1VUR-5WcyY8owdxGqsWmUHL7_h4	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 11:27:03.376	\N	2025-11-07 08:29:22.465	\N
1626894229064123778	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJhN2EyMGIzLWIzMDItNGExNi05NjAwLTAxMmRkNzY4Mjg4MyJ9.eyJpYXQiOjE3NjExMzI1MDUsImV4cCI6NDkxNDczMjUwNSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.YS5bSCE37LuDqDZad35n-4npLynxbjdP_FdT5tDuDIw	a79a209e-ad94-4543-85c2-62a75fe45be0	172.18.0.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-22 11:28:25.218	\N	2025-11-07 08:29:22.465	\N
1626978046693082499	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjgzNmVjMWMwLWRlOGQtNGU5NS04ZTkxLWFiNTE0NTQ3NzFiYSJ9.eyJpYXQiOjE3NjExNDI0OTcsImV4cCI6NDkxNDc0MjQ5Nywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.CrXi0uNXszTCEluNo4wfApEMy7Ug7p-vU-dYXwF7bvY	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 14:14:57.056	\N	2025-11-07 08:29:22.465	\N
1626978047490000262	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjJlMjE5OGY5LTQ1NDItNGU1Zi1hOTJhLTYxOWJiMWIxYzYwNyJ9.eyJpYXQiOjE3NjExNDI0OTcsImV4cCI6NDkxNDc0MjQ5Nywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.I0tAjwahAWm0EZrlUT3QzXv8Z-Ab-yT_ie5r2JOQ1VQ	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 14:14:57.155	\N	2025-11-07 08:29:22.465	\N
1626978048689571217	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQ4ZjAwMDE0LWZhNjUtNDg5YS04MWI0LThhNmU3N2RmNWFkNyJ9.eyJpYXQiOjE3NjExNDI0OTcsImV4cCI6NDkxNDc0MjQ5Nywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9._uZOpHh-QKe-ubET7JuI7gU_b4NfZG57kfQqrVXkTlA	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 14:14:57.299	\N	2025-11-07 08:29:22.465	\N
1626978049536820636	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjliY2Q3OGI0LTc1YmYtNDYwZS1hYzUzLWEwZWU5ZTU4ZDIzZCJ9.eyJpYXQiOjE3NjExNDI0OTcsImV4cCI6NDkxNDc0MjQ5Nywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Lfe6C1OdBwr-MkyBKfshKN3l-vXAvoE2r_9caIiXjHE	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 14:14:57.4	\N	2025-11-07 08:29:22.465	\N
1626978050409235879	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjIxODNmZmI3LWI4ZGQtNGUzNS04ZTc4LTgwMGFkYzdkOTY3MiJ9.eyJpYXQiOjE3NjExNDI0OTcsImV4cCI6NDkxNDc0MjQ5Nywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.712spH33NehCBwhNs6ogHP8-FKNESa0EUPPw_zOJx7w	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 14:14:57.504	\N	2025-11-07 08:29:22.465	\N
1626978051575252402	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImY1MGMyNTQ1LTEyNWUtNDBiZC04ZjU3LTU2MjcwNDg1OGFjYyJ9.eyJpYXQiOjE3NjExNDI0OTcsImV4cCI6NDkxNDc0MjQ5Nywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9._TyYz6qozA_XE_OMdn1CjBJ9ItA75q7ZHEQlfoqca94	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 14:14:57.642	\N	2025-11-07 08:29:22.465	\N
1626978457088951751	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQ0M2ZhNTNiLTI1MDctNDRmZC1hYzFiLTNlMmY1N2YyNmFjZCJ9.eyJpYXQiOjE3NjExNDI1NDUsImV4cCI6NDkxNDc0MjU0NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.soRQAwzRCjCyisS-QAE98SOIjOFVKRhOJiSzMaRJC1A	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 14:15:45.981	\N	2025-11-07 08:29:22.465	\N
1626995069208757713	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjM2ZTZiZTIwLWE5ZTctNDY2Yi1iODQ3LWNlMjc4MWY0NzFlZSJ9.eyJpYXQiOjE3NjExNDQ1MjYsImV4cCI6NDkxNDc0NDUyNiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.q0eEr-oppB_hTE4GhNi3KSmMA3s1M3MSA6GNonh6Nps	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 14:48:46.3	\N	2025-11-07 08:29:22.465	\N
1626995071247189471	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImYyM2EwNjY2LTJlNTgtNGFjNC05OTM1LTY5YjNmZTdlOWQ2NyJ9.eyJpYXQiOjE3NjExNDQ1MjYsImV4cCI6NDkxNDc0NDUyNiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.sQPcJ1LnsPXIPAzZ1G53OXqyclFN4I9rP8yvtTziCsI	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 14:48:46.545	\N	2025-11-07 08:29:22.465	\N
1626995072086050282	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImVjZWU1MmFkLTk2NTQtNGMwOC04MTJmLTRjMzMyZjk4ODUzMCJ9.eyJpYXQiOjE3NjExNDQ1MjYsImV4cCI6NDkxNDc0NDUyNiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.MmNKRtYR3BaMEvf617ZucrgxqRmB19NjX2NdaD7ZExE	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 14:48:46.646	\N	2025-11-07 08:29:22.465	\N
1626995072832636405	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjI2MjEwYzdkLWJlODktNDJmMi05ZmI2LTJhZGQyNjYyMDEwNyJ9.eyJpYXQiOjE3NjExNDQ1MjYsImV4cCI6NDkxNDc0NDUyNiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.yCB97uoIv1l_-huyk9w0KqS7vVLhVhRHkpgCJraybdc	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 14:48:46.735	\N	2025-11-07 08:29:22.465	\N
1626995073822492160	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImE5ODMxNTE4LTMzN2EtNDVjOC04ZWFkLTYwZGQ5NTE0YWU4NyJ9.eyJpYXQiOjE3NjExNDQ1MjYsImV4cCI6NDkxNDc0NDUyNiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.J0Mr42oEFRaWdsYF7-vFrzhADFQBU3NnqTm8lVH3AFs	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 14:48:46.852	\N	2025-11-07 08:29:22.465	\N
1626995678246864405	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImE3MTEyMmRmLWMyNWUtNDU5Mi1hNDM2LTM3NjgxNzViMWE5OSJ9.eyJpYXQiOjE3NjExNDQ1OTgsImV4cCI6NDkxNDc0NDU5OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.FOVjdi2b8KsAqRXyjHB3veuBQA9YDmrhO2mGDAT0cdM	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 14:49:58.903	\N	2025-11-07 08:29:22.465	\N
1627092963207153183	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImZjMTg1ZGY4LTUwODctNDA3OS1hMWNjLWZiYTUxY2FhZTIzYSJ9.eyJpYXQiOjE3NjExNTYxOTYsImV4cCI6NDkxNDc1NjE5Niwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.s1Mz9MgKzcSTch2GLcyzrjUTl_UiQ5wP4nBVJVK1QAk	323b1fc8-1dee-4e5a-a652-d19550aa3922	172.18.0.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-22 18:03:16.173	\N	2025-11-07 08:29:22.465	\N
1627092978902238752	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjMzZDVlOWFlLWZjNTAtNDQ0Zi04YmE1LTVlMGQ2YzVlZjEwNCJ9.eyJpYXQiOjE3NjExNTYxOTgsImV4cCI6NDkxNDc1NjE5OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.KBF1jKWKcZ3uKHLZamHz-0upFvE1YcXR6u0RDE7FAfU	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 18:03:18.048	\N	2025-11-07 08:29:22.465	\N
1627092979514607139	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImU2MDlkMWE3LTQxMTctNDA1NS1hNGZkLWMzYTVkMDc3YjFkYiJ9.eyJpYXQiOjE3NjExNTYxOTgsImV4cCI6NDkxNDc1NjE5OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.hrG1EIP90j5caw5jKdYVkeAztJdQIdj5U5mZ1oDeN2s	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 18:03:18.12	\N	2025-11-07 08:29:22.465	\N
1627092980705789486	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImQ5OGY0MjZmLWU4ZjItNDU4MS04NTMyLTg0OTQ3ZWVjYzNmMyJ9.eyJpYXQiOjE3NjExNTYxOTgsImV4cCI6NDkxNDc1NjE5OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.sO1V2i0HC3yOWmEMP41BO1akyNyQDXvZ4_yuXxE8FZM	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 18:03:18.262	\N	2025-11-07 08:29:22.465	\N
1627092981594981945	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjMwMzdiNzZmLTE3MWQtNDU0Yi04ODcxLWE5MGRlMjJkNzZjNiJ9.eyJpYXQiOjE3NjExNTYxOTgsImV4cCI6NDkxNDc1NjE5OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.TIdnKae7PfipV1phcrKdPn2z0d8Yj_HrnxG5HsWa8Gw	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 18:03:18.369	\N	2025-11-07 08:29:22.465	\N
1627092982568060484	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImRmOTk3MmYyLWNmYjUtNGI3Ni04ZjRjLWYyODE5ZjU0MDYwNyJ9.eyJpYXQiOjE3NjExNTYxOTgsImV4cCI6NDkxNDc1NjE5OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.TLlBGmLqbWG2hb1tLaBIDX9s-u_DxYxZBUHJUlIBKtg	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 18:03:18.484	\N	2025-11-07 08:29:22.465	\N
1627092983708911183	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImZiZTZhMDJlLTQxMGItNDk4OS04ZjYzLTRjYzI2YTlhYmFlNCJ9.eyJpYXQiOjE3NjExNTYxOTgsImV4cCI6NDkxNDc1NjE5OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.O_Jl-9jBKbXRE28760wBXhFcwwIPJvL2bIO21ec2Rp4	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 18:03:18.62	\N	2025-11-07 08:29:22.465	\N
1627093220561258084	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImNhMjA0NDRmLTczMWQtNDFlMi04MjE2LTQ1ZDdiYzQ2NTVmOCJ9.eyJpYXQiOjE3NjExNTYyMjYsImV4cCI6NDkxNDc1NjIyNiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.gpqUkXpt0sZrFi33_zOrAPyOrAwiIC--TkzybvpnDy4	\N	172.18.0.15	Python/3.12 aiohttp/3.13.0	2025-10-22 18:03:46.853	\N	2025-11-07 08:29:22.465	\N
1627548712412644974	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImFiMmJlOTM2LTFiYWEtNDc3ZC04ZmQ3LTMyZjQ4ZTExZmExZSJ9.eyJpYXQiOjE3NjEyMTA1MjUsImV4cCI6NDkxNDgxMDUyNSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Udqk5hED0u55sb_2PTINohHh-jP_Qc8L7D7zwYhI6hg	6cac0238-c8b5-4d1d-9bf7-721b5a14d05c	172.18.0.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-23 09:08:45.709	\N	2025-11-07 08:29:22.465	\N
1636555341552420678	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjZjMWQ3MzUwLThjZWQtNGUwNC1hYzNmLWQ2ODQ3MzZiNDE0OCJ9.eyJpYXQiOjE3NjIyODQxOTksImV4cCI6NDkxNTg4NDE5OSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.n9bK5gYVa0oEk2HP7FZA4yLXCaFzLwK0ApNFAywv--I	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 19:23:19.572	\N	2025-11-07 08:29:22.465	\N
1627865015086220914	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjA2ZGZiMWM4LWJhNmQtNDJmMS1hYzhhLWI2MzI0NzU0YTEwMSJ9.eyJpYXQiOjE3NjEyNDgyMzEsImV4cCI6NDkxNDg0ODIzMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.GmCiFBGyyqxWsFp2HjcEwri2Ip_tH16mUSPF2fXp5oU	d21a6851-021e-4b05-ab38-d372b2a1f364	172.18.0.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.1 Safari/605.1.15	2025-10-23 19:37:11.92	\N	2025-11-07 08:29:22.465	\N
1628340410990462579	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJkMmJiMDgxLWQ2NjItNDBjNC1hOTMwLWZlMTkwZjU3MDY3MSJ9.eyJpYXQiOjE3NjEzMDQ5MDMsImV4cCI6NDkxNDkwNDkwMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.lsudNQvqwWMMq0PCWK3gRmDiOSTcFjZTnmIkgwfwL5U	ac65f0fb-3e92-46e7-8e83-29388d476656	172.18.0.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.1 Safari/605.1.15	2025-10-24 11:21:43.536	\N	2025-11-07 08:29:22.465	\N
1630695022531708621	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImE5Y2NlZjNlLTZiYWUtNGVhYi04NTIyLWQ5NzkzYmU5ZWJlMiJ9.eyJpYXQiOjE3NjE1ODU1OTUsImV4cCI6NDkxNTE4NTU5NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.coRInUthB2DHusWM9vmNtcHDNWeH0G6N_vPkxA8rUEA	0c9457f3-5749-40f5-8845-1c200ded0238	172.18.0.20	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-27 17:19:55.104	\N	2025-11-07 08:29:22.465	\N
1634802356480640727	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc2ODlmMjljLTg0YTUtNDM5Zi1iNGY3LTNhYTM5Y2FkYmVkOCJ9.eyJpYXQiOjE3NjIwNzUyMjcsImV4cCI6NDkxNTY3NTIyNywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ylp6TqkWZCnEKTwMtzYrEn1scwC-Ghnt7GiDTadmtUI	5bfda0b8-4f33-41c9-8431-5a6fb6c45cea	172.18.0.20	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-11-02 09:20:27.471	\N	2025-11-07 08:29:22.465	\N
1634825456123381474	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjI2MmMwN2IxLWRmMjMtNDViYi04OThjLWY3ZWVjZDQyNzRkMiJ9.eyJpYXQiOjE3NjIwNzc5ODEsImV4cCI6NDkxNTY3Nzk4MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.qd5mj5GDbN56cQrmycZoyhTOhI-bqvhqbu1mJVk7xes	\N	172.18.0.20	PostmanRuntime/7.49.0	2025-11-02 10:06:21.161	\N	2025-11-07 08:29:22.465	\N
1635448115542623984	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjkzZmI4MDdlLTk4MjQtNGI0OS05ODFkLWIwZTNhYThjZWVjYyJ9.eyJpYXQiOjE3NjIxNTIyMDcsImV4cCI6NDkxNTc1MjIwNywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.AagI-H27T6dNQO88k8ABXO2ruaoNVmPfA3AaoM1CP84	\N	172.18.0.20	PostmanRuntime/7.49.0	2025-11-03 06:43:27.948	\N	2025-11-07 08:29:22.465	\N
1636181107370100508	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjZlMjk2NmM2LTYxY2QtNGZmNi1hZjc4LWZlY2YxYjkxM2VjMSJ9.eyJpYXQiOjE3NjIyMzk1ODcsImV4cCI6NDkxNTgzOTU4Nywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.FwVUYxwug8eo_bNBsAXUhBofU8RHN20Mb4RGh9By_Zs	\N	172.18.0.6	Python-urllib/3.13	2025-11-04 06:59:47.375	\N	2025-11-07 08:29:22.465	\N
1636182529859913501	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjRiN2ZhMjZlLWU1OTMtNDFmNy1hYzVjLTJhNGFmMGYzY2NkZSJ9.eyJpYXQiOjE3NjIyMzk3NTYsImV4cCI6NDkxNTgzOTc1Niwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.9Aj4Qnu9Uprsm34pE7cxZAlNdgazX1URu13TYw0-ct0	\N	172.18.0.6	python-httpx/0.27.2	2025-11-04 07:02:36.958	\N	2025-11-07 08:29:22.465	\N
1636184278700132128	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjYzZjcyYjg2LTFhNjUtNGUzOC04NGYxLWMxYTViY2VhYjM3OSJ9.eyJpYXQiOjE3NjIyMzk5NjUsImV4cCI6NDkxNTgzOTk2NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.xlEl8BErHqXWbRr48cP9ALl8jadhP8UNaXz4SgaAf30	\N	172.18.0.6	python-httpx/0.27.2	2025-11-04 07:06:05.435	\N	2025-11-07 08:29:22.465	\N
1636184279522215715	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjMwY2M1NmFkLWQ5YjktNGRmYy1hMTI1LWI2YTU4NTAyMjExMCJ9.eyJpYXQiOjE3NjIyMzk5NjUsImV4cCI6NDkxNTgzOTk2NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.nCfbr9COyDxGILptpJhxq8TmZ-bQSA46Ycsz7253dds	\N	172.18.0.6	python-httpx/0.27.2	2025-11-04 07:06:05.534	\N	2025-11-07 08:29:22.465	\N
1636194979585984292	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjY3ZjBkZTVhLWFmNDgtNDAwOS05ZTY0LWRlYzEwYTBkYjBmMyJ9.eyJpYXQiOjE3NjIyNDEyNDEsImV4cCI6NDkxNTg0MTI0MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.r8mZxjbfCrQBBNR9-BP4Muk76JOFHJF8tswOz0dyX9M	\N	172.18.0.6	python-httpx/0.27.2	2025-11-04 07:27:21.08	\N	2025-11-07 08:29:22.465	\N
1636194980391290663	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImNkMDMzMWY0LTdkMjItNDkyNi04ZjU1LTUwYTc4MGFhNDc5ZiJ9.eyJpYXQiOjE3NjIyNDEyNDEsImV4cCI6NDkxNTg0MTI0MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.a_VTqXMk2xGS7mQVFuPMTSvUFbzDWlxyuFk4N6Xp-Lw	\N	172.18.0.6	python-httpx/0.27.2	2025-11-04 07:27:21.177	\N	2025-11-07 08:29:22.465	\N
1636362670242268972	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImRmYjIyZDY3LWMwNjMtNGU1Mi05MDcwLTk5YjczMjIxZGNkMyJ9.eyJpYXQiOjE3NjIyNjEyMzEsImV4cCI6NDkxNTg2MTIzMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.GDNAtoEVvp4jb8qiCGBJ5jqGJLYrL9xDO7RW_x1Shco	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 13:00:31.347	\N	2025-11-07 08:29:22.465	\N
1636362671391508271	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjNhMTQ4M2M1LTUxMzktNDdiMy1hYjhiLWUxZTAzYmI5YjY2NSJ9.eyJpYXQiOjE3NjIyNjEyMzEsImV4cCI6NDkxNTg2MTIzMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.2xYKvm4X_SLCEAXcH4DolJJoNVX95FELmuzYdt6CA4o	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 13:00:31.503	\N	2025-11-07 08:29:22.465	\N
1636366527567497012	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjYzMmYwYzZlLTFjNjItNGUyMy05YTg4LWRmYjIyNWJjMmE4YSJ9.eyJpYXQiOjE3NjIyNjE2OTEsImV4cCI6NDkxNTg2MTY5MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.HhW7ADDIwmC--pFNa1DnckwXLT0VjmyqYlQxXPnBqgk	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 13:08:11.19	\N	2025-11-07 08:29:22.465	\N
1636366528439912247	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjY2YjVhOThmLTIzMDAtNDllMC05MTA0LTk5ZGYxY2NlODdmNiJ9.eyJpYXQiOjE3NjIyNjE2OTEsImV4cCI6NDkxNTg2MTY5MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.f_vve9HghPSvC5wiIqzhLYHA87cfTnzpnUGx2SrsebU	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 13:08:11.298	\N	2025-11-07 08:29:22.465	\N
1636366529186498364	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImIzODBkMmMzLTY5NjYtNDc5OS05YmQ2LWFjYzE2MDJmMDQ2OCJ9.eyJpYXQiOjE3NjIyNjE2OTEsImV4cCI6NDkxNTg2MTY5MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.yTNh5WGB3uIz24qg4ClQw_Xed1gnq5Q8R1rDlRTuU7U	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 13:08:11.389	\N	2025-11-07 08:29:22.465	\N
1636423058640078653	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImMzYmIzOGM0LWExNGUtNGQzYy1hMjhhLWViNjczYTJhMDg5NSJ9.eyJpYXQiOjE3NjIyNjg0MzAsImV4cCI6NDkxNTg2ODQzMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ZHsrtv4QBrj3OAwSxQWxkQoVvmDpT_mC59U3w76Pu4E	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 15:00:30.222	\N	2025-11-07 08:29:22.465	\N
1636498709413889856	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjgwMDlhZmRjLTdiZjgtNDBkMC05ZGY5LTAxNWI2ODg3YmYyMyJ9.eyJpYXQiOjE3NjIyNzc0NDgsImV4cCI6NDkxNTg3NzQ0OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ZAqtkZX1PZF6204cO9GWXkFu5hBscSrhZJxLtDVVrto	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 17:30:48.489	\N	2025-11-07 08:29:22.465	\N
1636537680428795713	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImFhZmE1ZWJlLWQ1OGUtNGFmYS1hNzBlLTU2YzExYTJmYTZkYiJ9.eyJpYXQiOjE3NjIyODIwOTQsImV4cCI6NDkxNTg4MjA5NCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.D7tn6WOsVgNqR4oYe9iIO5T9_WGgW_6ZBJwv9H-6oVs	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 18:48:14.204	\N	2025-11-07 08:29:22.465	\N
1636538679285516098	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjIxZGQxOWQ2LThkZmUtNGFhYi1iOTY2LTYyZmE1MWY0ODY1NiJ9.eyJpYXQiOjE3NjIyODIyMTMsImV4cCI6NDkxNTg4MjIxMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.fjYr_f5MREs_C68lZEqmp3_5AWpe2GPHHExj5S7EvME	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 18:50:13.277	\N	2025-11-07 08:29:22.465	\N
1636543758906427203	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImU2MWJlMjI1LTQxOWUtNDFkZi1hMDcxLTNhMWM5MjNhOGJiYSJ9.eyJpYXQiOjE3NjIyODI4MTgsImV4cCI6NDkxNTg4MjgxOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.CHlhWsjBU8DvtwkqsBv61DsTJyTwsjIVjTaUA6lDEh0	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 19:00:18.814	\N	2025-11-07 08:29:22.465	\N
1636560255481546567	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg1OWIzM2NhLTkzNjMtNDNmNS1iODlhLTY1NzNmNmFhZTNlMSJ9.eyJpYXQiOjE3NjIyODQ3ODUsImV4cCI6NDkxNTg4NDc4NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.lgveVyfRpHz9aqTLvlnowG4bLMX0HwoZ-H7YPHeZjro	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 19:33:05.359	\N	2025-11-07 08:29:22.465	\N
1636569167815509832	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjkzZmNmMDkwLWI3NjQtNGE2Mi05NGM3LTQ0MjUzNmE3ODQwMCJ9.eyJpYXQiOjE3NjIyODU4NDcsImV4cCI6NDkxNTg4NTg0Nywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.gEAE8cTDqStFmahpxsjlGG2BxZpHFvvJnZ2ShdCbNbE	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 19:50:47.793	\N	2025-11-07 08:29:22.465	\N
1636569886425614153	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjFiOWJmYTQzLWYwMjctNGE1ZS1hZmM4LTBjY2VjMTRhN2Y5MSJ9.eyJpYXQiOjE3NjIyODU5MzMsImV4cCI6NDkxNTg4NTkzMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Wwnqt9NSuk-SHQzas4IQKFYLVoECHVB6Jhk-yDEOe-s	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 19:52:13.457	\N	2025-11-07 08:29:22.465	\N
1636570285622691658	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijk3Y2VjODM2LTU1MjAtNDMzZi1hNDdkLTIzZjZhNzM4MDBhYSJ9.eyJpYXQiOjE3NjIyODU5ODEsImV4cCI6NDkxNTg4NTk4MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.CKjNksfRSm6v6kIAF4YWZfDZj2ojVoP4xe2azC88JuU	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 19:53:01.043	\N	2025-11-07 08:29:22.465	\N
1636574684642281291	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjY5Y2Q5NGMyLWJlZmMtNDRlMi05ZGQ5LTczMzA1ZTEwZjkwZSJ9.eyJpYXQiOjE3NjIyODY1MDUsImV4cCI6NDkxNTg4NjUwNSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Z0c_toVQjdE1lXYk61HPU5hxf1DfMlI7-TSFWgGrpnA	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 20:01:45.45	\N	2025-11-07 08:29:22.465	\N
1636578026839869260	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImUxNzA2ZGY4LWJlZjUtNGM0OC1hMDI2LWI5MmRiOGJkZGMyYiJ9.eyJpYXQiOjE3NjIyODY5MDMsImV4cCI6NDkxNTg4NjkwMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.V-iYXe-mozTqjXfkJidEQzcwTylg8fY8meMN31Z5dKM	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 20:08:23.87	\N	2025-11-07 08:29:22.465	\N
1636581031916078925	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjgyMjZlNTE2LTE5M2EtNDgwZS1hMWM4LTZkNWM3MTVmYmFlOCJ9.eyJpYXQiOjE3NjIyODcyNjIsImV4cCI6NDkxNTg4NzI2Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.jAXrfXyIhoBLnaTE6U2SL4gEepAHNU27BN6_oTFfoQc	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 20:14:22.095	\N	2025-11-07 08:29:22.465	\N
1636582546705745742	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImEyZGE5YWJkLWNmZWItNGFhNi1iZDhkLTM3MmJlN2YxNzY5NyJ9.eyJpYXQiOjE3NjIyODc0NDIsImV4cCI6NDkxNTg4NzQ0Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.cit9OubYXb1qWrf9TKIepIFabg0ESBKqcm6-YG5K2cc	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 20:17:22.681	\N	2025-11-07 08:29:22.465	\N
1636602006338537297	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjBlOGY1MDhmLWU0ZGMtNGZlOS1hNGY0LTQzZTA1Y2UyMmI0OCJ9.eyJpYXQiOjE3NjIyODk3NjIsImV4cCI6NDkxNTg4OTc2Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.pcMXT8HtyL318EUa7b10oF1dYCK1IBgxcmdXldy6iS0	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 20:56:02.45	\N	2025-11-07 08:29:22.465	\N
1636618542222673748	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImRhNWNjMzE1LTZlNWItNDBjNy1iYzNmLTcyMWY3MjliM2FhNSJ9.eyJpYXQiOjE3NjIyOTE3MzMsImV4cCI6NDkxNTg5MTczMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.3Euoh6edRGfMU75FovviGXq3cm1g9awX386XH3wV53I	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:28:53.68	\N	2025-11-07 08:29:22.465	\N
1636618543170586455	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjEwNTYxZGNkLTJkNmYtNGY5NC1iYWUwLWFhNzFjNDFlMzc4NCJ9.eyJpYXQiOjE3NjIyOTE3MzMsImV4cCI6NDkxNTg5MTczMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.3tF9yDxA-lmUQBGd4-sHT-LOjJbCAEdw1-8naULZz50	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:28:53.796	\N	2025-11-07 08:29:22.465	\N
1636621051263715164	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJjY2QxNGI3LTAzZTAtNDU0YS04OTNmLTFhY2I0MTAwMzJkNCJ9.eyJpYXQiOjE3NjIyOTIwMzIsImV4cCI6NDkxNTg5MjAzMiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Rr2vbdYkr3AVI4uWrOFb_UfmOHjpGcKTIxrcpTCBeNo	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:33:52.781	\N	2025-11-07 08:29:22.465	\N
1636621052161296223	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjFhYTZiZGRjLTkzZDUtNDU1MC1iOTVhLTY2YTg0YTI1ZmQyZSJ9.eyJpYXQiOjE3NjIyOTIwMzIsImV4cCI6NDkxNTg5MjAzMiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.NKF2vHhyHxOyeSOeOjSFsp5q9__5p1K2udYmr50P_QI	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:33:52.89	\N	2025-11-07 08:29:22.465	\N
1636622652187608932	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg5NmQwMGEwLTc5YzctNGIwZi05NzMxLTUzNzg5MTQ1ZmZmYyJ9.eyJpYXQiOjE3NjIyOTIyMjMsImV4cCI6NDkxNTg5MjIyMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.kRTWoF43nPfIz8-mWMxImOmz60_s7NfoBHMl-GRfLyw	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:37:03.624	\N	2025-11-07 08:29:22.465	\N
1636622653026469735	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjViZWVkNTFjLWRmZWYtNGE1Yy04ZjJlLTU5ZjJhYzE3M2ZmNCJ9.eyJpYXQiOjE3NjIyOTIyMjMsImV4cCI6NDkxNTg5MjIyMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.oKNUj7yywiTcAyflBK7fITNxN62Ym1M9zIvILDITZgs	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:37:03.73	\N	2025-11-07 08:29:22.465	\N
1636622653806610284	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjFjYTBhY2JkLWFjZTMtNDk1NS1hZmQ0LWQ2ZmYyOWUyY2QwYSJ9.eyJpYXQiOjE3NjIyOTIyMjMsImV4cCI6NDkxNTg5MjIyMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.6shUHZ80DlNLhBgdH-bAomqXe_zSfPMb8CLfBRmP-Jg	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:37:03.823	\N	2025-11-07 08:29:22.465	\N
1636624464462481262	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjM4MjA0MDQ5LWVjZjktNGMzZS1hYTYzLWIyYTc4YTU0Yzk5NyJ9.eyJpYXQiOjE3NjIyOTI0MzksImV4cCI6NDkxNTg5MjQzOSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.l3P9mPAp9ZJQdAE73_-KAaZd-3HrxyYK1oOw7gMpDD4	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:40:39.665	\N	2025-11-07 08:29:22.465	\N
1636624465267787633	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjRkZWRiNWY3LTc0M2EtNDZjMi05YjQzLTZhYmU5ZWZlMmQ2MCJ9.eyJpYXQiOjE3NjIyOTI0MzksImV4cCI6NDkxNTg5MjQzOSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.WeS47McalUfdW8xeOZftXdtTYpKx8LMQfXa-XasjMbs	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:40:39.765	\N	2025-11-07 08:29:22.465	\N
1636624466316363638	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImI2MWQ1NzkwLTI2OWYtNDJmYi1hNjM4LTkzNmMxNjNkMGFhZCJ9.eyJpYXQiOjE3NjIyOTI0MzksImV4cCI6NDkxNTg5MjQzOSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.IJcMKWFVYqF9I-gPVw3Ecg3j0_HbCQ8JTes6WIzLh6E	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:40:39.891	\N	2025-11-07 08:29:22.465	\N
1636624467339773821	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImIyYzQ4ZmM0LWY3ODQtNDY3ZS1iNmQ5LTJlY2E2YmNmYjliZiJ9.eyJpYXQiOjE3NjIyOTI0NDAsImV4cCI6NDkxNTg5MjQ0MCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Hv6wtCuq8ivI_F_QQtxbi8-VLr9zvBzwyLaLZEqp1KI	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:40:40.013	\N	2025-11-07 08:29:22.465	\N
1636624468094748545	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjNkM2Q4NmNjLTJmZWEtNDNkMS1hOTdmLWFjYjJhZmFhZTMxNCJ9.eyJpYXQiOjE3NjIyOTI0NDAsImV4cCI6NDkxNTg5MjQ0MCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.kbXUoVSDK0TcKQoUGGiGpmOEbM-ZT-hwLx-GHZ-ro1Y	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:40:40.103	\N	2025-11-07 08:29:22.465	\N
1636624469294319503	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImE3ZDFiYTNiLTJhYTYtNGI1OS1iNjUwLWQ0ZGE4NDQ5OTUwMSJ9.eyJpYXQiOjE3NjIyOTI0NDAsImV4cCI6NDkxNTg5MjQ0MCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.vgnZ_36x64d1Xt6PRxfvDNTSXfHZw8maOgPIYYfYmc4	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:40:40.245	\N	2025-11-07 08:29:22.465	\N
1636626841273894802	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjY2MWM4ZjQ1LTEyMWMtNGI5ZS05ODIxLWE2Mzk2YTg1YWQxYyJ9.eyJpYXQiOjE3NjIyOTI3MjMsImV4cCI6NDkxNTg5MjcyMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.rUAEknvCtszf6sFwUmwja0IoD_chxuuxnMu5xA1K-88	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:45:23.006	\N	2025-11-07 08:29:22.465	\N
1636626842121144213	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQ0MmM5MDAyLWRiNjAtNDNkMC05YThjLTk3YjUzMjAyNDYxNyJ9.eyJpYXQiOjE3NjIyOTI3MjMsImV4cCI6NDkxNTg5MjcyMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.dMbamyDwePkHaG8jNruDan4w5G6dJUZlcAKqWsVy7VM	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:45:23.107	\N	2025-11-07 08:29:22.465	\N
1636626842968393626	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjZjZmQwZTdmLTA2ZWYtNDE5Yy1iM2JmLWJmNWM0NWYwOWUyYSJ9.eyJpYXQiOjE3NjIyOTI3MjMsImV4cCI6NDkxNTg5MjcyMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.lT2PhABAq6CL6dFYDSKWsK3qtvXczNdC6pkpQ0s-3AU	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:45:23.21	\N	2025-11-07 08:29:22.465	\N
1636626843966637985	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImVmMDUxM2ZhLTNhMWYtNDE2MS1hZDJiLTE3NWNkNjhhYzNiOSJ9.eyJpYXQiOjE3NjIyOTI3MjMsImV4cCI6NDkxNTg5MjcyMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.NuEdsHzvlzYCTEQ1hHft6yC0XhWTsR33xabXUgevdSI	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:45:23.329	\N	2025-11-07 08:29:22.465	\N
1636629172140902306	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjZlYWY3NGZiLTYxZTUtNGY0Zi05N2EzLTYyMTJiN2M3Mzk4OCJ9.eyJpYXQiOjE3NjIyOTMwMDAsImV4cCI6NDkxNTg5MzAwMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9._ZnZpqdhjWEb2yZzOe-DEnHoBn46Na-0logD1804jdw	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:50:00.864	\N	2025-11-07 08:29:22.465	\N
1636629173004928933	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjAwMTI5Njg4LTZmNWQtNGQ2My1iZjFjLWEyZTA2N2Y2ZWNlOCJ9.eyJpYXQiOjE3NjIyOTMwMDAsImV4cCI6NDkxNTg5MzAwMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.X1OVv3XE_wT0QZbjzKTQwoKx7Q5lKj14wLENQTdFmXM	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:50:00.971	\N	2025-11-07 08:29:22.465	\N
1636629173734737834	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjVlNWE5MDliLTUzNDctNDk1Yy05MWUyLTc2YTU0Mjc1ZThkMSJ9.eyJpYXQiOjE3NjIyOTMwMDEsImV4cCI6NDkxNTg5MzAwMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.S6mASqcUMmWjPGdU6u-YSfrAqZ_t5GljCP_oYrgLibg	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:50:01.058	\N	2025-11-07 08:29:22.465	\N
1636629174758148017	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImNkZjk3NDQ0LTUzMDItNGI4Ny1hZjUwLTNmMTA1MzE0OTU3OCJ9.eyJpYXQiOjE3NjIyOTMwMDEsImV4cCI6NDkxNTg5MzAwMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.IzskG6e5KmbbpnHGqRxRc9DGGHN543KB14HVXzM2V8g	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:50:01.18	\N	2025-11-07 08:29:22.465	\N
1636629175513122741	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQ2NmM2YTU4LTUwZTItNDMwMi1hMjM1LWZkYzFmMWVhZjM4ZCJ9.eyJpYXQiOjE3NjIyOTMwMDEsImV4cCI6NDkxNTg5MzAwMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.EkGt0AQEfHPZ8a9zcq_Ko6TPiy7G8zVdDwaJopY_QQA	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:50:01.271	\N	2025-11-07 08:29:22.465	\N
1636629176670750659	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjRmMjE0ZDk3LWM5MTItNGU2MS05MWE3LTJhMmJiYTk3NjkyNCJ9.eyJpYXQiOjE3NjIyOTMwMDEsImV4cCI6NDkxNTg5MzAwMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.tDVRpKlq7Tege7M8Rd9RRsQcXrmquZt7or3j0znEQ1s	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 21:50:01.408	\N	2025-11-07 08:29:22.465	\N
1636635390792173510	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjlhNGUwNzg3LWM4ODItNDQ3ZC1iMjRiLWJjOTc4OWY3MDBlNyJ9.eyJpYXQiOjE3NjIyOTM3NDIsImV4cCI6NDkxNTg5Mzc0Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.t8no855pYjfbNYgHXZil9Z7U6hBNA6ZARdZSUcxP_z8	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 22:02:22.187	\N	2025-11-07 08:29:22.465	\N
1636635391790417865	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImFkZWZiNjk3LWQzMGEtNGE3Ny04NGIwLTRkZjZlZjU4YTM0MiJ9.eyJpYXQiOjE3NjIyOTM3NDIsImV4cCI6NDkxNTg5Mzc0Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.dXIpBSjfGJyd-sUlqgzqPO1HB2aR3M7EbIcAd4Cpf54	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 22:02:22.308	\N	2025-11-07 08:29:22.465	\N
1636635392520226766	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjYyMGFiNjU5LWVhZTYtNDBlNS1iNGMwLTUyY2JlZGYwM2MwZSJ9.eyJpYXQiOjE3NjIyOTM3NDIsImV4cCI6NDkxNTg5Mzc0Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.8d5MgY07kyvDqrF0KuMlC-5xXjgbnq6X8lpMyusNNfw	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 22:02:22.396	\N	2025-11-07 08:29:22.465	\N
1636635393610745813	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImYwMDQxYjg5LTA4MWYtNDg1MC1hOGM5LTg3YmIzZTUzOGE4NiJ9.eyJpYXQiOjE3NjIyOTM3NDIsImV4cCI6NDkxNTg5Mzc0Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.4Oxgsxg-TlrtEnBZ8MG3M52sTY9-j4PRt6e-Z3fuOEA	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 22:02:22.526	\N	2025-11-07 08:29:22.465	\N
1636635394416052185	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjM1OTFjNjZiLWU3YjEtNGQ1Yy05MzI0LWFhOWY2NWIwZjMyMSJ9.eyJpYXQiOjE3NjIyOTM3NDIsImV4cCI6NDkxNTg5Mzc0Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.t1OXmEzK0kPA9cPGnFSveKXGK9DSIguHWGDd4R5LGj4	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 22:02:22.621	\N	2025-11-07 08:29:22.465	\N
1636635395825338343	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjRhNDNmZTA0LWFkODAtNDNjMi05ZGQzLWQ0ZjhlYjllZWZjMCJ9.eyJpYXQiOjE3NjIyOTM3NDIsImV4cCI6NDkxNTg5Mzc0Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.2S-l1zgCwnYrQkYl15EWO05N6LG9HyRlhyzqInN6N0c	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 22:02:22.79	\N	2025-11-07 08:29:22.465	\N
1636639386932086762	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjFmZGU2OGFiLTE4NmItNDYyZS04Yjc0LTk3NDYyYTY2YTI0YSJ9.eyJpYXQiOjE3NjIyOTQyMTgsImV4cCI6NDkxNTg5NDIxOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.IM4h6E-9r55LydFN4q4IIFRJwcxEKhDkk48oaMYj6Qo	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 22:10:18.564	\N	2025-11-07 08:29:22.465	\N
1636639387720615917	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc1YzQ4MjIzLWI4NDYtNDZlOS1hYzhjLTEwYjJmMTQxZGVlYSJ9.eyJpYXQiOjE3NjIyOTQyMTgsImV4cCI6NDkxNTg5NDIxOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ZQ9OLweUGfqFt5beEQjZRcSvkHTXkJzxt_gMRGskf04	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 22:10:18.661	\N	2025-11-07 08:29:22.465	\N
1636639388433647602	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjE2MmNmYTYxLTA4MGUtNDk5Mi1hMzRjLTY0ODdjYmMyYTU5ZiJ9.eyJpYXQiOjE3NjIyOTQyMTgsImV4cCI6NDkxNTg5NDIxOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.SJLwaR0qtEYwjSk4sdEfvD5FYccdgi5MYY-eq8iODQg	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 22:10:18.745	\N	2025-11-07 08:29:22.465	\N
1636639389499000825	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjhmZTcwMmI3LWM1NDQtNDc2ZC1hZDQ0LTU2NTM3YjU2NDU4YyJ9.eyJpYXQiOjE3NjIyOTQyMTgsImV4cCI6NDkxNTg5NDIxOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.yz-Y76NyXbAm5FfbaURVP1rMydos6uWpwk6RBm1RhOw	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 22:10:18.872	\N	2025-11-07 08:29:22.465	\N
1636639390228809725	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImMzYWQwNzE5LTZkZmMtNGY2OC1hMGFhLWJjYjJkNWYyYzhiMyJ9.eyJpYXQiOjE3NjIyOTQyMTgsImV4cCI6NDkxNTg5NDIxOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.3Bk2IV-cfMZVtj0hFArK6J7kukxD8unqY2PDrJncmfQ	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 22:10:18.96	\N	2025-11-07 08:29:22.465	\N
1636639391562597387	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjE5MzllNmE5LTczNTEtNGNlNi1iZmE1LWEzMjBkNWNmOWQ3NSJ9.eyJpYXQiOjE3NjIyOTQyMTksImV4cCI6NDkxNTg5NDIxOSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.dlgJSh7sQA5VPoP1l6bOrXSA4Xyqbjcq_ADpn25MRcI	\N	172.18.0.6	python-httpx/0.28.1	2025-11-04 22:10:19.119	\N	2025-11-07 08:29:22.465	\N
1637116326331810831	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg4Nzc2MWQ3LWVjM2ItNDhkMy1iYWRkLTdhMDMwOWUwY2RlYyJ9.eyJpYXQiOjE3NjIzNTEwNzQsImV4cCI6NDkxNTk1MTA3NCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.wI2KTbHblptZ_EJ2Wu_M_uH9NYE0iroMVTySJNHffqY	\N	172.18.0.6	Python-urllib/3.14	2025-11-05 13:57:54.163	\N	2025-11-07 08:29:22.465	\N
1637116398322844688	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjM0YWNmYmI1LTY0ZDAtNDE3My04OWNiLTk3ZjRlN2EwMjVhMiJ9.eyJpYXQiOjE3NjIzNTEwODIsImV4cCI6NDkxNTk1MTA4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.hWmWdGJPxsRUSvJXKl8YulTS69RdnruKs5ALw-rcg6M	\N	172.18.0.6	Python-urllib/3.14	2025-11-05 13:58:02.755	\N	2025-11-07 08:29:22.465	\N
1637202878529537080	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjgzMjkyYWM3LTAyYjMtNDdhOS1hMDhlLTMzNjAyOGI5ZDFkNiJ9.eyJpYXQiOjE3NjIzNjEzOTEsImV4cCI6NDkxNTk2MTM5MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Cfk7cM14nPnHhRJ7HK0tg9Kc0oJSKrCn0Z3KAxiHnng	\N	172.18.0.6	curl/8.7.1	2025-11-05 16:49:51.989	\N	2025-11-07 08:29:22.465	\N
1637379573190493243	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjFmNzY0ZjdjLWU1YmQtNGQ2MC05MTU2LTViMmE3ZDUzNzllOCJ9.eyJpYXQiOjE3NjIzODI0NTUsImV4cCI6NDkxNTk4MjQ1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.tyipti3up5JeDGuhIwIaVOSkFMLlG0OzWRdpCQijslk	\N	172.18.0.6	modelcontextprotocol/servers/planka/v0.1.0 Node.js/24	2025-11-05 22:40:55.639	\N	2025-11-07 08:29:22.465	\N
1637771579049903167	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImRkYjU1ZmFkLTRkMDgtNDE0Yy1iOWFkLTZmM2FkNWFhNTVlMiJ9.eyJpYXQiOjE3NjI0MjkxODYsImV4cCI6NDkxNjAyOTE4Niwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.kOAEMn9XsyBTRArkfPXHt6WWAR19-yZ4FHF4LC-FOIU	2a1a4935-fbff-40ed-9e99-44477b01382c	172.18.0.6	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 OPR/122.0.0.0	2025-11-06 11:39:46.382	\N	2025-11-07 08:29:22.465	\N
1637814492794455104	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQzZGQ1NzE1LWU0ODgtNDNhNy1hODczLTU4NDBkOTBlNWQ4NyJ9.eyJpYXQiOjE3NjI0MzQzMDIsImV4cCI6NDkxNjAzNDMwMiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.0mmnp7FWAKkhMN9BVwDoap_DwqStpEJTm9MO3Xl_0lw	\N	172.18.0.6	Bun/1.2.23	2025-11-06 13:05:02.092	\N	2025-11-07 08:29:22.465	\N
1637877167582872651	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjllODU0MjhiLTM2YzgtNGVmOS05NmY1LTRiNTFmY2YxZGYzYiJ9.eyJpYXQiOjE3NjI0NDE3NzMsImV4cCI6NDkxNjA0MTc3Mywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.xmPSEhEaVJm4wO8p0xrsNJ0sWNYI1zshB0MDLziaXAE	\N	172.18.0.6	Bun/1.2.23	2025-11-06 15:09:33.51	\N	2025-11-07 08:29:22.465	\N
1638393359846343757	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImYwODI5M2Q1LTI2YWUtNDdhOS04OGIxLTNmMjQyYzBmY2MwOCJ9.eyJpYXQiOjE3NjI1MDMzMDgsImV4cCI6NDkxNjEwMzMwOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.MaAk9IPVvW_4ZvkA5i0HHkee5rbr7Ac2lr8M8lqfYc0	\N	172.18.0.6	modelcontextprotocol/servers/planka/v0.1.0 Node.js/24	2025-11-07 08:15:08.428	\N	2025-11-07 08:29:22.465	\N
1638777790868227152	1560328737491256322	\N	\N	172.18.0.6	curl/8.7.1	2025-11-07 20:58:56.178	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImM4OTMwZDk1LTQ0MWItNDFhYi05YjNlLWQwMDJhZDQwOTQ2YiJ9.eyJpYXQiOjE3NjI1NDkxMzYsImV4cCI6MTc2MjU0OTczNiwic3ViIjoiYWNjZXB0LXRlcm1zIn0._JYGz7aF16fph7oxf_fBP5QcfyBaLe6ugwaH7b_ylbI
1639160226894578769	1560328737491256322	\N	\N	172.18.0.6	curl/8.7.1	2025-11-08 09:38:46.105	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQ5ZDI0MjZmLWJhZjYtNGRmZS1iMGQ0LTFiZTliY2I1YzM2NSJ9.eyJpYXQiOjE3NjI1OTQ3MjYsImV4cCI6MTc2MjU5NTMyNiwic3ViIjoiYWNjZXB0LXRlcm1zIn0.S6oCSGExaeDBaiZE_c1S6TU8_VOi6kgpuap369jNEo8
1639160256724468818	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjA2ODdhOWY1LTlmODgtNDk4Ni1hMjZmLWJlZDllYzY3OWMyMCJ9.eyJpYXQiOjE3NjI1OTQ5MzEsImV4cCI6NDkxNjE5NDkzMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.I1JDqfy7OzP6fFYDm2RFvUmRuVN8qtMf-8lPXepR3Lo	\N	172.18.0.6	curl/8.7.1	2025-11-08 09:38:49.663	2025-11-08 09:42:11.851	\N	\N
\.


--
-- Data for Name: storage_usage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.storage_usage (id, total, user_avatars, background_images, attachments, created_at, updated_at) FROM stdin;
1	0	0	0	0	2025-11-07 08:29:22.407578	\N
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task (id, task_list_id, assignee_user_id, "position", name, is_completed, created_at, updated_at, linked_card_id) FROM stdin;
1626890534259787057	1626890499530949936	\N	65536	task	f	2025-10-22 11:21:04.766	\N	\N
1634824081566074589	1634803184562079449	1560328737491256323	65536	TaskTitle - TaskReferenceID - TaskStateReference	f	2025-11-02 10:03:37.303	2025-11-02 10:05:03.571	\N
1634824442695648991	1634824401155262174	1560328737491256323	65536	TaskTitle - TaskReferenceID - TaskStateReference	f	2025-11-02 10:04:20.353	2025-11-02 10:05:05.631	\N
1634824608949470945	1634824583389382368	\N	65536	TaskTitle - TaskReferenceID - TaskStateReference	f	2025-11-02 10:04:40.172	2025-11-02 10:05:07.128	\N
1635647558657246998	1635621825192920820	\N	229376	Provide a task list for the QA Task List given the card label: {{card.card_label}}, card title: {{card.title}}, card description: {{card.description}}, acceptance criteria {{card.acceptance_criteria}}, and the DOING task list {{card.todo_task_list}} | CARD_REQUEST, CARD | CARD {qa_task_list:{task_index:Integer, task_title, task_inputs, task_output, task_output_schema}}	f	2025-11-03 13:19:43.421	2025-11-03 13:20:08.671	\N
1634824058203801308	1634803011739977432	1560328737491256323	65536	TaskTitle - TaskReferenceID - TaskStateReferences [IN: OBJECT, OBJECT, OBJECT, OUT:OBJECT]	f	2025-11-02 10:03:34.515	2025-11-03 12:28:33.783	\N
1635639275007510289	1635621825192920819	\N	327680	Provide 4 scenario titles for BDD acceptance criteria to evaluate the card during quality inspection |  [CARD_LABEL, CARD_REQUEST, CARD_DESCRIPTION] | CARD {scenarios:{index:Integer, {feature_title: String}}}	f	2025-11-03 13:03:15.932	\N	\N
1635639327050434322	1635621825192920819	\N	393216	For scenario title {{scenarios[0].title}} define the BDD acceptance criteria in gherkin |  [CARD_LABEL, CARD_REQUEST, CARD_DESCRIPTION, SCENARIO_TITLES] | CARD {scenarios:{index:Integer, {scenario_content: String (gherkin)}}}	f	2025-11-03 13:03:22.139	2025-11-03 13:08:44.432	\N
1635640523928635155	1635621825192920819	\N	458752	For scenario {{title scenarios[1].title}} define the BDD acceptance criteria in gherkin |  [CARD_LABEL, CARD_REQUEST, CARD_DESCRIPTION, SCENARIO_TITLES] | CARD {scenarios:{index:Integer, {scenario_content: String (gherkin)}}}	f	2025-11-03 13:05:44.813	2025-11-03 13:08:50.77	\N
1635641068961662740	1635621825192920819	\N	524288	For scenario {{title scenarios[2].title}} define the BDD acceptance criteria in gherkin |  [CARD_LABEL, CARD_REQUEST, CARD_DESCRIPTION, SCENARIO_TITLES] | CARD {scenarios:{index:Integer, {scenario_content: String (gherkin)}}}	f	2025-11-03 13:06:49.787	2025-11-03 13:08:57.483	\N
1635631806579476238	1635621825192920820	\N	196608	Provide a task list for the DOING Task List given the card label: {{card.card_label}}, card title: {{card.title}}, card description: {{card.description}}, acceptance criteria {{card.acceptance_criteria}}, and the TODO task list {{card.todo_task_list}} | CARD_REQUEST, CARD | CARD {doing_task_list:{task_index:Integer, task_title, task_inputs, task_output, task_output_schema}}	f	2025-11-03 12:48:25.628	2025-11-03 13:20:14.62	\N
1635626798614054665	1635621825192920819	\N	196608	Based on the context create a card description | [PROJECT, CARD_LABEL, CARD_REQUEST] | CARD {description: String}	f	2025-11-03 12:38:28.63	2025-11-03 12:55:40.862	\N
1635648104747239191	1635621825192920820	\N	327680	Provide a task list for the DONE Task List given the card label: {{card.card_label}}, card title: {{card.title}}, card description: {{card.description}}, acceptance criteria {{card.acceptance_criteria}}, and the DOING task list {{card.doing_task_list}} | CARD_REQUEST, CARD | CARD {qa_task_list:{task_index:Integer, task_title, task_inputs, task_output, task_output_schema}}	f	2025-11-03 13:20:48.516	\N	\N
1635641112582424341	1635621825192920819	\N	589824	For scenario title {{scenarios[3].title}} define the BDD acceptance criteria in gherkin |  [CARD_LABEL, CARD_REQUEST, CARD_DESCRIPTION, SCENARIO_TITLES] | CARD {scenarios:{index:Integer, {scenario_content: String (gherkin)}}}	f	2025-11-03 13:06:54.991	2025-11-03 13:09:05.691	\N
1635621825251641087	1635621825192920821	1560328737491256323	65536	Evaluate the completess of the {{card}} and identify which item on the card is ambiguous or unclear | CARD | CARD_FEEDBACK {item:String:{feedback: String}}	f	2025-11-03 12:28:35.761	2025-11-03 13:41:07.149	\N
1635629919822153482	1635621825192920819	\N	262144	Based on the context create the card title for a card described with {{card.description}} | [CARD_LABEL, CARD_REQUEST, CARD_DESCRIPTION] | CARD {title: String}	f	2025-11-03 12:44:40.707	2025-11-03 13:09:44.485	\N
1635648737843873560	1635621825192920819	\N	81920	PROJECT = planka.get_project(project_id)	f	2025-11-03 13:22:03.991	2025-11-03 13:22:50.099	\N
1635634623549540111	1635621825192920819	\N	163840	Based on the context decide the card label | [PROJECT, CARD_REQUEST, CARD_LABEL_LIST] | CARD {card_label: Enum}	f	2025-11-03 12:54:01.435	2025-11-03 13:12:10.017	\N
1635631754737878797	1635621825192920820	\N	131072	Provide a task list for the TODO Task List given the card label: {{card.card_label}}, card title: {{card.title}}, card description: {{card.description}}, acceptance criteria {{card.acceptance_criteria}} | CARD_REQUEST, CARD | CARD {todo_task_list:{task_index:Integer, task_title, task_inputs, task_output, task_output_schema}}	f	2025-11-03 12:48:19.447	2025-11-03 13:18:44.346	\N
1635659290435913498	1635621825192920821	\N	131072	Decide if the card feedback should warrant returning the card back to the DOING list card feedback {{card_feedback}} card {{card}} | CARD, CARD_FEEDBACK | QA_PASS {boolean}	f	2025-11-03 13:43:01.957	\N	\N
1635649481712076569	1635621825192920819	\N	122880	CARD_REQUEST = state_store.get(card_request_id)	f	2025-11-03 13:23:32.659	2025-11-03 13:23:37.121	\N
\.


--
-- Data for Name: task_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_list (id, card_id, "position", name, show_on_front_of_card, created_at, updated_at, hide_completed_tasks) FROM stdin;
1626890499530949936	1626139517612197737	65536	Task List	t	2025-10-22 11:21:00.626	\N	f
1634803011739977432	1627548744566179439	65536	TODO TASK LIST	t	2025-11-02 09:21:45.582	2025-11-02 10:02:51.93	f
1634803184562079449	1627548744566179439	131072	DOING TASK LIST	t	2025-11-02 09:22:06.185	2025-11-02 10:02:58.623	f
1634824401155262174	1627548744566179439	196608	QA TASK LIST	t	2025-11-02 10:04:15.399	\N	f
1634824583389382368	1627548744566179439	262144	DONE TASK LIST	t	2025-11-02 10:04:37.124	\N	f
1635621825192920819	1635621824966428401	65536	TODO TASK LIST	t	2025-11-03 12:28:35.757	\N	f
1635621825192920820	1635621824966428401	131072	DOING TASK LIST	t	2025-11-03 12:28:35.757	\N	f
1635621825192920821	1635621824966428401	196608	QA TASK LIST	t	2025-11-03 12:28:35.757	\N	f
1635621825192920822	1635621824966428401	262144	DONE TASK LIST	t	2025-11-03 12:28:35.757	\N	f
\.


--
-- Data for Name: uploaded_file; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.uploaded_file (id, references_total, created_at, updated_at, type, mime_type, size) FROM stdin;
\.


--
-- Data for Name: user_account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_account (id, email, password, role, name, username, avatar, phone, organization, language, subscribe_to_own_cards, subscribe_to_card_when_commenting, turn_off_recent_card_highlighting, enable_favorites_by_default, default_editor_mode, default_home_view, default_projects_order, is_sso_user, is_deactivated, created_at, updated_at, password_changed_at, terms_signature, terms_accepted_at, api_key_prefix, api_key_hash, api_key_created_at) FROM stdin;
1560328737491256323	execution_agent@gmail.com	$2b$10$vpoSEvqsa0KymG.SnTHsU.CwGePmc/gPAO0Ze4/QE.BAUF8UH1SeK	boardUser	Execution Agent	execution_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-30 10:50:39.567685	2025-07-30 11:00:33.651	\N	\N	\N	\N	\N	\N
1560328737491256324	kanban_agent@gmail.com	$2b$10$vpoSEvqsa0KymG.SnTHsU.CwGePmc/gPAO0Ze4/QE.BAUF8UH1SeK	boardUser	Kanban Agent	kanban_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-30 10:50:39.567685	2025-07-30 11:00:37.275	\N	\N	\N	\N	\N	\N
1560328737491256325	meta_agent@gmail.com	$2b$10$vpoSEvqsa0KymG.SnTHsU.CwGePmc/gPAO0Ze4/QE.BAUF8UH1SeK	boardUser	Meta Agent	meta_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-30 10:50:39.567685	2025-07-30 11:00:41.191	\N	\N	\N	\N	\N	\N
1626139592824457076	project_agent@gmail.com	$2b$10$WPFiaWU6vxE/LrMu4j2oGOBTYX4UGtYDzU1Iv44oQYaA68XptBU9e	boardUser	Project Agent	project_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-10-21 10:29:05.57	\N	\N	\N	\N	\N	\N	\N
1560328737491256322	agent@gmail.com	$2b$10$vpoSEvqsa0KymG.SnTHsU.CwGePmc/gPAO0Ze4/QE.BAUF8UH1SeK	admin	Admin Agent	admin_agent	\N	\N	\N	\N	f	t	f	f	markup	groupedProjects	byDefault	f	f	2025-07-30 10:50:39.567685	2025-11-08 09:42:11.844	\N	b6d551164552f5886e8e9d372ba1198a1b991ed7df4e4fc3c005883483b6a8a2	2025-11-08 09:42:11.841	\N	\N	\N
1560278692305830913	demo@demo.demo	$2b$10$6v9Pex1xIqrQohR.5U8tSumsWJPOhBAEYKrQMHlIBtWy1oCy9aDRW	admin	Demo User	demo	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-22 13:35:14.411	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: webhook; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.webhook (id, board_id, name, url, access_token, events, excluded_events, created_at, updated_at) FROM stdin;
\.


--
-- Name: migration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migration_id_seq', 14, true);


--
-- Name: migration_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migration_lock_index_seq', 1, true);


--
-- Name: next_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.next_id_seq', 2160, true);


--
-- Name: action action_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.action
    ADD CONSTRAINT action_pkey PRIMARY KEY (id);


--
-- Name: attachment attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachment
    ADD CONSTRAINT attachment_pkey PRIMARY KEY (id);


--
-- Name: background_image background_image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.background_image
    ADD CONSTRAINT background_image_pkey PRIMARY KEY (id);


--
-- Name: base_custom_field_group base_custom_field_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.base_custom_field_group
    ADD CONSTRAINT base_custom_field_group_pkey PRIMARY KEY (id);


--
-- Name: board_membership board_membership_board_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_membership
    ADD CONSTRAINT board_membership_board_id_user_id_unique UNIQUE (board_id, user_id);


--
-- Name: board_membership board_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_membership
    ADD CONSTRAINT board_membership_pkey PRIMARY KEY (id);


--
-- Name: board board_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board
    ADD CONSTRAINT board_pkey PRIMARY KEY (id);


--
-- Name: board_subscription board_subscription_board_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_subscription
    ADD CONSTRAINT board_subscription_board_id_user_id_unique UNIQUE (board_id, user_id);


--
-- Name: board_subscription board_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_subscription
    ADD CONSTRAINT board_subscription_pkey PRIMARY KEY (id);


--
-- Name: card_label card_label_card_id_label_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_label
    ADD CONSTRAINT card_label_card_id_label_id_unique UNIQUE (card_id, label_id);


--
-- Name: card_label card_label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_label
    ADD CONSTRAINT card_label_pkey PRIMARY KEY (id);


--
-- Name: card_membership card_membership_card_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_membership
    ADD CONSTRAINT card_membership_card_id_user_id_unique UNIQUE (card_id, user_id);


--
-- Name: card_membership card_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_membership
    ADD CONSTRAINT card_membership_pkey PRIMARY KEY (id);


--
-- Name: card card_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card
    ADD CONSTRAINT card_pkey PRIMARY KEY (id);


--
-- Name: card_subscription card_subscription_card_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_subscription
    ADD CONSTRAINT card_subscription_card_id_user_id_unique UNIQUE (card_id, user_id);


--
-- Name: card_subscription card_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_subscription
    ADD CONSTRAINT card_subscription_pkey PRIMARY KEY (id);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (id);


--
-- Name: custom_field_group custom_field_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field_group
    ADD CONSTRAINT custom_field_group_pkey PRIMARY KEY (id);


--
-- Name: custom_field custom_field_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field
    ADD CONSTRAINT custom_field_pkey PRIMARY KEY (id);


--
-- Name: custom_field_value custom_field_value_card_id_custom_field_group_id_custom_field_i; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field_value
    ADD CONSTRAINT custom_field_value_card_id_custom_field_group_id_custom_field_i UNIQUE (card_id, custom_field_group_id, custom_field_id);


--
-- Name: custom_field_value custom_field_value_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field_value
    ADD CONSTRAINT custom_field_value_pkey PRIMARY KEY (id);


--
-- Name: identity_provider_user identity_provider_user_issuer_sub_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider_user
    ADD CONSTRAINT identity_provider_user_issuer_sub_unique UNIQUE (issuer, sub);


--
-- Name: identity_provider_user identity_provider_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider_user
    ADD CONSTRAINT identity_provider_user_pkey PRIMARY KEY (id);


--
-- Name: label label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: list list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list
    ADD CONSTRAINT list_pkey PRIMARY KEY (id);


--
-- Name: migration_lock migration_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration_lock
    ADD CONSTRAINT migration_lock_pkey PRIMARY KEY (index);


--
-- Name: migration migration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration
    ADD CONSTRAINT migration_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: notification_service notification_service_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_service
    ADD CONSTRAINT notification_service_pkey PRIMARY KEY (id);


--
-- Name: project_favorite project_favorite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_favorite
    ADD CONSTRAINT project_favorite_pkey PRIMARY KEY (id);


--
-- Name: project_favorite project_favorite_project_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_favorite
    ADD CONSTRAINT project_favorite_project_id_user_id_unique UNIQUE (project_id, user_id);


--
-- Name: project_manager project_manager_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_manager
    ADD CONSTRAINT project_manager_pkey PRIMARY KEY (id);


--
-- Name: project_manager project_manager_project_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_manager
    ADD CONSTRAINT project_manager_project_id_user_id_unique UNIQUE (project_id, user_id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: session session_access_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_access_token_unique UNIQUE (access_token);


--
-- Name: session session_pending_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pending_token_unique UNIQUE (pending_token);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: storage_usage storage_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storage_usage
    ADD CONSTRAINT storage_usage_pkey PRIMARY KEY (id);


--
-- Name: task_list task_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_list
    ADD CONSTRAINT task_list_pkey PRIMARY KEY (id);


--
-- Name: task task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: uploaded_file uploaded_file_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.uploaded_file
    ADD CONSTRAINT uploaded_file_pkey PRIMARY KEY (id);


--
-- Name: user_account user_account_api_key_hash_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_api_key_hash_unique UNIQUE (api_key_hash);


--
-- Name: user_account user_account_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_email_unique UNIQUE (email);


--
-- Name: user_account user_account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_pkey PRIMARY KEY (id);


--
-- Name: user_account user_account_username_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_username_unique EXCLUDE USING btree (username WITH =) WHERE ((username IS NOT NULL));


--
-- Name: webhook webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhook
    ADD CONSTRAINT webhook_pkey PRIMARY KEY (id);


--
-- Name: action_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_board_id_index ON public.action USING btree (board_id);


--
-- Name: action_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_card_id_index ON public.action USING btree (card_id);


--
-- Name: action_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_user_id_index ON public.action USING btree (user_id);


--
-- Name: attachment_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachment_card_id_index ON public.attachment USING btree (card_id);


--
-- Name: attachment_creator_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachment_creator_user_id_index ON public.attachment USING btree (creator_user_id);


--
-- Name: background_image_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX background_image_project_id_index ON public.background_image USING btree (project_id);


--
-- Name: base_custom_field_group_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX base_custom_field_group_project_id_index ON public.base_custom_field_group USING btree (project_id);


--
-- Name: board_membership_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_membership_project_id_index ON public.board_membership USING btree (project_id);


--
-- Name: board_membership_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_membership_user_id_index ON public.board_membership USING btree (user_id);


--
-- Name: board_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_position_index ON public.board USING btree ("position");


--
-- Name: board_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_project_id_index ON public.board USING btree (project_id);


--
-- Name: board_subscription_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_subscription_user_id_index ON public.board_subscription USING btree (user_id);


--
-- Name: card_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_board_id_index ON public.card USING btree (board_id);


--
-- Name: card_creator_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_creator_user_id_index ON public.card USING btree (creator_user_id);


--
-- Name: card_description_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_description_index ON public.card USING gin (description public.gin_trgm_ops);


--
-- Name: card_label_label_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_label_label_id_index ON public.card_label USING btree (label_id);


--
-- Name: card_list_changed_at_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_list_changed_at_index ON public.card USING btree (list_changed_at);


--
-- Name: card_list_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_list_id_index ON public.card USING btree (list_id);


--
-- Name: card_membership_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_membership_user_id_index ON public.card_membership USING btree (user_id);


--
-- Name: card_name_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_name_index ON public.card USING gin (name public.gin_trgm_ops);


--
-- Name: card_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_position_index ON public.card USING btree ("position");


--
-- Name: card_subscription_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_subscription_user_id_index ON public.card_subscription USING btree (user_id);


--
-- Name: comment_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX comment_card_id_index ON public.comment USING btree (card_id);


--
-- Name: comment_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX comment_user_id_index ON public.comment USING btree (user_id);


--
-- Name: custom_field_base_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_base_custom_field_group_id_index ON public.custom_field USING btree (base_custom_field_group_id);


--
-- Name: custom_field_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_custom_field_group_id_index ON public.custom_field USING btree (custom_field_group_id);


--
-- Name: custom_field_group_base_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_base_custom_field_group_id_index ON public.custom_field_group USING btree (base_custom_field_group_id);


--
-- Name: custom_field_group_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_board_id_index ON public.custom_field_group USING btree (board_id);


--
-- Name: custom_field_group_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_card_id_index ON public.custom_field_group USING btree (card_id);


--
-- Name: custom_field_group_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_position_index ON public.custom_field_group USING btree ("position");


--
-- Name: custom_field_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_position_index ON public.custom_field USING btree ("position");


--
-- Name: custom_field_value_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_value_custom_field_group_id_index ON public.custom_field_value USING btree (custom_field_group_id);


--
-- Name: custom_field_value_custom_field_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_value_custom_field_id_index ON public.custom_field_value USING btree (custom_field_id);


--
-- Name: identity_provider_user_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX identity_provider_user_user_id_index ON public.identity_provider_user USING btree (user_id);


--
-- Name: label_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX label_board_id_index ON public.label USING btree (board_id);


--
-- Name: label_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX label_position_index ON public.label USING btree ("position");


--
-- Name: list_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_board_id_index ON public.list USING btree (board_id);


--
-- Name: list_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_position_index ON public.list USING btree ("position");


--
-- Name: list_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_type_index ON public.list USING btree (type);


--
-- Name: notification_action_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_action_id_index ON public.notification USING btree (action_id);


--
-- Name: notification_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_card_id_index ON public.notification USING btree (card_id);


--
-- Name: notification_comment_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_comment_id_index ON public.notification USING btree (comment_id);


--
-- Name: notification_creator_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_creator_user_id_index ON public.notification USING btree (creator_user_id);


--
-- Name: notification_is_read_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_is_read_index ON public.notification USING btree (is_read);


--
-- Name: notification_service_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_service_board_id_index ON public.notification_service USING btree (board_id);


--
-- Name: notification_service_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_service_user_id_index ON public.notification_service USING btree (user_id);


--
-- Name: notification_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_user_id_index ON public.notification USING btree (user_id);


--
-- Name: project_favorite_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_favorite_user_id_index ON public.project_favorite USING btree (user_id);


--
-- Name: project_manager_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_manager_user_id_index ON public.project_manager USING btree (user_id);


--
-- Name: project_owner_project_manager_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_owner_project_manager_id_index ON public.project USING btree (owner_project_manager_id);


--
-- Name: session_remote_address_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX session_remote_address_index ON public.session USING btree (remote_address);


--
-- Name: session_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX session_user_id_index ON public.session USING btree (user_id);


--
-- Name: task_assignee_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_assignee_user_id_index ON public.task USING btree (assignee_user_id);


--
-- Name: task_linked_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_linked_card_id_index ON public.task USING btree (linked_card_id);


--
-- Name: task_list_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_list_card_id_index ON public.task_list USING btree (card_id);


--
-- Name: task_list_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_list_position_index ON public.task_list USING btree ("position");


--
-- Name: task_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_position_index ON public.task USING btree ("position");


--
-- Name: task_task_list_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_task_list_id_index ON public.task USING btree (task_list_id);


--
-- Name: uploaded_file_references_total_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX uploaded_file_references_total_index ON public.uploaded_file USING btree (references_total);


--
-- Name: uploaded_file_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX uploaded_file_type_index ON public.uploaded_file USING btree (type);


--
-- Name: user_account_is_deactivated_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_account_is_deactivated_index ON public.user_account USING btree (is_deactivated);


--
-- Name: user_account_role_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_account_role_index ON public.user_account USING btree (role);


--
-- Name: user_account_username_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_account_username_index ON public.user_account USING btree (username);


--
-- Name: webhook_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX webhook_board_id_index ON public.webhook USING btree (board_id);


--
-- PostgreSQL database dump complete
--

\unrestrict Za45xWzbpLVFqVKLeDbPp4O2zxKpD8gZKLFXSyfYKiiKFOLIbuTb3pT4huwemab

--
-- Database "postgres" dump
--

--
-- PostgreSQL database dump
--

\restrict ZXmLZqo2lnlM6f0liM0cRGUk7kEH2n2Li1RCY8xDhk0Au8ZhUGNvYwgNUewFjRh

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\unrestrict ZXmLZqo2lnlM6f0liM0cRGUk7kEH2n2Li1RCY8xDhk0Au8ZhUGNvYwgNUewFjRh
\connect postgres
\restrict ZXmLZqo2lnlM6f0liM0cRGUk7kEH2n2Li1RCY8xDhk0Au8ZhUGNvYwgNUewFjRh

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- PostgreSQL database dump complete
--

\unrestrict ZXmLZqo2lnlM6f0liM0cRGUk7kEH2n2Li1RCY8xDhk0Au8ZhUGNvYwgNUewFjRh

--
-- PostgreSQL database cluster dump complete
--

