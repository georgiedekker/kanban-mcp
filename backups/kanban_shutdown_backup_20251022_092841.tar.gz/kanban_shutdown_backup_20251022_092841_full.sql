--
-- PostgreSQL database cluster dump
--

\restrict bD1NOweIsoPSRytIKHGwdyoLRlbyd0TlJ6tWb32gAmfdF8RCXRw7VvCBPVJOuIP

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--

DROP DATABASE planka;




--
-- Drop roles
--

DROP ROLE postgres;


--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:RXXbR5Ez0xCVEUmXHIR9qA==$3o0TSW6x5rqx3qdlLk32OfFNrZRZVB8/K7bWHnwLmkQ=:xIdiISN265+TTY4Pv++lFB8dX/RomJ7hp+cbJs6PIT8=';

--
-- User Configurations
--








\unrestrict bD1NOweIsoPSRytIKHGwdyoLRlbyd0TlJ6tWb32gAmfdF8RCXRw7VvCBPVJOuIP

--
-- Databases
--

--
-- Database "template1" dump
--

--
-- PostgreSQL database dump
--

\restrict uxlhIb8weTByMYJ1t2dHlzzSXkuvyy3bzW9JgJ7JNbxRSPRhswkNim6TpdoNW2d

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

UPDATE pg_catalog.pg_database SET datistemplate = false WHERE datname = 'template1';
DROP DATABASE template1;
--
-- Name: template1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE template1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE template1 OWNER TO postgres;

\unrestrict uxlhIb8weTByMYJ1t2dHlzzSXkuvyy3bzW9JgJ7JNbxRSPRhswkNim6TpdoNW2d
\connect template1
\restrict uxlhIb8weTByMYJ1t2dHlzzSXkuvyy3bzW9JgJ7JNbxRSPRhswkNim6TpdoNW2d

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE template1 IS 'default template for new databases';


--
-- Name: template1; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE template1 IS_TEMPLATE = true;


\unrestrict uxlhIb8weTByMYJ1t2dHlzzSXkuvyy3bzW9JgJ7JNbxRSPRhswkNim6TpdoNW2d
\connect template1
\restrict uxlhIb8weTByMYJ1t2dHlzzSXkuvyy3bzW9JgJ7JNbxRSPRhswkNim6TpdoNW2d

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: ACL; Schema: -; Owner: postgres
--

REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict uxlhIb8weTByMYJ1t2dHlzzSXkuvyy3bzW9JgJ7JNbxRSPRhswkNim6TpdoNW2d

--
-- Database "planka" dump
--

--
-- PostgreSQL database dump
--

\restrict 3y8qMjQzwEyalewrzdogaTZULhI5c5lWSFE8qd9wYumR6EBcQy3P1JhGeSSLef6

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: planka; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE planka WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE planka OWNER TO postgres;

\unrestrict 3y8qMjQzwEyalewrzdogaTZULhI5c5lWSFE8qd9wYumR6EBcQy3P1JhGeSSLef6
\connect planka
\restrict 3y8qMjQzwEyalewrzdogaTZULhI5c5lWSFE8qd9wYumR6EBcQy3P1JhGeSSLef6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: next_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.next_id(OUT id bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
      DECLARE
        shard INT := 1;
        epoch BIGINT := 1567191600000;
        sequence BIGINT;
        milliseconds BIGINT;
      BEGIN
        SELECT nextval('next_id_seq') % 1024 INTO sequence;
        SELECT FLOOR(EXTRACT(EPOCH FROM clock_timestamp()) * 1000) INTO milliseconds;
        id := (milliseconds - epoch) << 23;
        id := id | (shard << 10);
        id := id | (sequence);
      END;
    $$;


ALTER FUNCTION public.next_id(OUT id bigint) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.action (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint,
    type text NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    board_id bigint
);


ALTER TABLE public.action OWNER TO postgres;

--
-- Name: attachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attachment (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    creator_user_id bigint,
    type text NOT NULL,
    data jsonb NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.attachment OWNER TO postgres;

--
-- Name: background_image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.background_image (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    dirname text NOT NULL,
    extension text NOT NULL,
    size_in_bytes bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.background_image OWNER TO postgres;

--
-- Name: base_custom_field_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.base_custom_field_group (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.base_custom_field_group OWNER TO postgres;

--
-- Name: board; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text NOT NULL,
    default_view text NOT NULL,
    default_card_type text NOT NULL,
    limit_card_types_to_default_one boolean NOT NULL,
    always_display_card_creator boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.board OWNER TO postgres;

--
-- Name: board_membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board_membership (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    board_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role text NOT NULL,
    can_comment boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.board_membership OWNER TO postgres;

--
-- Name: board_subscription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board_subscription (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.board_subscription OWNER TO postgres;

--
-- Name: card; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    list_id bigint NOT NULL,
    creator_user_id bigint,
    prev_list_id bigint,
    cover_attachment_id bigint,
    type text NOT NULL,
    "position" double precision,
    name text NOT NULL,
    description text,
    due_date timestamp without time zone,
    stopwatch jsonb,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    list_changed_at timestamp without time zone,
    comments_total integer NOT NULL
);


ALTER TABLE public.card OWNER TO postgres;

--
-- Name: card_label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_label (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    label_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_label OWNER TO postgres;

--
-- Name: card_membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_membership (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_membership OWNER TO postgres;

--
-- Name: card_subscription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_subscription (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint NOT NULL,
    is_permanent boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_subscription OWNER TO postgres;

--
-- Name: comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comment (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint,
    text text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.comment OWNER TO postgres;

--
-- Name: custom_field; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_field (
    id bigint DEFAULT public.next_id() NOT NULL,
    base_custom_field_group_id bigint,
    custom_field_group_id bigint,
    "position" double precision NOT NULL,
    name text NOT NULL,
    show_on_front_of_card boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.custom_field OWNER TO postgres;

--
-- Name: custom_field_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_field_group (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint,
    card_id bigint,
    base_custom_field_group_id bigint,
    "position" double precision NOT NULL,
    name text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.custom_field_group OWNER TO postgres;

--
-- Name: custom_field_value; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_field_value (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    custom_field_group_id bigint NOT NULL,
    custom_field_id bigint NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.custom_field_value OWNER TO postgres;

--
-- Name: file_reference; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file_reference (
    id bigint DEFAULT public.next_id() NOT NULL,
    total integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.file_reference OWNER TO postgres;

--
-- Name: identity_provider_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.identity_provider_user (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    issuer text NOT NULL,
    sub text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.identity_provider_user OWNER TO postgres;

--
-- Name: label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.label (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text,
    color text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.label OWNER TO postgres;

--
-- Name: list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.list (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    type text NOT NULL,
    "position" double precision,
    name text,
    color text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.list OWNER TO postgres;

--
-- Name: migration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migration (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


ALTER TABLE public.migration OWNER TO postgres;

--
-- Name: migration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_id_seq OWNER TO postgres;

--
-- Name: migration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migration_id_seq OWNED BY public.migration.id;


--
-- Name: migration_lock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migration_lock (
    index integer NOT NULL,
    is_locked integer
);


ALTER TABLE public.migration_lock OWNER TO postgres;

--
-- Name: migration_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migration_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_lock_index_seq OWNER TO postgres;

--
-- Name: migration_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migration_lock_index_seq OWNED BY public.migration_lock.index;


--
-- Name: next_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.next_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.next_id_seq OWNER TO postgres;

--
-- Name: notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    creator_user_id bigint,
    board_id bigint NOT NULL,
    card_id bigint NOT NULL,
    comment_id bigint,
    action_id bigint,
    type text NOT NULL,
    data jsonb NOT NULL,
    is_read boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.notification OWNER TO postgres;

--
-- Name: notification_service; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_service (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint,
    board_id bigint,
    url text NOT NULL,
    format text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.notification_service OWNER TO postgres;

--
-- Name: project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project (
    id bigint DEFAULT public.next_id() NOT NULL,
    owner_project_manager_id bigint,
    background_image_id bigint,
    name text NOT NULL,
    description text,
    background_type text,
    background_gradient text,
    is_hidden boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.project OWNER TO postgres;

--
-- Name: project_favorite; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_favorite (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.project_favorite OWNER TO postgres;

--
-- Name: project_manager; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_manager (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.project_manager OWNER TO postgres;

--
-- Name: session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    access_token text NOT NULL,
    http_only_token text,
    remote_address text NOT NULL,
    user_agent text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.session OWNER TO postgres;

--
-- Name: task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task (
    id bigint DEFAULT public.next_id() NOT NULL,
    task_list_id bigint NOT NULL,
    assignee_user_id bigint,
    "position" double precision NOT NULL,
    name text NOT NULL,
    is_completed boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.task OWNER TO postgres;

--
-- Name: task_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_list (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text NOT NULL,
    show_on_front_of_card boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.task_list OWNER TO postgres;

--
-- Name: user_account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_account (
    id bigint DEFAULT public.next_id() NOT NULL,
    email text NOT NULL,
    password text,
    role text NOT NULL,
    name text NOT NULL,
    username text,
    avatar jsonb,
    phone text,
    organization text,
    language text,
    subscribe_to_own_cards boolean NOT NULL,
    subscribe_to_card_when_commenting boolean NOT NULL,
    turn_off_recent_card_highlighting boolean NOT NULL,
    enable_favorites_by_default boolean NOT NULL,
    default_editor_mode text NOT NULL,
    default_home_view text NOT NULL,
    default_projects_order text NOT NULL,
    is_sso_user boolean NOT NULL,
    is_deactivated boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    password_changed_at timestamp without time zone
);


ALTER TABLE public.user_account OWNER TO postgres;

--
-- Name: migration id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration ALTER COLUMN id SET DEFAULT nextval('public.migration_id_seq'::regclass);


--
-- Name: migration_lock index; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration_lock ALTER COLUMN index SET DEFAULT nextval('public.migration_lock_index_seq'::regclass);


--
-- Data for Name: action; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.action (id, card_id, user_id, type, data, created_at, updated_at, board_id) FROM stdin;
1566011327149769792	1566011327091049535	1560278692305830913	createCard	{"card": {"name": "test"}, "list": {"id": "1566004621732742167", "name": "TODO", "type": "active"}}	2025-07-30 11:24:57.736	\N	1541385320996537361
1566031207873905757	1566011327091049535	1560328737491256322	moveCard	{"card": {"name": "test"}, "toList": {"id": "1566004621741130776", "name": "READY", "type": "active"}, "fromList": {"id": "1566004621732742167", "name": "TODO", "type": "active"}}	2025-07-30 12:04:27.702	\N	1541385320996537361
1566031272583627871	1566011327091049535	1560328737491256322	moveCard	{"card": {"name": "test"}, "toList": {"id": "1566004621732742167", "name": "TODO", "type": "active"}, "fromList": {"id": "1566004621741130776", "name": "READY", "type": "active"}}	2025-07-30 12:04:35.417	\N	1541385320996537361
1566031331001893985	1566011327091049535	1560328737491256322	moveCard	{"card": {"name": "test"}, "toList": {"id": "1566004621741130776", "name": "READY", "type": "active"}, "fromList": {"id": "1566004621732742167", "name": "TODO", "type": "active"}}	2025-07-30 12:04:42.38	\N	1541385320996537361
1566031382063350883	1566011327091049535	1560328737491256322	moveCard	{"card": {"name": "test"}, "toList": {"id": "1566004621732742167", "name": "TODO", "type": "active"}, "fromList": {"id": "1566004621741130776", "name": "READY", "type": "active"}}	2025-07-30 12:04:48.468	\N	1541385320996537361
1566034264774935664	1566034264749769839	1560328737491256322	createCard	{"card": {"name": "test"}, "list": {"id": "1566000088495424528", "name": "TODO", "type": "active"}}	2025-07-30 12:10:32.115	\N	1565999911277691916
1626139517637363562	1626139517612197737	1560328737491256322	createCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "list": {"id": "1626139471978170170", "name": "TODO", "type": "active"}}	2025-10-21 10:28:56.607	\N	1626139471911061302
1626139517838690156	1626139517830301547	1560328737491256322	createCard	{"card": {"name": "Load Quality Requirements"}, "list": {"id": "1626139471978170170", "name": "TODO", "type": "active"}}	2025-10-21 10:28:56.632	\N	1626139471911061302
1626139518023239534	1626139518014850925	1560328737491256322	createCard	{"card": {"name": "Extract Repo-Specific Principles"}, "list": {"id": "1626139471978170170", "name": "TODO", "type": "active"}}	2025-10-21 10:28:56.654	\N	1626139471911061302
1626139518191011696	1626139518182623087	1560328737491256322	createCard	{"card": {"name": "Load Prompt Templates"}, "list": {"id": "1626139471978170170", "name": "TODO", "type": "active"}}	2025-10-21 10:28:56.674	\N	1626139471911061302
1626139518325229426	1626139518316840817	1560328737491256322	createCard	{"card": {"name": "Validate META Asset Completeness"}, "list": {"id": "1626139471978170170", "name": "TODO", "type": "active"}}	2025-10-21 10:28:56.69	\N	1626139471911061302
1626139518417504115	1626139517612197737	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "toList": {"id": "1626139472045279035", "name": "READY", "type": "active"}, "fromList": {"id": "1626139471978170170", "name": "TODO", "type": "active"}}	2025-10-21 10:28:56.701	\N	1626139471911061302
1626139640698242938	1626139517612197737	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "toList": {"id": "1626139472095610684", "name": "DOING", "type": "active"}, "fromList": {"id": "1626139472045279035", "name": "READY", "type": "active"}}	2025-10-21 10:29:11.278	\N	1626139471911061302
1626144083749636040	1626144083716081607	1560328737491256322	createCard	{"card": {"name": "Load Core Procedures for CLASSIFICATION"}, "list": {"id": "1626143869420701589", "name": "TODO", "type": "active"}}	2025-10-21 10:38:00.931	\N	1626143869236152209
1626144083950962634	1626144083934185417	1560328737491256322	createCard	{"card": {"name": "Load Quality Requirements"}, "list": {"id": "1626143869420701589", "name": "TODO", "type": "active"}}	2025-10-21 10:38:00.954	\N	1626143869236152209
1626144084101957580	1626144084093568971	1560328737491256322	createCard	{"card": {"name": "Load Prompt Templates"}, "list": {"id": "1626143869420701589", "name": "TODO", "type": "active"}}	2025-10-21 10:38:00.973	\N	1626143869236152209
1626144084244563918	1626144084236175309	1560328737491256322	createCard	{"card": {"name": "Validate META Asset Completeness"}, "list": {"id": "1626143869420701589", "name": "TODO", "type": "active"}}	2025-10-21 10:38:00.99	\N	1626143869236152209
1626144084362004431	1626144083716081607	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CLASSIFICATION"}, "toList": {"id": "1626143869512976278", "name": "READY", "type": "active"}, "fromList": {"id": "1626143869420701589", "name": "TODO", "type": "active"}}	2025-10-21 10:38:01.003	\N	1626143869236152209
1626144575967987669	1626144083716081607	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CLASSIFICATION"}, "toList": {"id": "1626143869580085143", "name": "DOING", "type": "active"}, "fromList": {"id": "1626143869512976278", "name": "READY", "type": "active"}}	2025-10-21 10:38:59.608	\N	1626143869236152209
1626762360104420387	1626762360079254562	1560328737491256322	createCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "list": {"id": "1626762338889631728", "name": "TODO", "type": "active"}}	2025-10-22 07:06:25.215	\N	1626762338814134252
1626762360305746981	1626762360297358372	1560328737491256322	createCard	{"card": {"name": "Load Quality Requirements"}, "list": {"id": "1626762338889631728", "name": "TODO", "type": "active"}}	2025-10-22 07:06:25.24	\N	1626762338814134252
1626762360456741927	1626762360439964710	1560328737491256322	createCard	{"card": {"name": "Extract Repo-Specific Principles"}, "list": {"id": "1626762338889631728", "name": "TODO", "type": "active"}}	2025-10-22 07:06:25.257	\N	1626762338814134252
1626762360599348265	1626762360582571048	1560328737491256322	createCard	{"card": {"name": "Load Prompt Templates"}, "list": {"id": "1626762338889631728", "name": "TODO", "type": "active"}}	2025-10-22 07:06:25.274	\N	1626762338814134252
1626762360725177387	1626762360716788778	1560328737491256322	createCard	{"card": {"name": "Validate META Asset Completeness"}, "list": {"id": "1626762338889631728", "name": "TODO", "type": "active"}}	2025-10-22 07:06:25.29	\N	1626762338814134252
1626762360834229292	1626762360079254562	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "toList": {"id": "1626762338956740593", "name": "READY", "type": "active"}, "fromList": {"id": "1626762338889631728", "name": "TODO", "type": "active"}}	2025-10-22 07:06:25.303	\N	1626762338814134252
1626762741291156531	1626762360079254562	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "toList": {"id": "1626762339007072242", "name": "DOING", "type": "active"}, "fromList": {"id": "1626762338956740593", "name": "READY", "type": "active"}}	2025-10-22 07:07:10.656	\N	1626762338814134252
\.


--
-- Data for Name: attachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attachment (id, card_id, creator_user_id, type, data, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: background_image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.background_image (id, project_id, dirname, extension, size_in_bytes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: base_custom_field_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.base_custom_field_group (id, project_id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: board; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board (id, project_id, "position", name, default_view, default_card_type, limit_card_types_to_default_one, always_display_card_creator, created_at, updated_at) FROM stdin;
1573201068874008314	1573201067548608248	1	EXECUTION	kanban	project	f	f	2025-08-09 09:29:41.74	\N
1573201069712869127	1573201067548608248	16385	KANBAN	kanban	project	f	f	2025-08-09 09:29:41.841	\N
1573201070316848916	1573201067548608248	8193	META	kanban	project	f	f	2025-08-09 09:29:41.912	\N
1626139470484997931	1626139469679691560	1	EXECUTION	kanban	project	f	f	2025-10-21 10:28:50.986	\N
1626139471911061302	1626139469679691560	8193	META	kanban	project	f	f	2025-10-21 10:28:51.156	\N
1626139472775087937	1626139469679691560	16385	KANBAN	kanban	project	f	f	2025-10-21 10:28:51.26	\N
1626139473588782924	1626139469679691560	81921	PROJECT	kanban	project	f	f	2025-10-21 10:28:51.357	\N
1626143868271462278	1626143867390658435	1	EXECUTION	kanban	project	f	f	2025-10-21 10:37:35.244	\N
1626143869236152209	1626143867390658435	8193	META	kanban	project	f	f	2025-10-21 10:37:35.358	\N
1626143870267951004	1626143867390658435	16385	KANBAN	kanban	project	f	f	2025-10-21 10:37:35.481	\N
1626143871081645991	1626143867390658435	81921	PROJECT	kanban	project	f	f	2025-10-21 10:37:35.578	\N
1626762337480345569	1626762336809256926	1	EXECUTION	kanban	project	f	f	2025-10-22 07:06:22.519	\N
1626762338814134252	1626762336809256926	8193	META	kanban	project	f	f	2025-10-22 07:06:22.678	\N
1626762339703326711	1626762336809256926	16385	KANBAN	kanban	project	f	f	2025-10-22 07:06:22.784	\N
1626762340525409282	1626762336809256926	81921	PROJECT	kanban	project	f	f	2025-10-22 07:06:22.882	\N
\.


--
-- Data for Name: board_membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board_membership (id, project_id, board_id, user_id, role, can_comment, created_at, updated_at) FROM stdin;
1573201068882396923	1573201067548608248	1573201068874008314	1560328737491256322	editor	\N	2025-08-09 09:29:41.742	\N
1573201069377324804	1573201067548608248	1573201068874008314	1560328737491256323	editor	\N	2025-08-09 09:29:41.801	\N
1573201069486376709	1573201067548608248	1573201068874008314	1560328737491256324	viewer	t	2025-08-09 09:29:41.814	\N
1573201069553485574	1573201067548608248	1573201068874008314	1560328737491256325	viewer	t	2025-08-09 09:29:41.822	\N
1573201069721257736	1573201067548608248	1573201069712869127	1560328737491256322	editor	\N	2025-08-09 09:29:41.842	\N
1573201070140688145	1573201067548608248	1573201069712869127	1560328737491256324	editor	\N	2025-08-09 09:29:41.891	\N
1573201070191019794	1573201067548608248	1573201069712869127	1560328737491256323	viewer	t	2025-08-09 09:29:41.897	\N
1573201070241351443	1573201067548608248	1573201069712869127	1560328737491256325	viewer	t	2025-08-09 09:29:41.904	\N
1573201070316848917	1573201067548608248	1573201070316848916	1560328737491256322	editor	\N	2025-08-09 09:29:41.913	\N
1573201070711113502	1573201067548608248	1573201070316848916	1560328737491256325	editor	\N	2025-08-09 09:29:41.96	\N
1573201070761445151	1573201067548608248	1573201070316848916	1560328737491256323	viewer	t	2025-08-09 09:29:41.965	\N
1573201070820165408	1573201067548608248	1573201070316848916	1560328737491256324	viewer	t	2025-08-09 09:29:41.972	\N
1626139470510163756	1626139469679691560	1626139470484997931	1560328737491256322	editor	\N	2025-10-21 10:28:50.989	\N
1626139471911061303	1626139469679691560	1626139471911061302	1560328737491256322	editor	\N	2025-10-21 10:28:51.157	\N
1626139472783476546	1626139469679691560	1626139472775087937	1560328737491256322	editor	\N	2025-10-21 10:28:51.261	\N
1626139473597171533	1626139469679691560	1626139473588782924	1560328737491256322	editor	\N	2025-10-21 10:28:51.358	\N
1626139474863851352	1626139469679691560	1626139470484997931	1560328737491256323	editor	\N	2025-10-21 10:28:51.509	\N
1626139474922571609	1626139469679691560	1626139470484997931	1560328737491256324	viewer	t	2025-10-21 10:28:51.516	\N
1626139474981291866	1626139469679691560	1626139470484997931	1560328737491256325	viewer	t	2025-10-21 10:28:51.522	\N
1626139475073566556	1626139469679691560	1626139471911061302	1560328737491256325	editor	\N	2025-10-21 10:28:51.533	\N
1626139475115509597	1626139469679691560	1626139471911061302	1560328737491256323	viewer	t	2025-10-21 10:28:51.539	\N
1626139475165841246	1626139469679691560	1626139471911061302	1560328737491256324	viewer	t	2025-10-21 10:28:51.545	\N
1626139475266504544	1626139469679691560	1626139472775087937	1560328737491256324	editor	\N	2025-10-21 10:28:51.557	\N
1626139475308447585	1626139469679691560	1626139472775087937	1560328737491256323	viewer	t	2025-10-21 10:28:51.562	\N
1626139475350390626	1626139469679691560	1626139472775087937	1560328737491256325	viewer	t	2025-10-21 10:28:51.567	\N
1626139475459442532	1626139469679691560	1626139473588782924	1560328737491256323	viewer	t	2025-10-21 10:28:51.579	\N
1626139475602048869	1626139469679691560	1626139473588782924	1560328737491256324	viewer	t	2025-10-21 10:28:51.597	\N
1626139475660769126	1626139469679691560	1626139473588782924	1560328737491256325	viewer	t	2025-10-21 10:28:51.603	\N
1626143868279850887	1626143867390658435	1626143868271462278	1560328737491256322	editor	\N	2025-10-21 10:37:35.244	\N
1626143869236152210	1626143867390658435	1626143869236152209	1560328737491256322	editor	\N	2025-10-21 10:37:35.359	\N
1626143870267951005	1626143867390658435	1626143870267951004	1560328737491256322	editor	\N	2025-10-21 10:37:35.482	\N
1626143871081645992	1626143867390658435	1626143871081645991	1560328737491256322	editor	\N	2025-10-21 10:37:35.579	\N
1626143873455622067	1626143867390658435	1626143868271462278	1560328737491256323	editor	\N	2025-10-21 10:37:35.862	\N
1626143873623394228	1626143867390658435	1626143868271462278	1560328737491256324	viewer	t	2025-10-21 10:37:35.881	\N
1626143873749223349	1626143867390658435	1626143868271462278	1560328737491256325	viewer	t	2025-10-21 10:37:35.896	\N
1626143873816332214	1626143867390658435	1626143868271462278	1626139592824457076	viewer	t	2025-10-21 10:37:35.905	\N
1626143873942161336	1626143867390658435	1626143869236152209	1560328737491256325	editor	\N	2025-10-21 10:37:35.92	\N
1626143874017658809	1626143867390658435	1626143869236152209	1560328737491256323	viewer	t	2025-10-21 10:37:35.928	\N
1626143874084767674	1626143867390658435	1626143869236152209	1560328737491256324	viewer	t	2025-10-21 10:37:35.937	\N
1626143874135099323	1626143867390658435	1626143869236152209	1626139592824457076	viewer	t	2025-10-21 10:37:35.943	\N
1626143874235762621	1626143867390658435	1626143870267951004	1560328737491256324	editor	\N	2025-10-21 10:37:35.955	\N
1626143874294482878	1626143867390658435	1626143870267951004	1560328737491256323	viewer	t	2025-10-21 10:37:35.962	\N
1626143874361591743	1626143867390658435	1626143870267951004	1560328737491256325	viewer	t	2025-10-21 10:37:35.97	\N
1626143874470643648	1626143867390658435	1626143870267951004	1626139592824457076	viewer	t	2025-10-21 10:37:35.982	\N
1626143874705524674	1626143867390658435	1626143871081645991	1626139592824457076	editor	\N	2025-10-21 10:37:36.011	\N
1626143874814576579	1626143867390658435	1626143871081645991	1560328737491256323	viewer	t	2025-10-21 10:37:36.023	\N
1626143874890074052	1626143867390658435	1626143871081645991	1560328737491256324	viewer	t	2025-10-21 10:37:36.033	\N
1626143874957182917	1626143867390658435	1626143871081645991	1560328737491256325	viewer	t	2025-10-21 10:37:36.041	\N
1626762337488734178	1626762336809256926	1626762337480345569	1560328737491256322	editor	\N	2025-10-22 07:06:22.519	\N
1626762338822522861	1626762336809256926	1626762338814134252	1560328737491256322	editor	\N	2025-10-22 07:06:22.678	\N
1626762339711715320	1626762336809256926	1626762339703326711	1560328737491256322	editor	\N	2025-10-22 07:06:22.785	\N
1626762340533797891	1626762336809256926	1626762340525409282	1560328737491256322	editor	\N	2025-10-22 07:06:22.883	\N
1626762342379291662	1626762336809256926	1626762337480345569	1560328737491256323	editor	\N	2025-10-22 07:06:23.102	\N
1626762342429623311	1626762336809256926	1626762337480345569	1560328737491256324	viewer	t	2025-10-22 07:06:23.109	\N
1626762342479954960	1626762336809256926	1626762337480345569	1560328737491256325	viewer	t	2025-10-22 07:06:23.115	\N
1626762342530286609	1626762336809256926	1626762337480345569	1626139592824457076	viewer	t	2025-10-22 07:06:23.121	\N
1626762342614172691	1626762336809256926	1626762338814134252	1560328737491256325	editor	\N	2025-10-22 07:06:23.131	\N
1626762342672892948	1626762336809256926	1626762338814134252	1560328737491256323	viewer	t	2025-10-22 07:06:23.137	\N
1626762342723224597	1626762336809256926	1626762338814134252	1560328737491256324	viewer	t	2025-10-22 07:06:23.143	\N
1626762342765167638	1626762336809256926	1626762338814134252	1626139592824457076	viewer	t	2025-10-22 07:06:23.148	\N
1626762342840665112	1626762336809256926	1626762339703326711	1560328737491256324	editor	\N	2025-10-22 07:06:23.158	\N
1626762342890996761	1626762336809256926	1626762339703326711	1560328737491256323	viewer	t	2025-10-22 07:06:23.164	\N
1626762342932939802	1626762336809256926	1626762339703326711	1560328737491256325	viewer	t	2025-10-22 07:06:23.169	\N
1626762342974882843	1626762336809256926	1626762339703326711	1626139592824457076	viewer	t	2025-10-22 07:06:23.174	\N
1626762343050380317	1626762336809256926	1626762340525409282	1626139592824457076	editor	\N	2025-10-22 07:06:23.183	\N
1626762343117489182	1626762336809256926	1626762340525409282	1560328737491256323	viewer	t	2025-10-22 07:06:23.191	\N
1626762343209763871	1626762336809256926	1626762340525409282	1560328737491256324	viewer	t	2025-10-22 07:06:23.201	\N
1626762343251706912	1626762336809256926	1626762340525409282	1560328737491256325	viewer	t	2025-10-22 07:06:23.207	\N
\.


--
-- Data for Name: board_subscription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board_subscription (id, board_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card (id, board_id, list_id, creator_user_id, prev_list_id, cover_attachment_id, type, "position", name, description, due_date, stopwatch, created_at, updated_at, list_changed_at, comments_total) FROM stdin;
1626139517830301547	1626139471911061302	1626139471978170170	1560328737491256322	\N	\N	project	2	Load Quality Requirements	Load requirements for: code_quality\n\nThis card will select and load quality requirements.	\N	\N	2025-10-21 10:28:56.631	\N	2025-10-21 10:28:56.63	0
1626139518014850925	1626139471911061302	1626139471978170170	1560328737491256322	\N	\N	project	3	Extract Repo-Specific Principles	Extract principles from repository analysis.\n\nThis card will analyze the codebase and extract project-specific principles.	\N	\N	2025-10-21 10:28:56.652	\N	2025-10-21 10:28:56.652	0
1626139518182623087	1626139471911061302	1626139471978170170	1560328737491256322	\N	\N	project	4	Load Prompt Templates	Prepare prompt templates for project type: CODE_ANALYSIS\n\nThis card will load and prepare prompt templates.	\N	\N	2025-10-21 10:28:56.673	\N	2025-10-21 10:28:56.672	0
1626139518316840817	1626139471911061302	1626139471978170170	1560328737491256322	\N	\N	project	5	Validate META Asset Completeness	Validate that all META assets are loaded and ready.\n\nDepends on: 4 previous cards	\N	\N	2025-10-21 10:28:56.689	\N	2025-10-21 10:28:56.689	0
1626762360079254562	1626762338814134252	1626762339007072242	1560328737491256322	\N	\N	project	1	Load Core Procedures for CODE_ANALYSIS	Load procedures for: code_analysis\n\nThis card will select and load the necessary procedures from procedure_management.	\N	\N	2025-10-22 07:06:25.213	2025-10-22 07:07:35.622	2025-10-22 07:07:10.654	3
1626139517612197737	1626139471911061302	1626139472095610684	1560328737491256322	\N	\N	project	1	Load Core Procedures for CODE_ANALYSIS	Load procedures for: code_analysis\n\nThis card will select and load the necessary procedures from procedure_management.	\N	\N	2025-10-21 10:28:56.605	2025-10-21 10:29:18.876	2025-10-21 10:29:11.276	3
1626144083934185417	1626143869236152209	1626143869420701589	1560328737491256322	\N	\N	project	2	Load Quality Requirements	Load requirements for: quality_standards, security_requirements, usability_criteria\n\nThis card will select and load quality requirements.	\N	\N	2025-10-21 10:38:00.953	\N	2025-10-21 10:38:00.953	0
1626144084093568971	1626143869236152209	1626143869420701589	1560328737491256322	\N	\N	project	3	Load Prompt Templates	Prepare prompt templates for project type: CLASSIFICATION\n\nThis card will load and prepare prompt templates.	\N	\N	2025-10-21 10:38:00.971	\N	2025-10-21 10:38:00.971	0
1626144084236175309	1626143869236152209	1626143869420701589	1560328737491256322	\N	\N	project	4	Validate META Asset Completeness	Validate that all META assets are loaded and ready.\n\nDepends on: 3 previous cards	\N	\N	2025-10-21 10:38:00.989	\N	2025-10-21 10:38:00.988	0
1626144083716081607	1626143869236152209	1626143869580085143	1560328737491256322	\N	\N	project	1	Load Core Procedures for CLASSIFICATION	Load procedures for: code_review, testing, deployment\n\nThis card will select and load the necessary procedures from procedure_management.	\N	\N	2025-10-21 10:38:00.926	2025-10-21 10:42:29.804	2025-10-21 10:38:59.606	3
1626762360297358372	1626762338814134252	1626762338889631728	1560328737491256322	\N	\N	project	2	Load Quality Requirements	Load requirements for: code_quality\n\nThis card will select and load quality requirements.	\N	\N	2025-10-22 07:06:25.238	\N	2025-10-22 07:06:25.238	0
1626762360439964710	1626762338814134252	1626762338889631728	1560328737491256322	\N	\N	project	3	Extract Repo-Specific Principles	Extract principles from repository analysis.\n\nThis card will analyze the codebase and extract project-specific principles.	\N	\N	2025-10-22 07:06:25.256	\N	2025-10-22 07:06:25.256	0
1626762360582571048	1626762338814134252	1626762338889631728	1560328737491256322	\N	\N	project	4	Load Prompt Templates	Prepare prompt templates for project type: CODE_ANALYSIS\n\nThis card will load and prepare prompt templates.	\N	\N	2025-10-22 07:06:25.273	\N	2025-10-22 07:06:25.273	0
1626762360716788778	1626762338814134252	1626762338889631728	1560328737491256322	\N	\N	project	5	Validate META Asset Completeness	Validate that all META assets are loaded and ready.\n\nDepends on: 4 previous cards	\N	\N	2025-10-22 07:06:25.289	\N	2025-10-22 07:06:25.289	0
\.


--
-- Data for Name: card_label; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_label (id, card_id, label_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card_membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_membership (id, card_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card_subscription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_subscription (id, card_id, user_id, is_permanent, created_at, updated_at) FROM stdin;
1626139639649666935	1626139517612197737	1560328737491256322	t	2025-10-21 10:29:11.153	\N
1626144574911023058	1626144083716081607	1560328737491256322	t	2025-10-21 10:38:59.481	\N
1626762740284523568	1626762360079254562	1560328737491256322	t	2025-10-22 07:07:10.537	\N
\.


--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comment (id, card_id, user_id, text, created_at, updated_at) FROM stdin;
1626139639616112502	1626139517612197737	1560328737491256322	🚀 **Card Ready for Execution**\n\n**Status**: Initiated\n**Timestamp**: 2025-10-21T10:29:11.087090+00:00\n**Next**: Moving to DOING state for execution\n\nAll prerequisites satisfied, beginning execution process.	2025-10-21 10:29:11.149	\N
1626139641268668284	1626139517612197737	1560328737491256322	✅ **Batch batch_1761042551_approval** completed\n\n**Status**: Success\n**Duration**: 0.250657s\n**Timestamp**: 2025-10-21 10:29:11 UTC\n\n**Results**:\n- meta-ready: 0.25s\n	2025-10-21 10:29:11.346	\N
1626139704434886528	1626139517612197737	1560328737491256322	✅ **Batch batch_1761042555_approval** completed\n\n**Status**: Success\n**Duration**: 3.358137s\n**Timestamp**: 2025-10-21 10:29:18 UTC\n\n**Results**:\n- meta-doing: 3.36s\n	2025-10-21 10:29:18.876	\N
1626144574860691409	1626144083716081607	1560328737491256322	🚀 **Card Ready for Execution**\n\n**Status**: Initiated\n**Timestamp**: 2025-10-21T10:38:59.388658+00:00\n**Next**: Moving to DOING state for execution\n\nAll prerequisites satisfied, beginning execution process.	2025-10-21 10:38:59.476	\N
1626144576555190231	1626144083716081607	1560328737491256322	✅ **Batch batch_1761043139_approval** completed\n\n**Status**: Success\n**Duration**: 0.323186s\n**Timestamp**: 2025-10-21 10:38:59 UTC\n\n**Results**:\n- meta-ready: 0.32s\n	2025-10-21 10:38:59.678	\N
1626146339211446234	1626144083716081607	1560328737491256322	✅ **Batch batch_1761043149_approval** completed\n\n**Status**: Success\n**Duration**: 200.296554s\n**Timestamp**: 2025-10-21 10:42:29 UTC\n\n**Results**:\n- meta-doing: 200.30s\n	2025-10-21 10:42:29.803	\N
1626762740242580527	1626762360079254562	1560328737491256322	🚀 **Card Ready for Execution**\n\n**Status**: Initiated\n**Timestamp**: 2025-10-22T07:07:10.472275+00:00\n**Next**: Moving to DOING state for execution\n\nAll prerequisites satisfied, beginning execution process.	2025-10-22 07:07:10.532	\N
1626762741853193269	1626762360079254562	1560328737491256322	✅ **Batch batch_1761116830_approval** completed\n\n**Status**: Success\n**Duration**: 0.24141s\n**Timestamp**: 2025-10-22 07:07:10 UTC\n\n**Results**:\n- meta-ready: 0.24s\n	2025-10-22 07:07:10.724	\N
1626762950712755256	1626762360079254562	1560328737491256322	✅ **Batch batch_1761116835_approval** completed\n\n**Status**: Success\n**Duration**: 20.128342s\n**Timestamp**: 2025-10-22 07:07:35 UTC\n\n**Results**:\n- meta-doing: 20.13s\n	2025-10-22 07:07:35.622	\N
\.


--
-- Data for Name: custom_field; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_field (id, base_custom_field_group_id, custom_field_group_id, "position", name, show_on_front_of_card, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: custom_field_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_field_group (id, board_id, card_id, base_custom_field_group_id, "position", name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: custom_field_value; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_field_value (id, card_id, custom_field_group_id, custom_field_id, content, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: file_reference; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.file_reference (id, total, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: identity_provider_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.identity_provider_user (id, user_id, issuer, sub, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.label (id, board_id, "position", name, color, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.list (id, board_id, type, "position", name, color, created_at, updated_at) FROM stdin;
1573201068890785532	1573201068874008314	archive	\N	\N	\N	2025-08-09 09:29:41.743	\N
1573201068890785533	1573201068874008314	trash	\N	\N	\N	2025-08-09 09:29:41.743	\N
1573201068957894398	1573201068874008314	active	65536	TODO	\N	2025-08-09 09:29:41.751	\N
1573201069058557695	1573201068874008314	active	131072	READY	\N	2025-08-09 09:29:41.762	\N
1573201069100500736	1573201068874008314	active	196608	DOING	\N	2025-08-09 09:29:41.768	\N
1573201069150832385	1573201068874008314	active	262144	QA	\N	2025-08-09 09:29:41.774	\N
1573201069226329858	1573201068874008314	active	327680	BLOCKED	\N	2025-08-09 09:29:41.783	\N
1573201069268272899	1573201068874008314	active	393216	DONE	\N	2025-08-09 09:29:41.788	\N
1573201069729646345	1573201069712869127	archive	\N	\N	\N	2025-08-09 09:29:41.843	\N
1573201069729646346	1573201069712869127	trash	\N	\N	\N	2025-08-09 09:29:41.843	\N
1573201069788366603	1573201069712869127	active	65536	TODO	\N	2025-08-09 09:29:41.85	\N
1573201069872252684	1573201069712869127	active	131072	READY	\N	2025-08-09 09:29:41.859	\N
1573201069922584333	1573201069712869127	active	196608	DOING	\N	2025-08-09 09:29:41.866	\N
1573201069972915982	1573201069712869127	active	262144	QA	\N	2025-08-09 09:29:41.872	\N
1573201070014859023	1573201069712869127	active	327680	BLOCKED	\N	2025-08-09 09:29:41.877	\N
1573201070056802064	1573201069712869127	active	393216	DONE	\N	2025-08-09 09:29:41.882	\N
1573201070325237526	1573201070316848916	archive	\N	\N	\N	2025-08-09 09:29:41.914	\N
1573201070325237527	1573201070316848916	trash	\N	\N	\N	2025-08-09 09:29:41.914	\N
1573201070425900824	1573201070316848916	active	65536	TODO	\N	2025-08-09 09:29:41.925	\N
1573201070476232473	1573201070316848916	active	131072	READY	\N	2025-08-09 09:29:41.932	\N
1573201070518175514	1573201070316848916	active	196608	DOING	\N	2025-08-09 09:29:41.937	\N
1573201070560118555	1573201070316848916	active	262144	QA	\N	2025-08-09 09:29:41.942	\N
1573201070602061596	1573201070316848916	active	327680	BLOCKED	\N	2025-08-09 09:29:41.947	\N
1573201070644004637	1573201070316848916	active	393216	DONE	\N	2025-08-09 09:29:41.952	\N
1626139470543718189	1626139470484997931	archive	\N	\N	\N	2025-10-21 10:28:50.992	\N
1626139470543718190	1626139470484997931	trash	\N	\N	\N	2025-10-21 10:28:50.992	\N
1626139470669547311	1626139470484997931	active	65536	TODO	\N	2025-10-21 10:28:51.009	\N
1626139470912816944	1626139470484997931	active	131072	READY	\N	2025-10-21 10:28:51.037	\N
1626139471021868849	1626139470484997931	active	196608	DOING	\N	2025-10-21 10:28:51.05	\N
1626139471248361266	1626139470484997931	active	262144	QA	\N	2025-10-21 10:28:51.077	\N
1626139471323858739	1626139470484997931	active	327680	BLOCKED	\N	2025-10-21 10:28:51.087	\N
1626139471390967604	1626139470484997931	active	393216	DONE	\N	2025-10-21 10:28:51.095	\N
1626139471919449912	1626139471911061302	archive	\N	\N	\N	2025-10-21 10:28:51.158	\N
1626139471919449913	1626139471911061302	trash	\N	\N	\N	2025-10-21 10:28:51.158	\N
1626139471978170170	1626139471911061302	active	65536	TODO	\N	2025-10-21 10:28:51.165	\N
1626139472045279035	1626139471911061302	active	131072	READY	\N	2025-10-21 10:28:51.172	\N
1626139472095610684	1626139471911061302	active	196608	DOING	\N	2025-10-21 10:28:51.179	\N
1626139472171108157	1626139471911061302	active	262144	QA	\N	2025-10-21 10:28:51.188	\N
1626139472229828414	1626139471911061302	active	327680	BLOCKED	\N	2025-10-21 10:28:51.195	\N
1626139472288548671	1626139471911061302	active	393216	DONE	\N	2025-10-21 10:28:51.202	\N
1626139472791865155	1626139472775087937	archive	\N	\N	\N	2025-10-21 10:28:51.261	\N
1626139472791865156	1626139472775087937	trash	\N	\N	\N	2025-10-21 10:28:51.261	\N
1626139472842196805	1626139472775087937	active	65536	TODO	\N	2025-10-21 10:28:51.268	\N
1626139472892528454	1626139472775087937	active	131072	READY	\N	2025-10-21 10:28:51.274	\N
1626139472942860103	1626139472775087937	active	196608	DOING	\N	2025-10-21 10:28:51.28	\N
1626139473001580360	1626139472775087937	active	262144	QA	\N	2025-10-21 10:28:51.286	\N
1626139473051912009	1626139472775087937	active	327680	BLOCKED	\N	2025-10-21 10:28:51.293	\N
1626139473110632266	1626139472775087937	active	393216	DONE	\N	2025-10-21 10:28:51.3	\N
1626139473605560142	1626139473588782924	archive	\N	\N	\N	2025-10-21 10:28:51.358	\N
1626139473605560143	1626139473588782924	trash	\N	\N	\N	2025-10-21 10:28:51.358	\N
1626139473655891792	1626139473588782924	active	65536	TODO	\N	2025-10-21 10:28:51.365	\N
1626139473714612049	1626139473588782924	active	131072	READY	\N	2025-10-21 10:28:51.372	\N
1626139473773332306	1626139473588782924	active	196608	DOING	\N	2025-10-21 10:28:51.378	\N
1626139473832052563	1626139473588782924	active	262144	QA	\N	2025-10-21 10:28:51.385	\N
1626139473882384212	1626139473588782924	active	327680	BLOCKED	\N	2025-10-21 10:28:51.391	\N
1626139473941104469	1626139473588782924	active	393216	DONE	\N	2025-10-21 10:28:51.399	\N
1626143868288239496	1626143868271462278	archive	\N	\N	\N	2025-10-21 10:37:35.245	\N
1626143868288239497	1626143868271462278	trash	\N	\N	\N	2025-10-21 10:37:35.245	\N
1626143868355348362	1626143868271462278	active	65536	TODO	\N	2025-10-21 10:37:35.254	\N
1626143868430845835	1626143868271462278	active	131072	READY	\N	2025-10-21 10:37:35.263	\N
1626143868489566092	1626143868271462278	active	196608	DOING	\N	2025-10-21 10:37:35.269	\N
1626143868556674957	1626143868271462278	active	262144	QA	\N	2025-10-21 10:37:35.278	\N
1626143868615395214	1626143868271462278	active	327680	BLOCKED	\N	2025-10-21 10:37:35.285	\N
1626143868690892687	1626143868271462278	active	393216	DONE	\N	2025-10-21 10:37:35.294	\N
1626143869244540819	1626143869236152209	archive	\N	\N	\N	2025-10-21 10:37:35.36	\N
1626143869244540820	1626143869236152209	trash	\N	\N	\N	2025-10-21 10:37:35.36	\N
1626143869420701589	1626143869236152209	active	65536	TODO	\N	2025-10-21 10:37:35.381	\N
1626143869512976278	1626143869236152209	active	131072	READY	\N	2025-10-21 10:37:35.392	\N
1626143869580085143	1626143869236152209	active	196608	DOING	\N	2025-10-21 10:37:35.4	\N
1626143869638805400	1626143869236152209	active	262144	QA	\N	2025-10-21 10:37:35.407	\N
1626143869697525657	1626143869236152209	active	327680	BLOCKED	\N	2025-10-21 10:37:35.414	\N
1626143869756245914	1626143869236152209	active	393216	DONE	\N	2025-10-21 10:37:35.421	\N
1626143870276339614	1626143870267951004	archive	\N	\N	\N	2025-10-21 10:37:35.483	\N
1626143870276339615	1626143870267951004	trash	\N	\N	\N	2025-10-21 10:37:35.483	\N
1626143870326671264	1626143870267951004	active	65536	TODO	\N	2025-10-21 10:37:35.489	\N
1626143870393780129	1626143870267951004	active	131072	READY	\N	2025-10-21 10:37:35.497	\N
1626143870444111778	1626143870267951004	active	196608	DOING	\N	2025-10-21 10:37:35.502	\N
1626143870494443427	1626143870267951004	active	262144	QA	\N	2025-10-21 10:37:35.508	\N
1626143870536386468	1626143870267951004	active	327680	BLOCKED	\N	2025-10-21 10:37:35.514	\N
1626143870586718117	1626143870267951004	active	393216	DONE	\N	2025-10-21 10:37:35.52	\N
1626143871090034601	1626143871081645991	archive	\N	\N	\N	2025-10-21 10:37:35.58	\N
1626143871090034602	1626143871081645991	trash	\N	\N	\N	2025-10-21 10:37:35.58	\N
1626143871157143467	1626143871081645991	active	65536	TODO	\N	2025-10-21 10:37:35.588	\N
1626143871215863724	1626143871081645991	active	131072	READY	\N	2025-10-21 10:37:35.594	\N
1626143871299749805	1626143871081645991	active	196608	DOING	\N	2025-10-21 10:37:35.603	\N
1626143871408801710	1626143871081645991	active	262144	QA	\N	2025-10-21 10:37:35.618	\N
1626143871459133359	1626143871081645991	active	327680	BLOCKED	\N	2025-10-21 10:37:35.624	\N
1626143871501076400	1626143871081645991	active	393216	DONE	\N	2025-10-21 10:37:35.629	\N
1626762337522288611	1626762337480345569	archive	\N	\N	\N	2025-10-22 07:06:22.523	\N
1626762337530677220	1626762337480345569	trash	\N	\N	\N	2025-10-22 07:06:22.523	\N
1626762337614563301	1626762337480345569	active	65536	TODO	\N	2025-10-22 07:06:22.534	\N
1626762337882998758	1626762337480345569	active	131072	READY	\N	2025-10-22 07:06:22.566	\N
1626762337950107623	1626762337480345569	active	196608	DOING	\N	2025-10-22 07:06:22.575	\N
1626762338008827880	1626762337480345569	active	262144	QA	\N	2025-10-22 07:06:22.582	\N
1626762338176600041	1626762337480345569	active	327680	BLOCKED	\N	2025-10-22 07:06:22.602	\N
1626762338294040554	1626762337480345569	active	393216	DONE	\N	2025-10-22 07:06:22.616	\N
1626762338830911470	1626762338814134252	archive	\N	\N	\N	2025-10-22 07:06:22.679	\N
1626762338830911471	1626762338814134252	trash	\N	\N	\N	2025-10-22 07:06:22.679	\N
1626762338889631728	1626762338814134252	active	65536	TODO	\N	2025-10-22 07:06:22.687	\N
1626762338956740593	1626762338814134252	active	131072	READY	\N	2025-10-22 07:06:22.695	\N
1626762339007072242	1626762338814134252	active	196608	DOING	\N	2025-10-22 07:06:22.701	\N
1626762339074181107	1626762338814134252	active	262144	QA	\N	2025-10-22 07:06:22.709	\N
1626762339132901364	1626762338814134252	active	327680	BLOCKED	\N	2025-10-22 07:06:22.716	\N
1626762339183233013	1626762338814134252	active	393216	DONE	\N	2025-10-22 07:06:22.722	\N
1626762339720103929	1626762339703326711	archive	\N	\N	\N	2025-10-22 07:06:22.786	\N
1626762339720103930	1626762339703326711	trash	\N	\N	\N	2025-10-22 07:06:22.786	\N
1626762339778824187	1626762339703326711	active	65536	TODO	\N	2025-10-22 07:06:22.793	\N
1626762339837544444	1626762339703326711	active	131072	READY	\N	2025-10-22 07:06:22.799	\N
1626762339879487485	1626762339703326711	active	196608	DOING	\N	2025-10-22 07:06:22.805	\N
1626762339929819134	1626762339703326711	active	262144	QA	\N	2025-10-22 07:06:22.811	\N
1626762339980150783	1626762339703326711	active	327680	BLOCKED	\N	2025-10-22 07:06:22.817	\N
1626762340030481408	1626762339703326711	active	393216	DONE	\N	2025-10-22 07:06:22.823	\N
1626762340533797892	1626762340525409282	archive	\N	\N	\N	2025-10-22 07:06:22.883	\N
1626762340533797893	1626762340525409282	trash	\N	\N	\N	2025-10-22 07:06:22.883	\N
1626762340584129542	1626762340525409282	active	65536	TODO	\N	2025-10-22 07:06:22.889	\N
1626762340634461191	1626762340525409282	active	131072	READY	\N	2025-10-22 07:06:22.895	\N
1626762340693181448	1626762340525409282	active	196608	DOING	\N	2025-10-22 07:06:22.902	\N
1626762340777067529	1626762340525409282	active	262144	QA	\N	2025-10-22 07:06:22.912	\N
1626762341246829578	1626762340525409282	active	327680	BLOCKED	\N	2025-10-22 07:06:22.968	\N
1626762341297161227	1626762340525409282	active	393216	DONE	\N	2025-10-22 07:06:22.973	\N
\.


--
-- Data for Name: migration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migration (id, name, batch, migration_time) FROM stdin;
1	20250228000022_version_2.js	1	2025-07-22 13:35:14.35+00
2	20250522151122_add_board_activity_log.js	1	2025-07-22 13:35:14.352+00
3	20250523131647_add_comments_counter.js	1	2025-07-22 13:35:14.353+00
4	20250603102521_canonicalize_locale_codes.js	1	2025-07-22 13:35:14.354+00
\.


--
-- Data for Name: migration_lock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migration_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification (id, user_id, creator_user_id, board_id, card_id, comment_id, action_id, type, data, is_read, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_service; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_service (id, user_id, board_id, url, format, created_at, updated_at) FROM stdin;
1565999542187328521	1560278692305830913	\N	json://mini2.local:8634/api/v1/flow-events/webhook	markdown	2025-07-30 11:01:32.859	\N
1566022531410822231	\N	1541385320996537361	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:13.388652	2025-07-30 12:08:07.365
1566022531410822232	\N	1541386488111957023	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:13.388652	2025-07-30 12:08:15.742
1566022531410822233	\N	1541386853553275948	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:13.388652	2025-07-30 12:08:23.596
1566033706831840358	\N	1566019210167977028	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 12:09:25.602	\N
1566033750276441191	\N	1566019210167977027	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 12:09:30.782	\N
1566033792991233128	\N	1565999911277691916	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 12:09:35.874	\N
1566022633139471450	\N	1565999911277691916	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:25.515868	2025-07-30 11:47:25.515868
1566022633139471451	\N	1566019210167977027	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:25.515868	2025-07-30 11:47:25.515868
1566022633139471452	\N	1566019210167977028	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:25.515868	2025-07-30 11:47:25.515868
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project (id, owner_project_manager_id, background_image_id, name, description, background_type, background_gradient, is_hidden, created_at, updated_at) FROM stdin;
1573201067548608248	\N	\N	Core Repository - Rearchitecture	\N	\N	\N	f	2025-08-09 09:29:41.572	\N
1626139469679691560	\N	\N	enterprise_mcp_server	\N	\N	\N	f	2025-10-21 10:28:50.891	\N
1626143867390658435	\N	\N	enterprise_mcp_server	\N	\N	\N	f	2025-10-21 10:37:35.139	\N
1626762336809256926	\N	\N	enterprise_mcp_server	\N	\N	\N	f	2025-10-22 07:06:22.438	\N
\.


--
-- Data for Name: project_favorite; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_favorite (id, project_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project_manager; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_manager (id, project_id, user_id, created_at, updated_at) FROM stdin;
1573201067573774073	1573201067548608248	1560328737491256322	2025-08-09 09:29:41.586	\N
1626139469688080169	1626139469679691560	1560328737491256322	2025-10-21 10:28:50.892	\N
1626143867407435652	1626143867390658435	1560328737491256322	2025-10-21 10:37:35.14	\N
1626762336826034143	1626762336809256926	1560328737491256322	2025-10-22 07:06:22.44	\N
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session (id, user_id, access_token, http_only_token, remote_address, user_agent, created_at, updated_at, deleted_at) FROM stdin;
1560294586092356611	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjAzN2Y4YjIyLTU0YzMtNDVhMi04Mzk2LTM2N2FiZWI0M2U2YiJ9.eyJpYXQiOjE3NTMxOTMyMDksImV4cCI6MTc4NDcyOTIwOSwic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.B9YaJbWEbGLo5wG6UuGgeFKDtcixTiCLeCQ0Z462oIs	fcd4dc85-2b9d-4125-81bb-1f21c400d3c6	151.101.128.223	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 14:06:49.095	\N	\N
1560328737491256326	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjllZDg4ODgzLWI0Y2MtNDI0NS1iOTZjLTVkZWZmZTk0ZTg1YSJ9.eyJpYXQiOjE3NTM4NzI2ODMsImV4cCI6MTc4NTQwODY4Mywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.q02RBVLTM2Ald69pfn8xBcUCATBdqAFcFP-ndN-_hF4	\N	127.0.0.1	API Client	2025-07-30 10:51:29.898679	2025-07-30 10:51:29.898679	\N
1565996599279092742	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImIxMDJmZjE3LWU4MjgtNDJhZC05ZDk4LTVlMDFmNjgxNWY4ZiJ9.eyJpYXQiOjE3NTM4NzI5NDIsImV4cCI6MTc4NTQwODk0Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ml3BmWfjj03jomVI2uJdJLlqj8F2fIQkuT5c6CBtNLA	b153c63b-4562-49ca-8cee-2727a4dc051d	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 10:55:42.036	2025-07-30 11:00:11.817	2025-07-30 11:00:11.816
1565998904820892680	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjE3ZDFhYTk1LTM1MmUtNDMwNS04NjZjLTdmMjA0MTY1MjU4ZCJ9.eyJpYXQiOjE3NTM4NzMyMTYsImV4cCI6MTc4NTQwOTIxNiwic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.wxOtFDkb6tEuB-e-G87QBgIFe98EKxESq2uc6vxbvdU	6bfaa4a3-4721-4086-ba63-b0cab1c19a18	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:00:16.878	2025-07-30 11:11:25.3	2025-07-30 11:11:25.298
1566004531731366934	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjBmYmM0ODk2LTI4MWYtNDViOC04NzAyLTNmMGIyMGM4Y2RiZiJ9.eyJpYXQiOjE3NTM4NzM4ODcsImV4cCI6MTc4NTQwOTg4Nywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.8DAHLMniUdCG8eMZkrVi6xM6P0vbTmcx8LYuLbSKAmU	c8d09b71-a2f6-4a6f-927c-fd894eeda38b	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:11:27.659	2025-07-30 11:23:34.744	2025-07-30 11:23:34.743
1566010658535769148	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjkxODMwNWZmLWMzYzMtNDkxMy05YmJkLWZhODkwYWQ0N2UxMiJ9.eyJpYXQiOjE3NTM4NzQ2MTgsImV4cCI6MTc4NTQxMDYxOCwic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.TM6KEQJQBuXsZ7ffjVjcRKrFcArXVaelDHBjgVuxunI	606003c2-c924-4b8f-bae4-f45c63da76ff	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:23:38.032	2025-07-30 11:29:54.912	2025-07-30 11:29:54.91
1566013844503921729	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjcyZmQyYzM1LWVhNjItNDZkYy1iYjA4LTk2MDgzOTUyYmFkMCJ9.eyJpYXQiOjE3NTM4NzQ5OTcsImV4cCI6MTc4NTQxMDk5Nywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Ut1GIjkn2kdZ_OFTubbZTlm7VWgfrycsHTGkORENfXs	49686d2f-d3b0-4688-8979-9ee345e3db01	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:29:57.829	\N	\N
1572105354811016308	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQzYWMyMTcxLTQ0YmEtNDQ0Yi05YzU0LTVhYzU5NDMzY2Y2YSJ9.eyJpYXQiOjE3NTQ2MDExNjIsImV4cCI6MTc4NjEzNzE2Miwic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.wqarkYGmWGchfdqW2CCtNpDL4JXLYAPL4SkDN6ryTnE	019fe815-6f03-496c-ac49-6cab12d4014e	142.250.179.187	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15	2025-08-07 21:12:42.443	\N	\N
1572120589982762101	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg2M2FiMDMwLTUwZjEtNDJmNy1iYTUyLTU3MmEzMzUwMzJkYSJ9.eyJpYXQiOjE3NTQ2MDI5NzgsImV4cCI6MTc4NjEzODk3OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.hIi2r_oad-oBu-zclw2ZvaxaS0W11NLeorH-cKTSJY8	\N	142.250.179.187	Python-urllib/3.13	2025-08-07 21:42:58.618	\N	\N
1572120638863180918	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjY0Y2YxMDM5LTQ3YTAtNDgwNC1iNWE4LWNjZGNmOTgzODdlZSJ9.eyJpYXQiOjE3NTQ2MDI5ODQsImV4cCI6MTc4NjEzODk4NCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Yuq7g116ACd5kml5HP0ayS9FiniAig3gUSC2-gerVE4	\N	142.250.179.187	Python-urllib/3.13	2025-08-07 21:43:04.447	\N	\N
1572120709486871671	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImQ3YzIyOTQxLTkyYTQtNDA4NC1iYTc4LWMxNTVmOTE1ZWYzMSJ9.eyJpYXQiOjE3NTQ2MDI5OTIsImV4cCI6MTc4NjEzODk5Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.e-vOn0G3GnL7PS98X8qmv0QusZxIk1fi_oXHW7fa3WM	\N	142.250.179.187	Python-urllib/3.13	2025-08-07 21:43:12.866	\N	\N
1572120946196612216	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQyM2MzYjlkLTNmZGItNDZhYS04NDc0LTJlNzBlMjJiNTNhYiJ9.eyJpYXQiOjE3NTQ2MDMwMjEsImV4cCI6MTc4NjEzOTAyMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.LmOR5Htz6wICxT-Ek1aRWKUS6YkSIZqrtFmt7WcDV5k	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:43:41.082	\N	\N
1572121045853275257	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg4OTQ3NGI0LTRmODctNDdhMi04YzUzLTZhMWZmMzQ4NzY4NyJ9.eyJpYXQiOjE3NTQ2MDMwMzIsImV4cCI6MTc4NjEzOTAzMiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Os9ISwVNBNLUjGJE29ZKBh30-KZkxoBqxM7Y07lg8dI	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:43:52.963	\N	\N
1572121901784892538	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjI3NGQxNzJkLTA2ZTktNDA4Zi05ZWIxLWFhODAxZTRkMWI5YiJ9.eyJpYXQiOjE3NTQ2MDMxMzQsImV4cCI6MTc4NjEzOTEzNCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.qqoOOaAnQXVUv_Szc4r9WMa0fN-jC18zZl0QdCQyEXc	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:45:34.998	\N	\N
1572122394867270779	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImU4YjM1OWZkLTk4Y2ItNGUyMy05NjU0LTM1MDUyMTBmZTBmNSJ9.eyJpYXQiOjE3NTQ2MDMxOTMsImV4cCI6MTc4NjEzOTE5Mywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.46DwZc1MK9h2tD2wBgE-nOADpdG9w-Zu7IY4_ZdsMIk	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:46:33.778	\N	\N
1572122796731925628	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjE0YTMzM2YzLTI2NTgtNDAyYy05Y2Q4LTFmZjRiNGZlOTM3OSJ9.eyJpYXQiOjE3NTQ2MDMyNDEsImV4cCI6MTc4NjEzOTI0MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.2lAOwYbTlPAZS3K6D6qhpe9h2xX7ffgg1VzOIciD2Bw	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:47:21.683	\N	\N
1572123028853097599	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjFkNWFmMzBmLTM1YzAtNGZiNy1iY2EwLWE5YzczNDg1YzQ3OCJ9.eyJpYXQiOjE3NTQ2MDMyNjksImV4cCI6MTc4NjEzOTI2OSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.37eztz7Z_VmsL8CNsvm_-Qr80vXvglVlVZtc7S90RZI	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:47:49.355	\N	\N
1572130827263804546	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjJjM2VkODc2LTJkNmMtNDAwNi04MWFkLWExMTEyZmM0NjM5OCJ9.eyJpYXQiOjE3NTQ2MDQxOTgsImV4cCI6MTc4NjE0MDE5OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.4rSidu_0MEvWHb36QnCIESkr0urZO4ZYw2J8472hXRU	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:03:18.996	\N	\N
1572131155786859665	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjVmZjA1NzY0LTk0ZTQtNGExNi1hNjBhLWI0OWYzNzFhY2YwNSJ9.eyJpYXQiOjE3NTQ2MDQyMzgsImV4cCI6MTc4NjE0MDIzOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.cIifhdg3RiuPw7BSOdLRKqm4903UZt7OqOOGoVhCU6w	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:03:58.161	\N	\N
1572131313291363488	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjlhZGU5YjQ0LTkyM2MtNDNiYi1hYzczLTE2ZmFiZDkyNGMyMiJ9.eyJpYXQiOjE3NTQ2MDQyNTYsImV4cCI6MTc4NjE0MDI1Niwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.9jrwy4HYjcfDmV3jBvQLhrEROKzo5GWvii12RA8bmQo	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:04:16.937	\N	\N
1572131367280444591	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImVhNmYyZDNlLTk4ZGUtNDg4ZC04ODhkLWFhMDhjMGUyZGI0NiJ9.eyJpYXQiOjE3NTQ2MDQyNjMsImV4cCI6MTc4NjE0MDI2Mywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Lb110Bgwgd-uvPpHOBj8d2JftFhUwaLg-AuUmdnm3bI	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:04:23.374	\N	\N
1572131515842692286	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjllZTRkZjc5LTZlODAtNGFhNC04OGRlLWE3MWZlM2RkYjBiOCJ9.eyJpYXQiOjE3NTQ2MDQyODEsImV4cCI6MTc4NjE0MDI4MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.7t0D8fRszB2hRqnlo2HV_n0A65YB-BpTy-AzwIt7zWY	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:04:41.082	\N	\N
1572132139728635103	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImFjMmM4Yzc1LTU1YTUtNDUzZi05NTg1LTVmYmRlYWM5Y2Q4MCJ9.eyJpYXQiOjE3NTQ2MDQzNTUsImV4cCI6MTc4NjE0MDM1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.33sXLWxXv5OqxPc7w6wYEWyMKVRtvfTShfqWLDmXRDE	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:05:55.455	\N	\N
1572132307601458432	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjZiN2FlMDlkLWJhNzYtNGRmNC1hZTU2LWJhNmVkNGVlMjQyZSJ9.eyJpYXQiOjE3NTQ2MDQzNzUsImV4cCI6MTc4NjE0MDM3NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.BlgzsB6XtVucEjzOPudMcjrry0LSoZqdt80V03rC6Jo	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:06:15.467	\N	\N
1572132506755400961	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImUzMjE4YjkyLTA2MTUtNGEwNi05ODgyLThjMTdjNDlmN2Y4MiJ9.eyJpYXQiOjE3NTQ2MDQzOTksImV4cCI6MTc4NjE0MDM5OSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.5nrfWnMwyYMcZhMA5KopAvEPSxh875YAWCsfCvU7PhM	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:06:39.208	\N	\N
1572133168926950658	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc0YmMzMTE4LTExNDUtNDk4NS1hOTY0LTM5OWNjNmNhMDM5NCJ9.eyJpYXQiOjE3NTQ2MDQ0NzgsImV4cCI6MTc4NjE0MDQ3OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ktDc75UculROzIG6FKvUfetBEW4amYDaLbqCk_eZPkw	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:07:58.145	\N	\N
1572139607955342627	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg4NDNiNTAwLTg4M2QtNDExNS1hOTc1LTU5ZDU3OWU4ZTYwYSJ9.eyJpYXQiOjE3NTQ2MDUyNDUsImV4cCI6MTc4NjE0MTI0NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.eVskS1Lq74Or76EMZjQ2_XPOW-OYImmxuOkCnlaLPVo	4ed8dc5c-8393-44ba-a459-4063f96f4eb3	142.250.179.187	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-07 22:20:45.737	\N	\N
1572140517012014373	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImNhNWFkMTM4LTJiYjgtNGIzZi1iNDRkLTI0ZmFiZGViZGNmMSJ9.eyJpYXQiOjE3NTQ2MDUzNTQsImV4cCI6MTc4NjE0MTM1NCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Xue2Vaqs0sEhuZ4Hn8L8CnOUdaJBYuN7i8iC8_iy8ek	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:22:34.105	\N	\N
1572141597875766607	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjliOTM5ZjhiLWE4NmMtNGM5Ny1iYmVmLWY2NzQ5NGIzYTk2MyJ9.eyJpYXQiOjE3NTQ2MDU0ODIsImV4cCI6MTc4NjE0MTQ4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Dw5urJY2zYUd29uI46VFo-ms_V0kfeA7QE54qiO2xds	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:24:42.955	\N	\N
1573185207350068570	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjI2ZDlkY2U5LWQ4NGYtNGMwZC1iY2E1LThhN2RjMzc1ZGVkOCJ9.eyJpYXQiOjE3NTQ3Mjk4OTAsImV4cCI6MTc4NjI2NTg5MCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.zhOJNh-CKHIMbB30xPt_YWPW6jdCYLbsIEDCm0e9Las	924a3417-bc5d-4a68-a961-f928e9ca1d8c	172.66.128.70	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-09 08:58:10.898	\N	\N
1573191082949215580	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjMwZGU2ZWYzLTExY2MtNDE3Yy05Y2EzLTY3MzQyYWQ4ZWU0YSJ9.eyJpYXQiOjE3NTQ3MzA1OTEsImV4cCI6MTc4NjI2NjU5MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.U1DIW7L6FlObNkU6Zp2-ZPs4fyYKYXqPUJeDK_Yd3Zk	\N	172.26.0.2	Python/3.12 aiohttp/3.12.15	2025-08-09 09:09:51.316	\N	\N
1573193974946989610	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJhNzM1ZDlhLThkZTgtNGRkMy04NWYyLWM5Y2U1N2I0NzYyZiJ9.eyJpYXQiOjE3NTQ3MzA5MzYsImV4cCI6MTc4NjI2NjkzNiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.SOIem_vkR5aL54QKRn5z_eZKHJzXC4uCM9HP6ryKsIA	\N	172.26.0.2	python-requests/2.32.4	2025-08-09 09:15:36.078	\N	\N
1573201460772996897	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImI4Nzg0MzhkLTM0ZDktNDEwNi05NzdkLWVkZWU3MDIwZjBjOSJ9.eyJpYXQiOjE3NTQ3MzE4MjgsImV4cCI6MTc4NjI2NzgyOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.MhMuJaIsQi6hClay_-6VXQfR1jDTxyx6rUQdygkAUkc	\N	172.26.0.2	python-requests/2.32.4	2025-08-09 09:30:28.457	\N	\N
1573203893385430818	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImVkZDcwZGY0LTc0MjItNGE0ZS04Y2U2LTBhMmQ5ZGI0ODkzMCJ9.eyJpYXQiOjE3NTQ3MzIxMTgsImV4cCI6MTc4NjI2ODExOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Q_3kWuwevvjPzTSY7-TCoBt6OxLoKS-VYosldUtI7fE	\N	172.26.0.2	python-requests/2.32.4	2025-08-09 09:35:18.448	\N	\N
1573216175389673253	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImMyZWNjZWE2LWU2MTAtNDFiMi1hNjRiLTY2MGRmZGQ2ZTgzMyJ9.eyJpYXQiOjE3NTQ3MzM1ODIsImV4cCI6MTc4NjI2OTU4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.PtDpuG9BxXuAK8oXmKJQCTXayN0TwgCSU7VhnjNIuGo	228dd350-bd34-480c-9982-9189f989fa29	172.66.128.70	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-09 09:59:42.574	\N	\N
1626139469595805479	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjE2MmRlNWNhLWEzZmQtNGI1MC1hMjY5LTAyYTY3MGY5OWVkYSJ9.eyJpYXQiOjE3NjEwNDI1MzAsImV4cCI6NDkxNDY0MjUzMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.HBIFYso2NmSdW4hM8ddE0o9BbJ87gVHrLxec-1jximQ	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:28:50.878	\N	\N
1626139470241728298	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjcyMzVhYWQyLTFkZjktNDU0ZS04MjU3LTVlMGMwNDUxNDA2OCJ9.eyJpYXQiOjE3NjEwNDI1MzAsImV4cCI6NDkxNDY0MjUzMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.1V6vuNlKVIjtJQTglmLS99WYr6masL4kQ_rRK-hjZsc	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:28:50.957	\N	\N
1626139471852341045	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImYyMDhjZmVmLTIzNmQtNDdiZS04MzI2LWZkYzlhYzkyODIzNyJ9.eyJpYXQiOjE3NjEwNDI1MzEsImV4cCI6NDkxNDY0MjUzMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.TB13IWVmMKL87IYp1EcA-2JkolS0CxBIC958xpx1JpM	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:28:51.15	\N	\N
1626139472733144896	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjdlMmE1NjFjLTUzNmEtNDE0NC1hZTRhLWUyYzk5NGYwNTg1ZSJ9.eyJpYXQiOjE3NjEwNDI1MzEsImV4cCI6NDkxNDY0MjUzMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.3Zn0HgmxoLpiXXO2OobtJwfUGEhFNu_lC5lSMO2i7Sk	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:28:51.255	\N	\N
1626139473546839883	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImE4YzRmYjExLWFiNWUtNGQxYy1hNTBkLTBmNWEwN2VmNThhYSJ9.eyJpYXQiOjE3NjEwNDI1MzEsImV4cCI6NDkxNDY0MjUzMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.vDkuaUusY6WgmGypxmjNZvIwxRG1zlePKMjCZ-fyYY8	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:28:51.352	\N	\N
1626139474545084246	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImVjNmM4NzZiLTZhNTItNDc2NC04MGVkLTFiNTIxMWVlODBkOCJ9.eyJpYXQiOjE3NjEwNDI1MzEsImV4cCI6NDkxNDY0MjUzMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.acXSkKej7Ifi0hzllWFHjJMoRXzS0mQ0uzlD8Qqcco8	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:28:51.47	\N	\N
1626139476818397031	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjEyYTM2Y2ZhLTlmNjEtNDI1NC1hODUwLWNjZTUyMmEyZDQ3MSJ9.eyJpYXQiOjE3NjEwNDI1MzEsImV4cCI6NDkxNDY0MjUzMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.oJnAEkKRu7xSYshkQrJXuqNohQfKgbhecopBba8fAIA	f8fa67dd-c779-491c-931f-3be780d26de1	172.18.0.13	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-21 10:28:51.741	\N	\N
1626139517461202792	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjIwMTUwMjFlLTdmODAtNGFlZS1iNjU3LWE0ZDQ0NDJlOGQ1NSJ9.eyJpYXQiOjE3NjEwNDI1MzYsImV4cCI6NDkxNDY0MjUzNiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.NPw8DM8cKlKtO9uVQfT9Vtp4CIIXDWyy0FjUoRp42xA	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:28:56.587	\N	\N
1626139639549003637	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjNmMjk1OWQ2LTZjODYtNDkwYy1iMzdmLTFhZjgwODEzMjYzZiJ9.eyJpYXQiOjE3NjEwNDI1NTEsImV4cCI6NDkxNDY0MjU1MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.8i2kP6VllzIZN3A6PlFKpErmh4lT4M4zZSQmh0848uA	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:29:11.14	\N	\N
1626139640060708728	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImZkMjQxMTE2LTQzOGMtNDcwMC04YTQ5LTkyYzRmNDAxMGRlYiJ9.eyJpYXQiOjE3NjEwNDI1NTEsImV4cCI6NDkxNDY0MjU1MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.F4DPnzV2wo0kU8CjYFDrRYtKO0G2mA2ykZtsOjZLdxc	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:29:11.202	\N	\N
1626139640597579641	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjdjMjgyZjEzLWNkMjMtNDZhZS1iNGIyLTNhZDI4M2I3NzU1NCJ9.eyJpYXQiOjE3NjEwNDI1NTEsImV4cCI6NDkxNDY0MjU1MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.2zOV2jiU5oHtug4PZXtQ0aOzUc1TqFvcGwuuN3G0NKg	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:29:11.266	\N	\N
1626139641226725243	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjEzMDQ0YTFkLTQ4MjktNGVhNC04YjQyLTJiZjU1MmM2NGE4MCJ9.eyJpYXQiOjE3NjEwNDI1NTEsImV4cCI6NDkxNDY0MjU1MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.-EaEdaNMfZ0CSl3tPvC5MpKwB3G5VgKuCPG0M9bUOtI	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:29:11.34	\N	\N
1626139703705077630	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjUyMGMxYzkwLTNlNjktNDIwZS1iZWYxLWQ2NDY4M2Q1MGEzNCJ9.eyJpYXQiOjE3NjEwNDI1NTgsImV4cCI6NDkxNDY0MjU1OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.BiJs1f-4m2OSTJwzXuqQP-L2M1R3EPtG2h-pQIpVKF8	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:29:18.788	\N	\N
1626139704342611839	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjI3YTAzNmRlLTQwNmEtNGQwMS1iNDlhLTkwNjAxYmRjOTc2OCJ9.eyJpYXQiOjE3NjEwNDI1NTgsImV4cCI6NDkxNDY0MjU1OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.s97pmKX-gmlsvXDsJFxwXkOsSm2BY4sulNuXeypPa9s	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:29:18.865	\N	\N
1626143867289995138	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImRmYzUxZWZlLTA4YWUtNDBkNy1hYmQ4LWZhM2U5Y2Q2ZWJhNiJ9.eyJpYXQiOjE3NjEwNDMwNTUsImV4cCI6NDkxNDY0MzA1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.o7s2TTc7H9jIiGqpbTuTN34sVRefCQLD21Kf1AHFEEA	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:37:35.124	\N	\N
1626143868187576197	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjM3NmU2YzFhLTc1NjUtNDAwOC1hYjFiLWIxOTU1OWM4ZWJhNSJ9.eyJpYXQiOjE3NjEwNDMwNTUsImV4cCI6NDkxNDY0MzA1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9._iJ4k6mBQcwnQGO2lWO_i4bGZfEGBABbW9_1ubW5kmM	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:37:35.234	\N	\N
1626143869177431952	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjEwNmJkMWY0LWU2YzUtNDVjYy04NzkwLTQ2YzBjOTNhMmRjNSJ9.eyJpYXQiOjE3NjEwNDMwNTUsImV4cCI6NDkxNDY0MzA1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Xi6yM_38ln7zEq5gGfIROzCGlGPRfV0SmvqB-YnUhPE	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:37:35.352	\N	\N
1626143870209230747	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjBiZTI1MzI5LWEwN2YtNDNiMy1hNDE2LTQ2ZmFmZTU3Y2UwMSJ9.eyJpYXQiOjE3NjEwNDMwNTUsImV4cCI6NDkxNDY0MzA1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.6zUfecnQ0os6_8jtyQRt7ktbgskjAJlLYWdbNxUlWrc	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:37:35.474	\N	\N
1626143871031314342	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjZiOTQ2OGQ5LWI3MDctNDViMy05YjZiLTVlNDY3ODA3N2Y1YiJ9.eyJpYXQiOjE3NjEwNDMwNTUsImV4cCI6NDkxNDY0MzA1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.0zv4RYbRDABS59_QYImY7L6sKpxOoSwuRNJBENi4-Vk	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:37:35.572	\N	\N
1626143872499320753	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjEwYzIwOTJkLTg2ODctNGUxMy1hNTcxLTNkYmZlMTFiMzdiNiJ9.eyJpYXQiOjE3NjEwNDMwNTUsImV4cCI6NDkxNDY0MzA1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9._gk9f1T0RroW5vk5mjHiA1NGjNwAutVlz8lXzsBW5KE	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:37:35.743	\N	\N
1626144083355371462	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImM3ZjA3MDI5LWM1MWYtNGNkNC05NDkxLTViZGQzYjA1NWZjOSJ9.eyJpYXQiOjE3NjEwNDMwODAsImV4cCI6NDkxNDY0MzA4MCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.4j_Nq0B33FaLAC-tj4aAljLhri2vxMslt9ai59L8tg0	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:38:00.881	\N	\N
1626144574768416720	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjZhMDMzZTA3LWVhY2EtNDY0Ny1iYjYyLWI0ZTViZTUwODBkNSJ9.eyJpYXQiOjE3NjEwNDMxMzksImV4cCI6NDkxNDY0MzEzOSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.J7Zlnd0504HEZzmURL5a0jBxDrNNwFmbeYiLc4rtzU8	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:38:59.462	\N	\N
1626144575347230675	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjkwNTNmMTFiLTI2ZDQtNDY5MS1hMTQ5LWQ4MWZlYzFmYTM1YSJ9.eyJpYXQiOjE3NjEwNDMxMzksImV4cCI6NDkxNDY0MzEzOSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Y2nUBiO5ZhE_eqOOVAgVCzNxBgybyV6sD7T48zXPaQo	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:38:59.533	\N	\N
1626144575875712980	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImE3Yzg5ZDM1LTJiZDktNDAyOC1hMjU0LTFlYTNkZjUxMWE5NCJ9.eyJpYXQiOjE3NjEwNDMxMzksImV4cCI6NDkxNDY0MzEzOSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.rsasVGizICIW5Fo80hX-bDBHZyk1IvvHatK1dNelmyo	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:38:59.597	\N	\N
1626144576496469974	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjExNDA5OGVlLTc2MGItNGJiYS04YWI0LWU1YzkxZTgwMWI1MSJ9.eyJpYXQiOjE3NjEwNDMxMzksImV4cCI6NDkxNDY0MzEzOSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.R5bt08JiktsGcUW0qgMZnG6mxKTs2-jAIH_H5vFHSl4	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:38:59.67	\N	\N
1626146339102394329	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjM3Zjg2MTNkLTMzOTktNDg3NS1iMjliLTk5OTk5NWIwNjVjOCJ9.eyJpYXQiOjE3NjEwNDMzNDksImV4cCI6NDkxNDY0MzM0OSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.5rTfTrhj9gRP9egP-VBpV90jQyvUrTDYPyer-HVM54I	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 10:42:29.787	\N	\N
1626762336658261981	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImVmMmRkZGI1LWU5ODEtNDIyNi1iOTE0LTdlYjZiZDhlYzk4NyJ9.eyJpYXQiOjE3NjExMTY3ODIsImV4cCI6NDkxNDcxNjc4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.FOgr81iWAmb5HipwePmXjvWR3aZFugjsRwTEcmg0K98	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:06:22.414	\N	\N
1626762337388070880	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjU4MWFmOTk3LTMwNzUtNDlkYS1hOGZkLTY5NDUzMjkzZTdiYyJ9.eyJpYXQiOjE3NjExMTY3ODIsImV4cCI6NDkxNDcxNjc4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.IX0rAJ8DdW_WTwgwe7uLHFDJ9vl8Sn_k4OARvcdS8Y4	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:06:22.507	\N	\N
1626762338763802603	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImEyOTYwOGYxLTExNmEtNGUyMS05N2MwLWQ5ODZjYmE2MzA1ZCJ9.eyJpYXQiOjE3NjExMTY3ODIsImV4cCI6NDkxNDcxNjc4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.iGNur6M4qKEWZAcXnQfzu1-BzLMj21QIK-SwqdcD-SY	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:06:22.672	\N	\N
1626762339661383670	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImZiYTc0M2YyLTUxMDEtNDVlZi05ZjdhLTc1OWEzNGIwZGMxNCJ9.eyJpYXQiOjE3NjExMTY3ODIsImV4cCI6NDkxNDcxNjc4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ZdUfW8_xzYRQ_t_reYxdEwZ7OisMvbFgpzhji8N4G7k	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:06:22.778	\N	\N
1626762340475077633	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjIzOWQ3OWM3LTRjNmItNGNmYS1iNDY2LWVmNWYyOTQyNGMzMCJ9.eyJpYXQiOjE3NjExMTY3ODIsImV4cCI6NDkxNDcxNjc4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.IbL8maFkmYnb7m4VlU9W8HZAjN6AP1mH02_C1Koa4DE	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:06:22.876	\N	\N
1626762341993415692	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjUyMDgyODY0LWQyM2YtNDc5ZC04MDI4LTRkNzkzNmVmZTJiMyJ9.eyJpYXQiOjE3NjExMTY3ODMsImV4cCI6NDkxNDcxNjc4Mywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Vg5DxlwHucDqfwY8eN3PVGmOMgsJHIM5niPU8J10rnE	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:06:23.057	\N	\N
1626762359903093793	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjliZTFiMThmLWI3YTgtNGI5OC1iNzc2LWM1ZGMyNjdkNGUyZSJ9.eyJpYXQiOjE3NjExMTY3ODUsImV4cCI6NDkxNDcxNjc4NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.VPAzWP1XxznkLOHpshA65MbhHW6AEt8DUMBu_GDI2c4	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:06:25.192	\N	\N
1626762564148921389	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQ3ZjZiZWFmLTBkMGItNDBiZC04ZjM1LTM1NTM2OGI0MTZlNCJ9.eyJpYXQiOjE3NjExMTY4MDksImV4cCI6NDkxNDcxNjgwOSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.CSlYyMY4ML23Kq6O3KpoRjyslHEM3q7P3tatTvbYPgo	edfe8e4e-fda2-4e4b-976d-17b32b8cd3bd	172.18.0.3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-22 07:06:49.539	\N	\N
1626762740183860270	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjJhNjUzOWRjLTFhMGItNDlkZS1hNDYwLTdkMTE3ODA5ZDI3ZCJ9.eyJpYXQiOjE3NjExMTY4MzAsImV4cCI6NDkxNDcxNjgzMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.4xhLIRWoNyma-HXNReJanl8JPUUO10njLow64WDpol4	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:07:10.524	\N	\N
1626762740695565361	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImZjZWVhMmQ4LTQ5YmItNDU4OS1iN2I1LWFlYThlNjZhYjQ0YyJ9.eyJpYXQiOjE3NjExMTY4MzAsImV4cCI6NDkxNDcxNjgzMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Skmdgd9mPKq-IvN1gXGn2mZSp5GvTT4TTIRkO0zpTHM	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:07:10.586	\N	\N
1626762741207270450	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImRhNTc5NTY0LWRkMDItNDgzYS1hOTY1LTRmYzExZDIxZTc3YyJ9.eyJpYXQiOjE3NjExMTY4MzAsImV4cCI6NDkxNDcxNjgzMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.XTuea1-J66v7mdK7r0q3Z6Gc4C3CPK6lrVuZgYD70t8	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:07:10.647	\N	\N
1626762741811250228	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjdhYjFkOWE1LThiYjQtNDAyZC04MzFkLTdkMTI3YzY4NjBmZiJ9.eyJpYXQiOjE3NjExMTY4MzAsImV4cCI6NDkxNDcxNjgzMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.kWoM07kWHJYnQpYKIEDgHtn3kE8BnopZZTJ3dCG6RoY	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:07:10.719	\N	\N
1626762950654034999	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjdjZGM3NjE3LThjZmQtNDgxMC1iMWEyLWRkYTU2Y2QwYWM5YSJ9.eyJpYXQiOjE3NjExMTY4NTUsImV4cCI6NDkxNDcxNjg1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.oRBxGdp0C2jNE6LKlRBiJjgpsR5ySrN479z5OydU-r0	\N	172.18.0.3	Python/3.12 aiohttp/3.13.0	2025-10-22 07:07:35.613	\N	\N
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task (id, task_list_id, assignee_user_id, "position", name, is_completed, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_list (id, card_id, "position", name, show_on_front_of_card, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_account (id, email, password, role, name, username, avatar, phone, organization, language, subscribe_to_own_cards, subscribe_to_card_when_commenting, turn_off_recent_card_highlighting, enable_favorites_by_default, default_editor_mode, default_home_view, default_projects_order, is_sso_user, is_deactivated, created_at, updated_at, password_changed_at) FROM stdin;
1560328737491256323	execution_agent@gmail.com	$2b$10$vpoSEvqsa0KymG.SnTHsU.CwGePmc/gPAO0Ze4/QE.BAUF8UH1SeK	boardUser	Execution Agent	execution_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-30 10:50:39.567685	2025-07-30 11:00:33.651	\N
1560328737491256324	kanban_agent@gmail.com	$2b$10$vpoSEvqsa0KymG.SnTHsU.CwGePmc/gPAO0Ze4/QE.BAUF8UH1SeK	boardUser	Kanban Agent	kanban_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-30 10:50:39.567685	2025-07-30 11:00:37.275	\N
1560328737491256325	meta_agent@gmail.com	$2b$10$vpoSEvqsa0KymG.SnTHsU.CwGePmc/gPAO0Ze4/QE.BAUF8UH1SeK	boardUser	Meta Agent	meta_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-30 10:50:39.567685	2025-07-30 11:00:41.191	\N
1560328737491256322	agent@gmail.com	$2b$10$vpoSEvqsa0KymG.SnTHsU.CwGePmc/gPAO0Ze4/QE.BAUF8UH1SeK	admin	Admin Agent	admin_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-30 10:50:39.567685	2025-07-30 11:23:54.304	\N
1626139592824457076	project_agent@gmail.com	$2b$10$WPFiaWU6vxE/LrMu4j2oGOBTYX4UGtYDzU1Iv44oQYaA68XptBU9e	boardUser	Project Agent	project_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-10-21 10:29:05.57	\N	\N
1560278692305830913	demo@demo.demo	$2b$10$dFKuckoYJAd/TQO1jCgG.eQGHqPwdflRfwt0AAtZtZJ.k3Up4TxNy	admin	Demo User	demo	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-22 13:35:14.411	\N	\N
\.


--
-- Name: migration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migration_id_seq', 4, true);


--
-- Name: migration_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migration_lock_index_seq', 1, true);


--
-- Name: next_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.next_id_seq', 1081, true);


--
-- Name: action action_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.action
    ADD CONSTRAINT action_pkey PRIMARY KEY (id);


--
-- Name: attachment attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachment
    ADD CONSTRAINT attachment_pkey PRIMARY KEY (id);


--
-- Name: background_image background_image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.background_image
    ADD CONSTRAINT background_image_pkey PRIMARY KEY (id);


--
-- Name: base_custom_field_group base_custom_field_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.base_custom_field_group
    ADD CONSTRAINT base_custom_field_group_pkey PRIMARY KEY (id);


--
-- Name: board_membership board_membership_board_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_membership
    ADD CONSTRAINT board_membership_board_id_user_id_unique UNIQUE (board_id, user_id);


--
-- Name: board_membership board_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_membership
    ADD CONSTRAINT board_membership_pkey PRIMARY KEY (id);


--
-- Name: board board_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board
    ADD CONSTRAINT board_pkey PRIMARY KEY (id);


--
-- Name: board_subscription board_subscription_board_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_subscription
    ADD CONSTRAINT board_subscription_board_id_user_id_unique UNIQUE (board_id, user_id);


--
-- Name: board_subscription board_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_subscription
    ADD CONSTRAINT board_subscription_pkey PRIMARY KEY (id);


--
-- Name: card_label card_label_card_id_label_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_label
    ADD CONSTRAINT card_label_card_id_label_id_unique UNIQUE (card_id, label_id);


--
-- Name: card_label card_label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_label
    ADD CONSTRAINT card_label_pkey PRIMARY KEY (id);


--
-- Name: card_membership card_membership_card_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_membership
    ADD CONSTRAINT card_membership_card_id_user_id_unique UNIQUE (card_id, user_id);


--
-- Name: card_membership card_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_membership
    ADD CONSTRAINT card_membership_pkey PRIMARY KEY (id);


--
-- Name: card card_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card
    ADD CONSTRAINT card_pkey PRIMARY KEY (id);


--
-- Name: card_subscription card_subscription_card_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_subscription
    ADD CONSTRAINT card_subscription_card_id_user_id_unique UNIQUE (card_id, user_id);


--
-- Name: card_subscription card_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_subscription
    ADD CONSTRAINT card_subscription_pkey PRIMARY KEY (id);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: custom_field_group custom_field_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field_group
    ADD CONSTRAINT custom_field_group_pkey PRIMARY KEY (id);


--
-- Name: custom_field custom_field_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field
    ADD CONSTRAINT custom_field_pkey PRIMARY KEY (id);


--
-- Name: custom_field_value custom_field_value_card_id_custom_field_group_id_custom_field_i; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field_value
    ADD CONSTRAINT custom_field_value_card_id_custom_field_group_id_custom_field_i UNIQUE (card_id, custom_field_group_id, custom_field_id);


--
-- Name: custom_field_value custom_field_value_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field_value
    ADD CONSTRAINT custom_field_value_pkey PRIMARY KEY (id);


--
-- Name: file_reference file_reference_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_reference
    ADD CONSTRAINT file_reference_pkey PRIMARY KEY (id);


--
-- Name: identity_provider_user identity_provider_user_issuer_sub_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider_user
    ADD CONSTRAINT identity_provider_user_issuer_sub_unique UNIQUE (issuer, sub);


--
-- Name: identity_provider_user identity_provider_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider_user
    ADD CONSTRAINT identity_provider_user_pkey PRIMARY KEY (id);


--
-- Name: label label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: list list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list
    ADD CONSTRAINT list_pkey PRIMARY KEY (id);


--
-- Name: migration_lock migration_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration_lock
    ADD CONSTRAINT migration_lock_pkey PRIMARY KEY (index);


--
-- Name: migration migration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration
    ADD CONSTRAINT migration_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: notification_service notification_service_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_service
    ADD CONSTRAINT notification_service_pkey PRIMARY KEY (id);


--
-- Name: project_favorite project_favorite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_favorite
    ADD CONSTRAINT project_favorite_pkey PRIMARY KEY (id);


--
-- Name: project_favorite project_favorite_project_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_favorite
    ADD CONSTRAINT project_favorite_project_id_user_id_unique UNIQUE (project_id, user_id);


--
-- Name: project_manager project_manager_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_manager
    ADD CONSTRAINT project_manager_pkey PRIMARY KEY (id);


--
-- Name: project_manager project_manager_project_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_manager
    ADD CONSTRAINT project_manager_project_id_user_id_unique UNIQUE (project_id, user_id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: session session_access_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_access_token_unique UNIQUE (access_token);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: task_list task_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_list
    ADD CONSTRAINT task_list_pkey PRIMARY KEY (id);


--
-- Name: task task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: user_account user_account_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_email_unique UNIQUE (email);


--
-- Name: user_account user_account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_pkey PRIMARY KEY (id);


--
-- Name: user_account user_account_username_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_username_unique EXCLUDE USING btree (username WITH =) WHERE ((username IS NOT NULL));


--
-- Name: action_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_board_id_index ON public.action USING btree (board_id);


--
-- Name: action_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_card_id_index ON public.action USING btree (card_id);


--
-- Name: action_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_user_id_index ON public.action USING btree (user_id);


--
-- Name: attachment_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachment_card_id_index ON public.attachment USING btree (card_id);


--
-- Name: attachment_creator_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachment_creator_user_id_index ON public.attachment USING btree (creator_user_id);


--
-- Name: background_image_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX background_image_project_id_index ON public.background_image USING btree (project_id);


--
-- Name: base_custom_field_group_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX base_custom_field_group_project_id_index ON public.base_custom_field_group USING btree (project_id);


--
-- Name: board_membership_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_membership_project_id_index ON public.board_membership USING btree (project_id);


--
-- Name: board_membership_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_membership_user_id_index ON public.board_membership USING btree (user_id);


--
-- Name: board_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_position_index ON public.board USING btree ("position");


--
-- Name: board_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_project_id_index ON public.board USING btree (project_id);


--
-- Name: board_subscription_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_subscription_user_id_index ON public.board_subscription USING btree (user_id);


--
-- Name: card_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_board_id_index ON public.card USING btree (board_id);


--
-- Name: card_creator_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_creator_user_id_index ON public.card USING btree (creator_user_id);


--
-- Name: card_description_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_description_index ON public.card USING gin (description public.gin_trgm_ops);


--
-- Name: card_label_label_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_label_label_id_index ON public.card_label USING btree (label_id);


--
-- Name: card_list_changed_at_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_list_changed_at_index ON public.card USING btree (list_changed_at);


--
-- Name: card_list_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_list_id_index ON public.card USING btree (list_id);


--
-- Name: card_membership_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_membership_user_id_index ON public.card_membership USING btree (user_id);


--
-- Name: card_name_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_name_index ON public.card USING gin (name public.gin_trgm_ops);


--
-- Name: card_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_position_index ON public.card USING btree ("position");


--
-- Name: card_subscription_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_subscription_user_id_index ON public.card_subscription USING btree (user_id);


--
-- Name: comment_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX comment_card_id_index ON public.comment USING btree (card_id);


--
-- Name: comment_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX comment_user_id_index ON public.comment USING btree (user_id);


--
-- Name: custom_field_base_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_base_custom_field_group_id_index ON public.custom_field USING btree (base_custom_field_group_id);


--
-- Name: custom_field_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_custom_field_group_id_index ON public.custom_field USING btree (custom_field_group_id);


--
-- Name: custom_field_group_base_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_base_custom_field_group_id_index ON public.custom_field_group USING btree (base_custom_field_group_id);


--
-- Name: custom_field_group_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_board_id_index ON public.custom_field_group USING btree (board_id);


--
-- Name: custom_field_group_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_card_id_index ON public.custom_field_group USING btree (card_id);


--
-- Name: custom_field_group_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_position_index ON public.custom_field_group USING btree ("position");


--
-- Name: custom_field_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_position_index ON public.custom_field USING btree ("position");


--
-- Name: custom_field_value_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_value_custom_field_group_id_index ON public.custom_field_value USING btree (custom_field_group_id);


--
-- Name: custom_field_value_custom_field_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_value_custom_field_id_index ON public.custom_field_value USING btree (custom_field_id);


--
-- Name: file_reference_total_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX file_reference_total_index ON public.file_reference USING btree (total);


--
-- Name: identity_provider_user_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX identity_provider_user_user_id_index ON public.identity_provider_user USING btree (user_id);


--
-- Name: label_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX label_board_id_index ON public.label USING btree (board_id);


--
-- Name: label_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX label_position_index ON public.label USING btree ("position");


--
-- Name: list_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_board_id_index ON public.list USING btree (board_id);


--
-- Name: list_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_position_index ON public.list USING btree ("position");


--
-- Name: list_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_type_index ON public.list USING btree (type);


--
-- Name: notification_action_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_action_id_index ON public.notification USING btree (action_id);


--
-- Name: notification_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_card_id_index ON public.notification USING btree (card_id);


--
-- Name: notification_comment_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_comment_id_index ON public.notification USING btree (comment_id);


--
-- Name: notification_creator_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_creator_user_id_index ON public.notification USING btree (creator_user_id);


--
-- Name: notification_is_read_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_is_read_index ON public.notification USING btree (is_read);


--
-- Name: notification_service_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_service_board_id_index ON public.notification_service USING btree (board_id);


--
-- Name: notification_service_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_service_user_id_index ON public.notification_service USING btree (user_id);


--
-- Name: notification_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_user_id_index ON public.notification USING btree (user_id);


--
-- Name: project_favorite_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_favorite_user_id_index ON public.project_favorite USING btree (user_id);


--
-- Name: project_manager_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_manager_user_id_index ON public.project_manager USING btree (user_id);


--
-- Name: project_owner_project_manager_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_owner_project_manager_id_index ON public.project USING btree (owner_project_manager_id);


--
-- Name: session_remote_address_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX session_remote_address_index ON public.session USING btree (remote_address);


--
-- Name: session_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX session_user_id_index ON public.session USING btree (user_id);


--
-- Name: task_assignee_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_assignee_user_id_index ON public.task USING btree (assignee_user_id);


--
-- Name: task_list_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_list_card_id_index ON public.task_list USING btree (card_id);


--
-- Name: task_list_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_list_position_index ON public.task_list USING btree ("position");


--
-- Name: task_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_position_index ON public.task USING btree ("position");


--
-- Name: task_task_list_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_task_list_id_index ON public.task USING btree (task_list_id);


--
-- Name: user_account_is_deactivated_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_account_is_deactivated_index ON public.user_account USING btree (is_deactivated);


--
-- Name: user_account_role_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_account_role_index ON public.user_account USING btree (role);


--
-- Name: user_account_username_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_account_username_index ON public.user_account USING btree (username);


--
-- PostgreSQL database dump complete
--

\unrestrict 3y8qMjQzwEyalewrzdogaTZULhI5c5lWSFE8qd9wYumR6EBcQy3P1JhGeSSLef6

--
-- Database "postgres" dump
--

--
-- PostgreSQL database dump
--

\restrict qwR1GFTFHHjYXNaEkEpidMH2oX9UlMhLcXZnZRgPMTfl1bNgOTmJsBgxaLN0hOJ

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\unrestrict qwR1GFTFHHjYXNaEkEpidMH2oX9UlMhLcXZnZRgPMTfl1bNgOTmJsBgxaLN0hOJ
\connect postgres
\restrict qwR1GFTFHHjYXNaEkEpidMH2oX9UlMhLcXZnZRgPMTfl1bNgOTmJsBgxaLN0hOJ

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- PostgreSQL database dump complete
--

\unrestrict qwR1GFTFHHjYXNaEkEpidMH2oX9UlMhLcXZnZRgPMTfl1bNgOTmJsBgxaLN0hOJ

--
-- PostgreSQL database cluster dump complete
--

