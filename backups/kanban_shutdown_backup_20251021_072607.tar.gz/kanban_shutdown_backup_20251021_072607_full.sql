--
-- PostgreSQL database cluster dump
--

\restrict VQfFmbZhLrNpmk45fUTHEGiKWybItOzVMxmOhhJd84QpO55JGib96dTT7zQHpU1

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--

DROP DATABASE enterprise_mcp_server;
DROP DATABASE planka;




--
-- Drop roles
--

DROP ROLE postgres;


--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:RXXbR5Ez0xCVEUmXHIR9qA==$3o0TSW6x5rqx3qdlLk32OfFNrZRZVB8/K7bWHnwLmkQ=:xIdiISN265+TTY4Pv++lFB8dX/RomJ7hp+cbJs6PIT8=';

--
-- User Configurations
--








\unrestrict VQfFmbZhLrNpmk45fUTHEGiKWybItOzVMxmOhhJd84QpO55JGib96dTT7zQHpU1

--
-- Databases
--

--
-- Database "template1" dump
--

--
-- PostgreSQL database dump
--

\restrict Ac1gKGmcCNFLW7aqaAgdv0wFrQw3VDWJMwrqvJQ4nZa1jmdw7uV9iR3rhrpoecT

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

UPDATE pg_catalog.pg_database SET datistemplate = false WHERE datname = 'template1';
DROP DATABASE template1;
--
-- Name: template1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE template1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE template1 OWNER TO postgres;

\unrestrict Ac1gKGmcCNFLW7aqaAgdv0wFrQw3VDWJMwrqvJQ4nZa1jmdw7uV9iR3rhrpoecT
\connect template1
\restrict Ac1gKGmcCNFLW7aqaAgdv0wFrQw3VDWJMwrqvJQ4nZa1jmdw7uV9iR3rhrpoecT

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE template1 IS 'default template for new databases';


--
-- Name: template1; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE template1 IS_TEMPLATE = true;


\unrestrict Ac1gKGmcCNFLW7aqaAgdv0wFrQw3VDWJMwrqvJQ4nZa1jmdw7uV9iR3rhrpoecT
\connect template1
\restrict Ac1gKGmcCNFLW7aqaAgdv0wFrQw3VDWJMwrqvJQ4nZa1jmdw7uV9iR3rhrpoecT

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: ACL; Schema: -; Owner: postgres
--

REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict Ac1gKGmcCNFLW7aqaAgdv0wFrQw3VDWJMwrqvJQ4nZa1jmdw7uV9iR3rhrpoecT

--
-- Database "enterprise_mcp_server" dump
--

--
-- PostgreSQL database dump
--

\restrict wyfYDJB3uql4uAJRIhl0IYnhyhJax5Oq4UkBchD5MLKXfC5ghKRPoXf3vPess6m

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: enterprise_mcp_server; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE enterprise_mcp_server WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE enterprise_mcp_server OWNER TO postgres;

\unrestrict wyfYDJB3uql4uAJRIhl0IYnhyhJax5Oq4UkBchD5MLKXfC5ghKRPoXf3vPess6m
\connect enterprise_mcp_server
\restrict wyfYDJB3uql4uAJRIhl0IYnhyhJax5Oq4UkBchD5MLKXfC5ghKRPoXf3vPess6m

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    actor_id integer,
    actor_type text NOT NULL,
    action_type text NOT NULL,
    resource_type text NOT NULL,
    resource_id text,
    status text NOT NULL,
    details jsonb,
    request_id text,
    ip_address text
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_id_seq OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: mcp_tool_files; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mcp_tool_files (
    id integer NOT NULL,
    tool_id uuid NOT NULL,
    filename text NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.mcp_tool_files OWNER TO postgres;

--
-- Name: mcp_tool_files_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mcp_tool_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mcp_tool_files_id_seq OWNER TO postgres;

--
-- Name: mcp_tool_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mcp_tool_files_id_seq OWNED BY public.mcp_tool_files.id;


--
-- Name: mcp_tool_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mcp_tool_versions (
    id integer NOT NULL,
    tool_id uuid NOT NULL,
    version_number integer NOT NULL,
    code text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by integer,
    description text
);


ALTER TABLE public.mcp_tool_versions OWNER TO postgres;

--
-- Name: mcp_tool_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mcp_tool_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mcp_tool_versions_id_seq OWNER TO postgres;

--
-- Name: mcp_tool_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mcp_tool_versions_id_seq OWNED BY public.mcp_tool_versions.id;


--
-- Name: mcp_tools; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mcp_tools (
    id integer NOT NULL,
    tool_id uuid NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    code text NOT NULL,
    is_multi_file boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.mcp_tools OWNER TO postgres;

--
-- Name: mcp_tools_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mcp_tools_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mcp_tools_id_seq OWNER TO postgres;

--
-- Name: mcp_tools_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mcp_tools_id_seq OWNED BY public.mcp_tools.id;


--
-- Name: oauth_access_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_access_tokens (
    id integer NOT NULL,
    token text NOT NULL,
    client_id text NOT NULL,
    user_id integer,
    scope text,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.oauth_access_tokens OWNER TO postgres;

--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_access_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_access_tokens_id_seq OWNER TO postgres;

--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_access_tokens_id_seq OWNED BY public.oauth_access_tokens.id;


--
-- Name: oauth_auth_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_auth_codes (
    id integer NOT NULL,
    code text NOT NULL,
    client_id text NOT NULL,
    user_id integer,
    scope text,
    code_challenge text NOT NULL,
    code_challenge_method text NOT NULL,
    redirect_uri text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.oauth_auth_codes OWNER TO postgres;

--
-- Name: oauth_auth_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_auth_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_auth_codes_id_seq OWNER TO postgres;

--
-- Name: oauth_auth_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_auth_codes_id_seq OWNED BY public.oauth_auth_codes.id;


--
-- Name: oauth_clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_clients (
    id integer NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    client_name text NOT NULL,
    redirect_uris jsonb NOT NULL,
    client_uri text,
    logo_uri text,
    scope text,
    contacts jsonb,
    client_id_issued_at bigint NOT NULL,
    client_secret_expires_at bigint NOT NULL
);


ALTER TABLE public.oauth_clients OWNER TO postgres;

--
-- Name: oauth_clients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_clients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_clients_id_seq OWNER TO postgres;

--
-- Name: oauth_clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_clients_id_seq OWNED BY public.oauth_clients.id;


--
-- Name: oauth_refresh_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_refresh_tokens (
    id integer NOT NULL,
    token text NOT NULL,
    client_id text NOT NULL,
    user_id integer,
    scope text,
    access_token_id integer,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.oauth_refresh_tokens OWNER TO postgres;

--
-- Name: oauth_refresh_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_refresh_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_refresh_tokens_id_seq OWNER TO postgres;

--
-- Name: oauth_refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_refresh_tokens_id_seq OWNED BY public.oauth_refresh_tokens.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    name text NOT NULL,
    description text
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_permissions (
    role_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name text NOT NULL,
    description text
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    user_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password_hash text,
    api_key_hash text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone NOT NULL,
    email text
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: mcp_tool_files id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_files ALTER COLUMN id SET DEFAULT nextval('public.mcp_tool_files_id_seq'::regclass);


--
-- Name: mcp_tool_versions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_versions ALTER COLUMN id SET DEFAULT nextval('public.mcp_tool_versions_id_seq'::regclass);


--
-- Name: mcp_tools id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tools ALTER COLUMN id SET DEFAULT nextval('public.mcp_tools_id_seq'::regclass);


--
-- Name: oauth_access_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.oauth_access_tokens_id_seq'::regclass);


--
-- Name: oauth_auth_codes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_auth_codes ALTER COLUMN id SET DEFAULT nextval('public.oauth_auth_codes_id_seq'::regclass);


--
-- Name: oauth_clients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_clients ALTER COLUMN id SET DEFAULT nextval('public.oauth_clients_id_seq'::regclass);


--
-- Name: oauth_refresh_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_refresh_tokens ALTER COLUMN id SET DEFAULT nextval('public.oauth_refresh_tokens_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, "timestamp", actor_id, actor_type, action_type, resource_type, resource_id, status, details, request_id, ip_address) FROM stdin;
\.


--
-- Data for Name: mcp_tool_files; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mcp_tool_files (id, tool_id, filename, content, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mcp_tool_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mcp_tool_versions (id, tool_id, version_number, code, created_at, created_by, description) FROM stdin;
\.


--
-- Data for Name: mcp_tools; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mcp_tools (id, tool_id, name, description, code, is_multi_file, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: oauth_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_access_tokens (id, token, client_id, user_id, scope, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_auth_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_auth_codes (id, code, client_id, user_id, scope, code_challenge, code_challenge_method, redirect_uri, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_clients (id, client_id, client_secret, client_name, redirect_uris, client_uri, logo_uri, scope, contacts, client_id_issued_at, client_secret_expires_at) FROM stdin;
\.


--
-- Data for Name: oauth_refresh_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_refresh_tokens (id, token, client_id, user_id, scope, access_token_id, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (id, name, description) FROM stdin;
1	admin	Grants all permissions
2	tool:create	Create new tools
3	tool:read	Read tool definitions and list tools
4	tool:update	Update existing tools
5	tool:delete	Delete tools
6	tool:execute	Execute tools
7	tool:backup	Access and create tool backups
8	tool:restore	Restore tools from backups
9	user:create	Create new users
10	user:read	Read user information
11	user:update	Update user information
12	user:delete	Delete users
13	role:create	Create new roles
14	role:read	Read role information
15	role:update	Update roles and assign permissions
16	role:delete	Delete roles
17	role:assign	Assign roles to users
18	log:read	Read audit logs
19	gateway:configure	Configure gateway settings (e.g., allowed imports)
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
1	1
1	2
1	3
1	4
1	5
1	6
1	7
1	8
1	9
1	10
1	11
1	12
1	13
1	14
1	15
1	16
1	17
1	18
1	19
2	2
2	3
2	4
2	5
2	7
2	8
3	3
3	6
4	3
4	10
4	14
5	18
6	19
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, description) FROM stdin;
1	admin	Full administrative access with all permissions
2	tool_creator	Can create and manage tools
3	tool_user	Can execute tools
4	readonly	Read-only access to system information
5	auditor	Can view audit logs
6	api_gateway	Internal role for API Gateway communication
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (user_id, role_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password_hash, api_key_hash, is_active, created_at, email) FROM stdin;
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: mcp_tool_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mcp_tool_files_id_seq', 1, false);


--
-- Name: mcp_tool_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mcp_tool_versions_id_seq', 1, false);


--
-- Name: mcp_tools_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mcp_tools_id_seq', 1, false);


--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_access_tokens_id_seq', 1, false);


--
-- Name: oauth_auth_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_auth_codes_id_seq', 1, false);


--
-- Name: oauth_clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_clients_id_seq', 1, false);


--
-- Name: oauth_refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_refresh_tokens_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.permissions_id_seq', 19, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 6, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: mcp_tool_files mcp_tool_files_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_files
    ADD CONSTRAINT mcp_tool_files_pkey PRIMARY KEY (id);


--
-- Name: mcp_tool_files mcp_tool_files_tool_id_filename_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_files
    ADD CONSTRAINT mcp_tool_files_tool_id_filename_key UNIQUE (tool_id, filename);


--
-- Name: mcp_tool_versions mcp_tool_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_versions
    ADD CONSTRAINT mcp_tool_versions_pkey PRIMARY KEY (id);


--
-- Name: mcp_tool_versions mcp_tool_versions_tool_id_version_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_versions
    ADD CONSTRAINT mcp_tool_versions_tool_id_version_number_key UNIQUE (tool_id, version_number);


--
-- Name: mcp_tools mcp_tools_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tools
    ADD CONSTRAINT mcp_tools_name_key UNIQUE (name);


--
-- Name: mcp_tools mcp_tools_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tools
    ADD CONSTRAINT mcp_tools_pkey PRIMARY KEY (id);


--
-- Name: mcp_tools mcp_tools_tool_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tools
    ADD CONSTRAINT mcp_tools_tool_id_key UNIQUE (tool_id);


--
-- Name: oauth_access_tokens oauth_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT oauth_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_tokens oauth_access_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT oauth_access_tokens_token_key UNIQUE (token);


--
-- Name: oauth_auth_codes oauth_auth_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_auth_codes
    ADD CONSTRAINT oauth_auth_codes_code_key UNIQUE (code);


--
-- Name: oauth_auth_codes oauth_auth_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_auth_codes
    ADD CONSTRAINT oauth_auth_codes_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_client_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_clients
    ADD CONSTRAINT oauth_clients_client_id_key UNIQUE (client_id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_refresh_tokens oauth_refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_refresh_tokens
    ADD CONSTRAINT oauth_refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_refresh_tokens oauth_refresh_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_refresh_tokens
    ADD CONSTRAINT oauth_refresh_tokens_token_key UNIQUE (token);


--
-- Name: permissions permissions_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_key UNIQUE (name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: audit_logs_actor_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_logs_actor_id_idx ON public.audit_logs USING btree (actor_id);


--
-- Name: audit_logs_resource_type_resource_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_logs_resource_type_resource_id_idx ON public.audit_logs USING btree (resource_type, resource_id);


--
-- Name: audit_logs_timestamp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_logs_timestamp_idx ON public.audit_logs USING btree ("timestamp");


--
-- Name: oauth_access_tokens_expires_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_access_tokens_expires_at_idx ON public.oauth_access_tokens USING btree (expires_at);


--
-- Name: oauth_access_tokens_token_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_access_tokens_token_idx ON public.oauth_access_tokens USING btree (token);


--
-- Name: oauth_auth_codes_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_auth_codes_code_idx ON public.oauth_auth_codes USING btree (code);


--
-- Name: oauth_auth_codes_expires_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_auth_codes_expires_at_idx ON public.oauth_auth_codes USING btree (expires_at);


--
-- Name: oauth_clients_client_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_clients_client_id_idx ON public.oauth_clients USING btree (client_id);


--
-- Name: oauth_refresh_tokens_expires_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_refresh_tokens_expires_at_idx ON public.oauth_refresh_tokens USING btree (expires_at);


--
-- Name: oauth_refresh_tokens_token_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oauth_refresh_tokens_token_idx ON public.oauth_refresh_tokens USING btree (token);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: audit_logs audit_logs_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: mcp_tool_files mcp_tool_files_tool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_files
    ADD CONSTRAINT mcp_tool_files_tool_id_fkey FOREIGN KEY (tool_id) REFERENCES public.mcp_tools(tool_id) ON DELETE CASCADE;


--
-- Name: mcp_tool_versions mcp_tool_versions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_versions
    ADD CONSTRAINT mcp_tool_versions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: mcp_tool_versions mcp_tool_versions_tool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_tool_versions
    ADD CONSTRAINT mcp_tool_versions_tool_id_fkey FOREIGN KEY (tool_id) REFERENCES public.mcp_tools(tool_id) ON DELETE CASCADE;


--
-- Name: oauth_access_tokens oauth_access_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT oauth_access_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: oauth_auth_codes oauth_auth_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_auth_codes
    ADD CONSTRAINT oauth_auth_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: oauth_refresh_tokens oauth_refresh_tokens_access_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_refresh_tokens
    ADD CONSTRAINT oauth_refresh_tokens_access_token_id_fkey FOREIGN KEY (access_token_id) REFERENCES public.oauth_access_tokens(id) ON DELETE CASCADE;


--
-- Name: oauth_refresh_tokens oauth_refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_refresh_tokens
    ADD CONSTRAINT oauth_refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict wyfYDJB3uql4uAJRIhl0IYnhyhJax5Oq4UkBchD5MLKXfC5ghKRPoXf3vPess6m

--
-- Database "planka" dump
--

--
-- PostgreSQL database dump
--

\restrict IBh6NlAyH8shliulMQJ498oEdgPCCqQC0seIH3xveMcTpgdDrYE7F0IbEbME34d

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: planka; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE planka WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE planka OWNER TO postgres;

\unrestrict IBh6NlAyH8shliulMQJ498oEdgPCCqQC0seIH3xveMcTpgdDrYE7F0IbEbME34d
\connect planka
\restrict IBh6NlAyH8shliulMQJ498oEdgPCCqQC0seIH3xveMcTpgdDrYE7F0IbEbME34d

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: next_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.next_id(OUT id bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
      DECLARE
        shard INT := 1;
        epoch BIGINT := 1567191600000;
        sequence BIGINT;
        milliseconds BIGINT;
      BEGIN
        SELECT nextval('next_id_seq') % 1024 INTO sequence;
        SELECT FLOOR(EXTRACT(EPOCH FROM clock_timestamp()) * 1000) INTO milliseconds;
        id := (milliseconds - epoch) << 23;
        id := id | (shard << 10);
        id := id | (sequence);
      END;
    $$;


ALTER FUNCTION public.next_id(OUT id bigint) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.action (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint,
    type text NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    board_id bigint
);


ALTER TABLE public.action OWNER TO postgres;

--
-- Name: attachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attachment (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    creator_user_id bigint,
    type text NOT NULL,
    data jsonb NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.attachment OWNER TO postgres;

--
-- Name: background_image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.background_image (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    dirname text NOT NULL,
    extension text NOT NULL,
    size_in_bytes bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.background_image OWNER TO postgres;

--
-- Name: base_custom_field_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.base_custom_field_group (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.base_custom_field_group OWNER TO postgres;

--
-- Name: board; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text NOT NULL,
    default_view text NOT NULL,
    default_card_type text NOT NULL,
    limit_card_types_to_default_one boolean NOT NULL,
    always_display_card_creator boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.board OWNER TO postgres;

--
-- Name: board_membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board_membership (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    board_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role text NOT NULL,
    can_comment boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.board_membership OWNER TO postgres;

--
-- Name: board_subscription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board_subscription (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.board_subscription OWNER TO postgres;

--
-- Name: card; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    list_id bigint NOT NULL,
    creator_user_id bigint,
    prev_list_id bigint,
    cover_attachment_id bigint,
    type text NOT NULL,
    "position" double precision,
    name text NOT NULL,
    description text,
    due_date timestamp without time zone,
    stopwatch jsonb,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    list_changed_at timestamp without time zone,
    comments_total integer NOT NULL
);


ALTER TABLE public.card OWNER TO postgres;

--
-- Name: card_label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_label (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    label_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_label OWNER TO postgres;

--
-- Name: card_membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_membership (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_membership OWNER TO postgres;

--
-- Name: card_subscription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_subscription (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint NOT NULL,
    is_permanent boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_subscription OWNER TO postgres;

--
-- Name: comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comment (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint,
    text text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.comment OWNER TO postgres;

--
-- Name: custom_field; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_field (
    id bigint DEFAULT public.next_id() NOT NULL,
    base_custom_field_group_id bigint,
    custom_field_group_id bigint,
    "position" double precision NOT NULL,
    name text NOT NULL,
    show_on_front_of_card boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.custom_field OWNER TO postgres;

--
-- Name: custom_field_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_field_group (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint,
    card_id bigint,
    base_custom_field_group_id bigint,
    "position" double precision NOT NULL,
    name text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.custom_field_group OWNER TO postgres;

--
-- Name: custom_field_value; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_field_value (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    custom_field_group_id bigint NOT NULL,
    custom_field_id bigint NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.custom_field_value OWNER TO postgres;

--
-- Name: file_reference; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file_reference (
    id bigint DEFAULT public.next_id() NOT NULL,
    total integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.file_reference OWNER TO postgres;

--
-- Name: identity_provider_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.identity_provider_user (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    issuer text NOT NULL,
    sub text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.identity_provider_user OWNER TO postgres;

--
-- Name: label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.label (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text,
    color text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.label OWNER TO postgres;

--
-- Name: list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.list (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    type text NOT NULL,
    "position" double precision,
    name text,
    color text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.list OWNER TO postgres;

--
-- Name: migration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migration (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


ALTER TABLE public.migration OWNER TO postgres;

--
-- Name: migration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_id_seq OWNER TO postgres;

--
-- Name: migration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migration_id_seq OWNED BY public.migration.id;


--
-- Name: migration_lock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migration_lock (
    index integer NOT NULL,
    is_locked integer
);


ALTER TABLE public.migration_lock OWNER TO postgres;

--
-- Name: migration_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migration_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_lock_index_seq OWNER TO postgres;

--
-- Name: migration_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migration_lock_index_seq OWNED BY public.migration_lock.index;


--
-- Name: next_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.next_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.next_id_seq OWNER TO postgres;

--
-- Name: notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    creator_user_id bigint,
    board_id bigint NOT NULL,
    card_id bigint NOT NULL,
    comment_id bigint,
    action_id bigint,
    type text NOT NULL,
    data jsonb NOT NULL,
    is_read boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.notification OWNER TO postgres;

--
-- Name: notification_service; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_service (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint,
    board_id bigint,
    url text NOT NULL,
    format text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.notification_service OWNER TO postgres;

--
-- Name: project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project (
    id bigint DEFAULT public.next_id() NOT NULL,
    owner_project_manager_id bigint,
    background_image_id bigint,
    name text NOT NULL,
    description text,
    background_type text,
    background_gradient text,
    is_hidden boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.project OWNER TO postgres;

--
-- Name: project_favorite; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_favorite (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.project_favorite OWNER TO postgres;

--
-- Name: project_manager; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_manager (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.project_manager OWNER TO postgres;

--
-- Name: session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    access_token text NOT NULL,
    http_only_token text,
    remote_address text NOT NULL,
    user_agent text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.session OWNER TO postgres;

--
-- Name: task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task (
    id bigint DEFAULT public.next_id() NOT NULL,
    task_list_id bigint NOT NULL,
    assignee_user_id bigint,
    "position" double precision NOT NULL,
    name text NOT NULL,
    is_completed boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.task OWNER TO postgres;

--
-- Name: task_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_list (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text NOT NULL,
    show_on_front_of_card boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.task_list OWNER TO postgres;

--
-- Name: user_account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_account (
    id bigint DEFAULT public.next_id() NOT NULL,
    email text NOT NULL,
    password text,
    role text NOT NULL,
    name text NOT NULL,
    username text,
    avatar jsonb,
    phone text,
    organization text,
    language text,
    subscribe_to_own_cards boolean NOT NULL,
    subscribe_to_card_when_commenting boolean NOT NULL,
    turn_off_recent_card_highlighting boolean NOT NULL,
    enable_favorites_by_default boolean NOT NULL,
    default_editor_mode text NOT NULL,
    default_home_view text NOT NULL,
    default_projects_order text NOT NULL,
    is_sso_user boolean NOT NULL,
    is_deactivated boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    password_changed_at timestamp without time zone
);


ALTER TABLE public.user_account OWNER TO postgres;

--
-- Name: migration id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration ALTER COLUMN id SET DEFAULT nextval('public.migration_id_seq'::regclass);


--
-- Name: migration_lock index; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration_lock ALTER COLUMN index SET DEFAULT nextval('public.migration_lock_index_seq'::regclass);


--
-- Data for Name: action; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.action (id, card_id, user_id, type, data, created_at, updated_at, board_id) FROM stdin;
1566011327149769792	1566011327091049535	1560278692305830913	createCard	{"card": {"name": "test"}, "list": {"id": "1566004621732742167", "name": "TODO", "type": "active"}}	2025-07-30 11:24:57.736	\N	1541385320996537361
1566031207873905757	1566011327091049535	1560328737491256322	moveCard	{"card": {"name": "test"}, "toList": {"id": "1566004621741130776", "name": "READY", "type": "active"}, "fromList": {"id": "1566004621732742167", "name": "TODO", "type": "active"}}	2025-07-30 12:04:27.702	\N	1541385320996537361
1566031272583627871	1566011327091049535	1560328737491256322	moveCard	{"card": {"name": "test"}, "toList": {"id": "1566004621732742167", "name": "TODO", "type": "active"}, "fromList": {"id": "1566004621741130776", "name": "READY", "type": "active"}}	2025-07-30 12:04:35.417	\N	1541385320996537361
1566031331001893985	1566011327091049535	1560328737491256322	moveCard	{"card": {"name": "test"}, "toList": {"id": "1566004621741130776", "name": "READY", "type": "active"}, "fromList": {"id": "1566004621732742167", "name": "TODO", "type": "active"}}	2025-07-30 12:04:42.38	\N	1541385320996537361
1566031382063350883	1566011327091049535	1560328737491256322	moveCard	{"card": {"name": "test"}, "toList": {"id": "1566004621732742167", "name": "TODO", "type": "active"}, "fromList": {"id": "1566004621741130776", "name": "READY", "type": "active"}}	2025-07-30 12:04:48.468	\N	1541385320996537361
1566034264774935664	1566034264749769839	1560328737491256322	createCard	{"card": {"name": "test"}, "list": {"id": "1566000088495424528", "name": "TODO", "type": "active"}}	2025-07-30 12:10:32.115	\N	1565999911277691916
1625784546039433065	1625784545921992552	1560328737491256322	createCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "list": {"id": "1625784489399551802", "name": "TODO", "type": "active"}}	2025-10-20 22:43:40.695	\N	1625784489189836598
1625784546668578667	1625784546618247018	1560328737491256322	createCard	{"card": {"name": "Load Quality Requirements"}, "list": {"id": "1625784489399551802", "name": "TODO", "type": "active"}}	2025-10-20 22:43:40.768	\N	1625784489189836598
1625784547314501485	1625784547247392620	1560328737491256322	createCard	{"card": {"name": "Extract Repo-Specific Principles"}, "list": {"id": "1625784489399551802", "name": "TODO", "type": "active"}}	2025-10-20 22:43:40.848	\N	1625784489189836598
1625784547842983791	1625784547817817966	1560328737491256322	createCard	{"card": {"name": "Load Prompt Templates"}, "list": {"id": "1625784489399551802", "name": "TODO", "type": "active"}}	2025-10-20 22:43:40.91	\N	1625784489189836598
1625784548220471153	1625784548178528112	1560328737491256322	createCard	{"card": {"name": "Validate META Asset Completeness"}, "list": {"id": "1625784489399551802", "name": "TODO", "type": "active"}}	2025-10-20 22:43:40.956	\N	1625784489189836598
1625784548556015474	1625784545921992552	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "toList": {"id": "1625784489542158139", "name": "READY", "type": "active"}, "fromList": {"id": "1625784489399551802", "name": "TODO", "type": "active"}}	2025-10-20 22:43:40.995	\N	1625784489189836598
1625967510077573045	1625967510052407220	1560328737491256322	createCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "list": {"id": "1625967479165552518", "name": "TODO", "type": "active"}}	2025-10-21 04:47:11.708	\N	1625967479098443650
1625967510211790775	1625967510203402166	1560328737491256322	createCard	{"card": {"name": "Load Quality Requirements"}, "list": {"id": "1625967479165552518", "name": "TODO", "type": "active"}}	2025-10-21 04:47:11.725	\N	1625967479098443650
1625967510329231289	1625967510320842680	1560328737491256322	createCard	{"card": {"name": "Extract Repo-Specific Principles"}, "list": {"id": "1625967479165552518", "name": "TODO", "type": "active"}}	2025-10-21 04:47:11.739	\N	1625967479098443650
1625967510488614843	1625967510471837626	1560328737491256322	createCard	{"card": {"name": "Load Prompt Templates"}, "list": {"id": "1625967479165552518", "name": "TODO", "type": "active"}}	2025-10-21 04:47:11.758	\N	1625967479098443650
1625967510622832573	1625967510614443964	1560328737491256322	createCard	{"card": {"name": "Validate META Asset Completeness"}, "list": {"id": "1625967479165552518", "name": "TODO", "type": "active"}}	2025-10-21 04:47:11.774	\N	1625967479098443650
1625967510723495870	1625967510052407220	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "toList": {"id": "1625967479224272775", "name": "READY", "type": "active"}, "fromList": {"id": "1625967479165552518", "name": "TODO", "type": "active"}}	2025-10-21 04:47:11.785	\N	1625967479098443650
1625967539085379524	1625967510052407220	1560328737491256322	moveCard	{"card": {"name": "Load Core Procedures for CODE_ANALYSIS"}, "toList": {"id": "1625967479274604424", "name": "DOING", "type": "active"}, "fromList": {"id": "1625967479224272775", "name": "READY", "type": "active"}}	2025-10-21 04:47:15.167	\N	1625967479098443650
\.


--
-- Data for Name: attachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attachment (id, card_id, creator_user_id, type, data, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: background_image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.background_image (id, project_id, dirname, extension, size_in_bytes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: base_custom_field_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.base_custom_field_group (id, project_id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: board; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board (id, project_id, "position", name, default_view, default_card_type, limit_card_types_to_default_one, always_display_card_creator, created_at, updated_at) FROM stdin;
1573201068874008314	1573201067548608248	1	EXECUTION	kanban	project	f	f	2025-08-09 09:29:41.74	\N
1573201069712869127	1573201067548608248	16385	KANBAN	kanban	project	f	f	2025-08-09 09:29:41.841	\N
1573201070316848916	1573201067548608248	8193	META	kanban	project	f	f	2025-08-09 09:29:41.912	\N
1625784485708564267	1625784483317810984	1	EXECUTION	kanban	project	f	f	2025-10-20 22:43:33.503	\N
1625784489189836598	1625784483317810984	8193	META	kanban	project	f	f	2025-10-20 22:43:33.918	\N
1625784490674620225	1625784483317810984	16385	KANBAN	kanban	project	f	f	2025-10-20 22:43:34.096	\N
1625784492318787404	1625784483317810984	81921	PROJECT	kanban	project	f	f	2025-10-20 22:43:34.29	\N
1625967478100199287	1625967477479442292	1	EXECUTION	kanban	project	f	f	2025-10-21 04:47:07.897	\N
1625967479098443650	1625967477479442292	8193	META	kanban	project	f	f	2025-10-21 04:47:08.016	\N
1625967480272848781	1625967477479442292	16385	KANBAN	kanban	project	f	f	2025-10-21 04:47:08.156	\N
1625967481069766552	1625967477479442292	81921	PROJECT	kanban	project	f	f	2025-10-21 04:47:08.251	\N
1625968218839451595	1573201067548608248	81921	PROJECT	kanban	project	f	f	2025-10-21 04:48:36.199	\N
\.


--
-- Data for Name: board_membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board_membership (id, project_id, board_id, user_id, role, can_comment, created_at, updated_at) FROM stdin;
1573201068882396923	1573201067548608248	1573201068874008314	1560328737491256322	editor	\N	2025-08-09 09:29:41.742	\N
1573201069377324804	1573201067548608248	1573201068874008314	1560328737491256323	editor	\N	2025-08-09 09:29:41.801	\N
1573201069486376709	1573201067548608248	1573201068874008314	1560328737491256324	viewer	t	2025-08-09 09:29:41.814	\N
1573201069553485574	1573201067548608248	1573201068874008314	1560328737491256325	viewer	t	2025-08-09 09:29:41.822	\N
1573201069721257736	1573201067548608248	1573201069712869127	1560328737491256322	editor	\N	2025-08-09 09:29:41.842	\N
1573201070140688145	1573201067548608248	1573201069712869127	1560328737491256324	editor	\N	2025-08-09 09:29:41.891	\N
1573201070191019794	1573201067548608248	1573201069712869127	1560328737491256323	viewer	t	2025-08-09 09:29:41.897	\N
1573201070241351443	1573201067548608248	1573201069712869127	1560328737491256325	viewer	t	2025-08-09 09:29:41.904	\N
1573201070316848917	1573201067548608248	1573201070316848916	1560328737491256322	editor	\N	2025-08-09 09:29:41.913	\N
1573201070711113502	1573201067548608248	1573201070316848916	1560328737491256325	editor	\N	2025-08-09 09:29:41.96	\N
1573201070761445151	1573201067548608248	1573201070316848916	1560328737491256323	viewer	t	2025-08-09 09:29:41.965	\N
1573201070820165408	1573201067548608248	1573201070316848916	1560328737491256324	viewer	t	2025-08-09 09:29:41.972	\N
1625784485716952876	1625784483317810984	1625784485708564267	1560328737491256322	editor	\N	2025-10-20 22:43:33.504	\N
1625784489198225207	1625784483317810984	1625784489189836598	1560328737491256322	editor	\N	2025-10-20 22:43:33.919	\N
1625784490683008834	1625784483317810984	1625784490674620225	1560328737491256322	editor	\N	2025-10-20 22:43:34.097	\N
1625784492352341837	1625784483317810984	1625784492318787404	1560328737491256322	editor	\N	2025-10-20 22:43:34.294	\N
1625784495456126808	1625784483317810984	1625784485708564267	1560328737491256323	editor	\N	2025-10-20 22:43:34.665	\N
1625784495573567321	1625784483317810984	1625784485708564267	1560328737491256324	viewer	t	2025-10-20 22:43:34.679	\N
1625784495833614170	1625784483317810984	1625784485708564267	1560328737491256325	viewer	t	2025-10-20 22:43:34.708	\N
1625784496336930652	1625784483317810984	1625784489189836598	1560328737491256325	editor	\N	2025-10-20 22:43:34.771	\N
1625784496555034461	1625784483317810984	1625784489189836598	1560328737491256323	viewer	t	2025-10-20 22:43:34.796	\N
1625784496689252190	1625784483317810984	1625784489189836598	1560328737491256324	viewer	t	2025-10-20 22:43:34.812	\N
1625784496907356000	1625784483317810984	1625784490674620225	1560328737491256324	editor	\N	2025-10-20 22:43:34.839	\N
1625784497024796513	1625784483317810984	1625784490674620225	1560328737491256323	viewer	t	2025-10-20 22:43:34.853	\N
1625784497117071202	1625784483317810984	1625784490674620225	1560328737491256325	viewer	t	2025-10-20 22:43:34.864	\N
1625784497360340836	1625784483317810984	1625784492318787404	1560328737491256323	viewer	t	2025-10-20 22:43:34.892	\N
1625784497511335781	1625784483317810984	1625784492318787404	1560328737491256324	viewer	t	2025-10-20 22:43:34.91	\N
1625784497897211750	1625784483317810984	1625784492318787404	1560328737491256325	viewer	t	2025-10-20 22:43:34.956	\N
1625967478108587896	1625967477479442292	1625967478100199287	1560328737491256322	editor	\N	2025-10-21 04:47:07.898	\N
1625967479106832259	1625967477479442292	1625967479098443650	1560328737491256322	editor	\N	2025-10-21 04:47:08.017	\N
1625967480281237390	1625967477479442292	1625967480272848781	1560328737491256322	editor	\N	2025-10-21 04:47:08.157	\N
1625967481078155161	1625967477479442292	1625967481069766552	1560328737491256322	editor	\N	2025-10-21 04:47:08.251	\N
1625967482252560292	1625967477479442292	1625967478100199287	1560328737491256323	editor	\N	2025-10-21 04:47:08.392	\N
1625967482294503333	1625967477479442292	1625967478100199287	1560328737491256324	viewer	t	2025-10-21 04:47:08.397	\N
1625967482344834982	1625967477479442292	1625967478100199287	1560328737491256325	viewer	t	2025-10-21 04:47:08.403	\N
1625967482437109672	1625967477479442292	1625967479098443650	1560328737491256325	editor	\N	2025-10-21 04:47:08.414	\N
1625967482487441321	1625967477479442292	1625967479098443650	1560328737491256323	viewer	t	2025-10-21 04:47:08.42	\N
1625967482621659050	1625967477479442292	1625967479098443650	1560328737491256324	viewer	t	2025-10-21 04:47:08.435	\N
1625967482781042604	1625967477479442292	1625967480272848781	1560328737491256324	editor	\N	2025-10-21 04:47:08.455	\N
1625967482839762861	1625967477479442292	1625967480272848781	1560328737491256323	viewer	t	2025-10-21 04:47:08.462	\N
1625967482906871726	1625967477479442292	1625967480272848781	1560328737491256325	viewer	t	2025-10-21 04:47:08.47	\N
1625967482999146416	1625967477479442292	1625967481069766552	1560328737491256323	viewer	t	2025-10-21 04:47:08.481	\N
1625967483041089457	1625967477479442292	1625967481069766552	1560328737491256324	viewer	t	2025-10-21 04:47:08.486	\N
1625967483074643890	1625967477479442292	1625967481069766552	1560328737491256325	viewer	t	2025-10-21 04:47:08.49	\N
1625968135104366538	1573201067548608248	1573201068874008314	1625967990719645641	viewer	t	2025-10-21 04:48:26.218	\N
1625968218847840204	1573201067548608248	1625968218839451595	1560328737491256322	editor	\N	2025-10-21 04:48:36.201	\N
1625968507122354133	1573201067548608248	1625968218839451595	1625967990719645641	editor	\N	2025-10-21 04:49:10.566	\N
1625968548738238422	1573201067548608248	1625968218839451595	1560328737491256323	viewer	t	2025-10-21 04:49:15.526	\N
1625968586747021271	1573201067548608248	1625968218839451595	1560328737491256324	viewer	t	2025-10-21 04:49:20.057	\N
1625968627817646040	1573201067548608248	1625968218839451595	1560328737491256325	viewer	t	2025-10-21 04:49:24.953	\N
\.


--
-- Data for Name: board_subscription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board_subscription (id, board_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card (id, board_id, list_id, creator_user_id, prev_list_id, cover_attachment_id, type, "position", name, description, due_date, stopwatch, created_at, updated_at, list_changed_at, comments_total) FROM stdin;
1625784546618247018	1625784489189836598	1625784489399551802	1560328737491256322	\N	\N	project	2	Load Quality Requirements	Load requirements for: code_quality\n\nThis card will select and load quality requirements.	\N	\N	2025-10-20 22:43:40.764	\N	2025-10-20 22:43:40.764	0
1625784547247392620	1625784489189836598	1625784489399551802	1560328737491256322	\N	\N	project	3	Extract Repo-Specific Principles	Extract principles from repository analysis.\n\nThis card will analyze the codebase and extract project-specific principles.	\N	\N	2025-10-20 22:43:40.84	\N	2025-10-20 22:43:40.839	0
1625784547817817966	1625784489189836598	1625784489399551802	1560328737491256322	\N	\N	project	4	Load Prompt Templates	Prepare prompt templates for project type: CODE_ANALYSIS\n\nThis card will load and prepare prompt templates.	\N	\N	2025-10-20 22:43:40.906	\N	2025-10-20 22:43:40.905	0
1625784548178528112	1625784489189836598	1625784489399551802	1560328737491256322	\N	\N	project	5	Validate META Asset Completeness	Validate that all META assets are loaded and ready.\n\nDepends on: 4 previous cards	\N	\N	2025-10-20 22:43:40.95	\N	2025-10-20 22:43:40.95	0
1625784545921992552	1625784489189836598	1625784489542158139	1560328737491256322	\N	\N	project	1	Load Core Procedures for CODE_ANALYSIS	Load procedures for: code_analysis\n\nThis card will select and load the necessary procedures from procedure_management.	\N	\N	2025-10-20 22:43:40.681	2025-10-20 22:43:40.984	2025-10-20 22:43:40.981	0
1625967510203402166	1625967479098443650	1625967479165552518	1560328737491256322	\N	\N	project	2	Load Quality Requirements	Load requirements for: code_quality\n\nThis card will select and load quality requirements.	\N	\N	2025-10-21 04:47:11.724	\N	2025-10-21 04:47:11.723	0
1625967510320842680	1625967479098443650	1625967479165552518	1560328737491256322	\N	\N	project	3	Extract Repo-Specific Principles	Extract principles from repository analysis.\n\nThis card will analyze the codebase and extract project-specific principles.	\N	\N	2025-10-21 04:47:11.738	\N	2025-10-21 04:47:11.737	0
1625967510471837626	1625967479098443650	1625967479165552518	1560328737491256322	\N	\N	project	4	Load Prompt Templates	Prepare prompt templates for project type: CODE_ANALYSIS\n\nThis card will load and prepare prompt templates.	\N	\N	2025-10-21 04:47:11.756	\N	2025-10-21 04:47:11.756	0
1625967510614443964	1625967479098443650	1625967479165552518	1560328737491256322	\N	\N	project	5	Validate META Asset Completeness	Validate that all META assets are loaded and ready.\n\nDepends on: 4 previous cards	\N	\N	2025-10-21 04:47:11.773	\N	2025-10-21 04:47:11.772	0
1625967510052407220	1625967479098443650	1625967479274604424	1560328737491256322	\N	\N	project	1	Load Core Procedures for CODE_ANALYSIS	Load procedures for: code_analysis\n\nThis card will select and load the necessary procedures from procedure_management.	\N	\N	2025-10-21 04:47:11.706	2025-10-21 04:49:39.791	2025-10-21 04:47:15.165	3
\.


--
-- Data for Name: card_label; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_label (id, card_id, label_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card_membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_membership (id, card_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card_subscription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_subscription (id, card_id, user_id, is_permanent, created_at, updated_at) FROM stdin;
1625967538045192129	1625967510052407220	1560328737491256322	t	2025-10-21 04:47:15.042	\N
\.


--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comment (id, card_id, user_id, text, created_at, updated_at) FROM stdin;
1625967537994860480	1625967510052407220	1560328737491256322	🚀 **Card Ready for Execution**\n\n**Status**: Initiated\n**Timestamp**: 2025-10-21T04:47:14.974333+00:00\n**Next**: Moving to DOING state for execution\n\nAll prerequisites satisfied, beginning execution process.	2025-10-21 04:47:15.037	\N
1625967539639027654	1625967510052407220	1560328737491256322	✅ **Batch batch_1761022034_approval** completed\n\n**Status**: Success\n**Duration**: 0.260646s\n**Timestamp**: 2025-10-21 04:47:15 UTC\n\n**Results**:\n- meta-ready: 0.26s\n	2025-10-21 04:47:15.233	\N
1625968752271034331	1625967510052407220	1560328737491256322	✅ **Batch batch_1761022177_approval** completed\n\n**Status**: Success\n**Duration**: 1.897399s\n**Timestamp**: 2025-10-21 04:49:39 UTC\n\n**Results**:\n- meta-doing: 1.90s\n	2025-10-21 04:49:39.79	\N
\.


--
-- Data for Name: custom_field; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_field (id, base_custom_field_group_id, custom_field_group_id, "position", name, show_on_front_of_card, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: custom_field_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_field_group (id, board_id, card_id, base_custom_field_group_id, "position", name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: custom_field_value; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_field_value (id, card_id, custom_field_group_id, custom_field_id, content, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: file_reference; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.file_reference (id, total, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: identity_provider_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.identity_provider_user (id, user_id, issuer, sub, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.label (id, board_id, "position", name, color, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.list (id, board_id, type, "position", name, color, created_at, updated_at) FROM stdin;
1573201068890785532	1573201068874008314	archive	\N	\N	\N	2025-08-09 09:29:41.743	\N
1573201068890785533	1573201068874008314	trash	\N	\N	\N	2025-08-09 09:29:41.743	\N
1573201068957894398	1573201068874008314	active	65536	TODO	\N	2025-08-09 09:29:41.751	\N
1573201069058557695	1573201068874008314	active	131072	READY	\N	2025-08-09 09:29:41.762	\N
1573201069100500736	1573201068874008314	active	196608	DOING	\N	2025-08-09 09:29:41.768	\N
1573201069150832385	1573201068874008314	active	262144	QA	\N	2025-08-09 09:29:41.774	\N
1573201069226329858	1573201068874008314	active	327680	BLOCKED	\N	2025-08-09 09:29:41.783	\N
1573201069268272899	1573201068874008314	active	393216	DONE	\N	2025-08-09 09:29:41.788	\N
1573201069729646345	1573201069712869127	archive	\N	\N	\N	2025-08-09 09:29:41.843	\N
1573201069729646346	1573201069712869127	trash	\N	\N	\N	2025-08-09 09:29:41.843	\N
1573201069788366603	1573201069712869127	active	65536	TODO	\N	2025-08-09 09:29:41.85	\N
1573201069872252684	1573201069712869127	active	131072	READY	\N	2025-08-09 09:29:41.859	\N
1573201069922584333	1573201069712869127	active	196608	DOING	\N	2025-08-09 09:29:41.866	\N
1573201069972915982	1573201069712869127	active	262144	QA	\N	2025-08-09 09:29:41.872	\N
1573201070014859023	1573201069712869127	active	327680	BLOCKED	\N	2025-08-09 09:29:41.877	\N
1573201070056802064	1573201069712869127	active	393216	DONE	\N	2025-08-09 09:29:41.882	\N
1573201070325237526	1573201070316848916	archive	\N	\N	\N	2025-08-09 09:29:41.914	\N
1573201070325237527	1573201070316848916	trash	\N	\N	\N	2025-08-09 09:29:41.914	\N
1573201070425900824	1573201070316848916	active	65536	TODO	\N	2025-08-09 09:29:41.925	\N
1573201070476232473	1573201070316848916	active	131072	READY	\N	2025-08-09 09:29:41.932	\N
1573201070518175514	1573201070316848916	active	196608	DOING	\N	2025-08-09 09:29:41.937	\N
1573201070560118555	1573201070316848916	active	262144	QA	\N	2025-08-09 09:29:41.942	\N
1573201070602061596	1573201070316848916	active	327680	BLOCKED	\N	2025-08-09 09:29:41.947	\N
1573201070644004637	1573201070316848916	active	393216	DONE	\N	2025-08-09 09:29:41.952	\N
1625784485742118701	1625784485708564267	archive	\N	\N	\N	2025-10-20 22:43:33.507	\N
1625784485750507310	1625784485708564267	trash	\N	\N	\N	2025-10-20 22:43:33.507	\N
1625784486966855471	1625784485708564267	active	65536	TODO	\N	2025-10-20 22:43:33.653	\N
1625784487445006128	1625784485708564267	active	131072	READY	\N	2025-10-20 22:43:33.71	\N
1625784487637944113	1625784485708564267	active	196608	DOING	\N	2025-10-20 22:43:33.733	\N
1625784487780550450	1625784485708564267	active	262144	QA	\N	2025-10-20 22:43:33.751	\N
1625784487897990963	1625784485708564267	active	327680	BLOCKED	\N	2025-10-20 22:43:33.764	\N
1625784488090928948	1625784485708564267	active	393216	DONE	\N	2025-10-20 22:43:33.788	\N
1625784489215002424	1625784489189836598	archive	\N	\N	\N	2025-10-20 22:43:33.921	\N
1625784489215002425	1625784489189836598	trash	\N	\N	\N	2025-10-20 22:43:33.921	\N
1625784489399551802	1625784489189836598	active	65536	TODO	\N	2025-10-20 22:43:33.944	\N
1625784489542158139	1625784489189836598	active	131072	READY	\N	2025-10-20 22:43:33.96	\N
1625784489667987260	1625784489189836598	active	196608	DOING	\N	2025-10-20 22:43:33.976	\N
1625784489785427773	1625784489189836598	active	262144	QA	\N	2025-10-20 22:43:33.989	\N
1625784489944811326	1625784489189836598	active	327680	BLOCKED	\N	2025-10-20 22:43:34.008	\N
1625784490053863231	1625784489189836598	active	393216	DONE	\N	2025-10-20 22:43:34.021	\N
1625784490708174659	1625784490674620225	archive	\N	\N	\N	2025-10-20 22:43:34.099	\N
1625784490708174660	1625784490674620225	trash	\N	\N	\N	2025-10-20 22:43:34.099	\N
1625784490808837957	1625784490674620225	active	65536	TODO	\N	2025-10-20 22:43:34.111	\N
1625784490917889862	1625784490674620225	active	131072	READY	\N	2025-10-20 22:43:34.125	\N
1625784491119216455	1625784490674620225	active	196608	DOING	\N	2025-10-20 22:43:34.148	\N
1625784491253434184	1625784490674620225	active	262144	QA	\N	2025-10-20 22:43:34.164	\N
1625784491446372169	1625784490674620225	active	327680	BLOCKED	\N	2025-10-20 22:43:34.187	\N
1625784491521869642	1625784490674620225	active	393216	DONE	\N	2025-10-20 22:43:34.197	\N
1625784492377507662	1625784492318787404	archive	\N	\N	\N	2025-10-20 22:43:34.298	\N
1625784492377507663	1625784492318787404	trash	\N	\N	\N	2025-10-20 22:43:34.298	\N
1625784492562057040	1625784492318787404	active	65536	TODO	\N	2025-10-20 22:43:34.321	\N
1625784492780160849	1625784492318787404	active	131072	READY	\N	2025-10-20 22:43:34.346	\N
1625784492956321618	1625784492318787404	active	196608	DOING	\N	2025-10-20 22:43:34.367	\N
1625784493073762131	1625784492318787404	active	262144	QA	\N	2025-10-20 22:43:34.381	\N
1625784493258311508	1625784492318787404	active	327680	BLOCKED	\N	2025-10-20 22:43:34.404	\N
1625784493417695061	1625784492318787404	active	393216	DONE	\N	2025-10-20 22:43:34.422	\N
1625967478116976505	1625967478100199287	archive	\N	\N	\N	2025-10-21 04:47:07.899	\N
1625967478125365114	1625967478100199287	trash	\N	\N	\N	2025-10-21 04:47:07.899	\N
1625967478192473979	1625967478100199287	active	65536	TODO	\N	2025-10-21 04:47:07.908	\N
1625967478276360060	1625967478100199287	active	131072	READY	\N	2025-10-21 04:47:07.918	\N
1625967478335080317	1625967478100199287	active	196608	DOING	\N	2025-10-21 04:47:07.925	\N
1625967478393800574	1625967478100199287	active	262144	QA	\N	2025-10-21 04:47:07.932	\N
1625967478502852479	1625967478100199287	active	327680	BLOCKED	\N	2025-10-21 04:47:07.945	\N
1625967478586738560	1625967478100199287	active	393216	DONE	\N	2025-10-21 04:47:07.954	\N
1625967479115220868	1625967479098443650	archive	\N	\N	\N	2025-10-21 04:47:08.018	\N
1625967479115220869	1625967479098443650	trash	\N	\N	\N	2025-10-21 04:47:08.018	\N
1625967479165552518	1625967479098443650	active	65536	TODO	\N	2025-10-21 04:47:08.024	\N
1625967479224272775	1625967479098443650	active	131072	READY	\N	2025-10-21 04:47:08.031	\N
1625967479274604424	1625967479098443650	active	196608	DOING	\N	2025-10-21 04:47:08.037	\N
1625967479333324681	1625967479098443650	active	262144	QA	\N	2025-10-21 04:47:08.044	\N
1625967479534651274	1625967479098443650	active	327680	BLOCKED	\N	2025-10-21 04:47:08.067	\N
1625967479702423435	1625967479098443650	active	393216	DONE	\N	2025-10-21 04:47:08.088	\N
1625967480289625999	1625967480272848781	archive	\N	\N	\N	2025-10-21 04:47:08.157	\N
1625967480289626000	1625967480272848781	trash	\N	\N	\N	2025-10-21 04:47:08.157	\N
1625967480348346257	1625967480272848781	active	65536	TODO	\N	2025-10-21 04:47:08.164	\N
1625967480398677906	1625967480272848781	active	131072	READY	\N	2025-10-21 04:47:08.171	\N
1625967480449009555	1625967480272848781	active	196608	DOING	\N	2025-10-21 04:47:08.177	\N
1625967480490952596	1625967480272848781	active	262144	QA	\N	2025-10-21 04:47:08.182	\N
1625967480532895637	1625967480272848781	active	327680	BLOCKED	\N	2025-10-21 04:47:08.187	\N
1625967480574838678	1625967480272848781	active	393216	DONE	\N	2025-10-21 04:47:08.192	\N
1625967481078155162	1625967481069766552	archive	\N	\N	\N	2025-10-21 04:47:08.252	\N
1625967481078155163	1625967481069766552	trash	\N	\N	\N	2025-10-21 04:47:08.252	\N
1625967481136875420	1625967481069766552	active	65536	TODO	\N	2025-10-21 04:47:08.259	\N
1625967481187207069	1625967481069766552	active	131072	READY	\N	2025-10-21 04:47:08.265	\N
1625967481229150110	1625967481069766552	active	196608	DOING	\N	2025-10-21 04:47:08.27	\N
1625967481271093151	1625967481069766552	active	262144	QA	\N	2025-10-21 04:47:08.275	\N
1625967481313036192	1625967481069766552	active	327680	BLOCKED	\N	2025-10-21 04:47:08.28	\N
1625967481354979233	1625967481069766552	active	393216	DONE	\N	2025-10-21 04:47:08.285	\N
1625968218864617421	1625968218839451595	archive	\N	\N	\N	2025-10-21 04:48:36.202	\N
1625968218864617422	1625968218839451595	trash	\N	\N	\N	2025-10-21 04:48:36.202	\N
1625968272249718735	1625968218839451595	active	65536	TODO	\N	2025-10-21 04:48:42.566	\N
1625968292466264016	1625968218839451595	active	131072	READY	\N	2025-10-21 04:48:44.977	\N
1625968313983043537	1625968218839451595	active	196608	DOING	\N	2025-10-21 04:48:47.541	\N
1625968348208564178	1625968218839451595	active	262144	QA	\N	2025-10-21 04:48:51.621	\N
1625968422674237395	1625968218839451595	active	327680	BLOCKED	\N	2025-10-21 04:49:00.498	\N
1625968439048800212	1625968218839451595	active	393216	DONE	\N	2025-10-21 04:49:02.45	\N
\.


--
-- Data for Name: migration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migration (id, name, batch, migration_time) FROM stdin;
1	20250228000022_version_2.js	1	2025-07-22 13:35:14.35+00
2	20250522151122_add_board_activity_log.js	1	2025-07-22 13:35:14.352+00
3	20250523131647_add_comments_counter.js	1	2025-07-22 13:35:14.353+00
4	20250603102521_canonicalize_locale_codes.js	1	2025-07-22 13:35:14.354+00
\.


--
-- Data for Name: migration_lock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migration_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification (id, user_id, creator_user_id, board_id, card_id, comment_id, action_id, type, data, is_read, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_service; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_service (id, user_id, board_id, url, format, created_at, updated_at) FROM stdin;
1565999542187328521	1560278692305830913	\N	json://mini2.local:8634/api/v1/flow-events/webhook	markdown	2025-07-30 11:01:32.859	\N
1566022531410822231	\N	1541385320996537361	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:13.388652	2025-07-30 12:08:07.365
1566022531410822232	\N	1541386488111957023	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:13.388652	2025-07-30 12:08:15.742
1566022531410822233	\N	1541386853553275948	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:13.388652	2025-07-30 12:08:23.596
1566033706831840358	\N	1566019210167977028	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 12:09:25.602	\N
1566033750276441191	\N	1566019210167977027	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 12:09:30.782	\N
1566033792991233128	\N	1565999911277691916	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 12:09:35.874	\N
1566022633139471450	\N	1565999911277691916	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:25.515868	2025-07-30 11:47:25.515868
1566022633139471451	\N	1566019210167977027	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:25.515868	2025-07-30 11:47:25.515868
1566022633139471452	\N	1566019210167977028	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:25.515868	2025-07-30 11:47:25.515868
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project (id, owner_project_manager_id, background_image_id, name, description, background_type, background_gradient, is_hidden, created_at, updated_at) FROM stdin;
1573201067548608248	\N	\N	Core Repository - Rearchitecture	\N	\N	\N	f	2025-08-09 09:29:41.572	\N
1625784483317810984	\N	\N	enterprise_mcp_server	\N	\N	\N	f	2025-10-20 22:43:33.218	\N
1625967477479442292	\N	\N	enterprise_mcp_server	\N	\N	\N	f	2025-10-21 04:47:07.822	\N
\.


--
-- Data for Name: project_favorite; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_favorite (id, project_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project_manager; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_manager (id, project_id, user_id, created_at, updated_at) FROM stdin;
1573201067573774073	1573201067548608248	1560328737491256322	2025-08-09 09:29:41.586	\N
1625784483351365417	1625784483317810984	1560328737491256322	2025-10-20 22:43:33.221	\N
1625967477479442293	1625967477479442292	1560328737491256322	2025-10-21 04:47:07.823	\N
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session (id, user_id, access_token, http_only_token, remote_address, user_agent, created_at, updated_at, deleted_at) FROM stdin;
1560294586092356611	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjAzN2Y4YjIyLTU0YzMtNDVhMi04Mzk2LTM2N2FiZWI0M2U2YiJ9.eyJpYXQiOjE3NTMxOTMyMDksImV4cCI6MTc4NDcyOTIwOSwic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.B9YaJbWEbGLo5wG6UuGgeFKDtcixTiCLeCQ0Z462oIs	fcd4dc85-2b9d-4125-81bb-1f21c400d3c6	151.101.128.223	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 14:06:49.095	\N	\N
1560328737491256326	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjllZDg4ODgzLWI0Y2MtNDI0NS1iOTZjLTVkZWZmZTk0ZTg1YSJ9.eyJpYXQiOjE3NTM4NzI2ODMsImV4cCI6MTc4NTQwODY4Mywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.q02RBVLTM2Ald69pfn8xBcUCATBdqAFcFP-ndN-_hF4	\N	127.0.0.1	API Client	2025-07-30 10:51:29.898679	2025-07-30 10:51:29.898679	\N
1565996599279092742	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImIxMDJmZjE3LWU4MjgtNDJhZC05ZDk4LTVlMDFmNjgxNWY4ZiJ9.eyJpYXQiOjE3NTM4NzI5NDIsImV4cCI6MTc4NTQwODk0Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ml3BmWfjj03jomVI2uJdJLlqj8F2fIQkuT5c6CBtNLA	b153c63b-4562-49ca-8cee-2727a4dc051d	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 10:55:42.036	2025-07-30 11:00:11.817	2025-07-30 11:00:11.816
1565998904820892680	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjE3ZDFhYTk1LTM1MmUtNDMwNS04NjZjLTdmMjA0MTY1MjU4ZCJ9.eyJpYXQiOjE3NTM4NzMyMTYsImV4cCI6MTc4NTQwOTIxNiwic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.wxOtFDkb6tEuB-e-G87QBgIFe98EKxESq2uc6vxbvdU	6bfaa4a3-4721-4086-ba63-b0cab1c19a18	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:00:16.878	2025-07-30 11:11:25.3	2025-07-30 11:11:25.298
1566004531731366934	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjBmYmM0ODk2LTI4MWYtNDViOC04NzAyLTNmMGIyMGM4Y2RiZiJ9.eyJpYXQiOjE3NTM4NzM4ODcsImV4cCI6MTc4NTQwOTg4Nywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.8DAHLMniUdCG8eMZkrVi6xM6P0vbTmcx8LYuLbSKAmU	c8d09b71-a2f6-4a6f-927c-fd894eeda38b	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:11:27.659	2025-07-30 11:23:34.744	2025-07-30 11:23:34.743
1566010658535769148	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjkxODMwNWZmLWMzYzMtNDkxMy05YmJkLWZhODkwYWQ0N2UxMiJ9.eyJpYXQiOjE3NTM4NzQ2MTgsImV4cCI6MTc4NTQxMDYxOCwic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.TM6KEQJQBuXsZ7ffjVjcRKrFcArXVaelDHBjgVuxunI	606003c2-c924-4b8f-bae4-f45c63da76ff	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:23:38.032	2025-07-30 11:29:54.912	2025-07-30 11:29:54.91
1566013844503921729	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjcyZmQyYzM1LWVhNjItNDZkYy1iYjA4LTk2MDgzOTUyYmFkMCJ9.eyJpYXQiOjE3NTM4NzQ5OTcsImV4cCI6MTc4NTQxMDk5Nywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Ut1GIjkn2kdZ_OFTubbZTlm7VWgfrycsHTGkORENfXs	49686d2f-d3b0-4688-8979-9ee345e3db01	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:29:57.829	\N	\N
1572105354811016308	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQzYWMyMTcxLTQ0YmEtNDQ0Yi05YzU0LTVhYzU5NDMzY2Y2YSJ9.eyJpYXQiOjE3NTQ2MDExNjIsImV4cCI6MTc4NjEzNzE2Miwic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.wqarkYGmWGchfdqW2CCtNpDL4JXLYAPL4SkDN6ryTnE	019fe815-6f03-496c-ac49-6cab12d4014e	142.250.179.187	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15	2025-08-07 21:12:42.443	\N	\N
1572120589982762101	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg2M2FiMDMwLTUwZjEtNDJmNy1iYTUyLTU3MmEzMzUwMzJkYSJ9.eyJpYXQiOjE3NTQ2MDI5NzgsImV4cCI6MTc4NjEzODk3OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.hIi2r_oad-oBu-zclw2ZvaxaS0W11NLeorH-cKTSJY8	\N	142.250.179.187	Python-urllib/3.13	2025-08-07 21:42:58.618	\N	\N
1572120638863180918	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjY0Y2YxMDM5LTQ3YTAtNDgwNC1iNWE4LWNjZGNmOTgzODdlZSJ9.eyJpYXQiOjE3NTQ2MDI5ODQsImV4cCI6MTc4NjEzODk4NCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Yuq7g116ACd5kml5HP0ayS9FiniAig3gUSC2-gerVE4	\N	142.250.179.187	Python-urllib/3.13	2025-08-07 21:43:04.447	\N	\N
1572120709486871671	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImQ3YzIyOTQxLTkyYTQtNDA4NC1iYTc4LWMxNTVmOTE1ZWYzMSJ9.eyJpYXQiOjE3NTQ2MDI5OTIsImV4cCI6MTc4NjEzODk5Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.e-vOn0G3GnL7PS98X8qmv0QusZxIk1fi_oXHW7fa3WM	\N	142.250.179.187	Python-urllib/3.13	2025-08-07 21:43:12.866	\N	\N
1572120946196612216	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQyM2MzYjlkLTNmZGItNDZhYS04NDc0LTJlNzBlMjJiNTNhYiJ9.eyJpYXQiOjE3NTQ2MDMwMjEsImV4cCI6MTc4NjEzOTAyMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.LmOR5Htz6wICxT-Ek1aRWKUS6YkSIZqrtFmt7WcDV5k	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:43:41.082	\N	\N
1572121045853275257	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg4OTQ3NGI0LTRmODctNDdhMi04YzUzLTZhMWZmMzQ4NzY4NyJ9.eyJpYXQiOjE3NTQ2MDMwMzIsImV4cCI6MTc4NjEzOTAzMiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Os9ISwVNBNLUjGJE29ZKBh30-KZkxoBqxM7Y07lg8dI	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:43:52.963	\N	\N
1572121901784892538	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjI3NGQxNzJkLTA2ZTktNDA4Zi05ZWIxLWFhODAxZTRkMWI5YiJ9.eyJpYXQiOjE3NTQ2MDMxMzQsImV4cCI6MTc4NjEzOTEzNCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.qqoOOaAnQXVUv_Szc4r9WMa0fN-jC18zZl0QdCQyEXc	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:45:34.998	\N	\N
1572122394867270779	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImU4YjM1OWZkLTk4Y2ItNGUyMy05NjU0LTM1MDUyMTBmZTBmNSJ9.eyJpYXQiOjE3NTQ2MDMxOTMsImV4cCI6MTc4NjEzOTE5Mywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.46DwZc1MK9h2tD2wBgE-nOADpdG9w-Zu7IY4_ZdsMIk	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:46:33.778	\N	\N
1572122796731925628	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjE0YTMzM2YzLTI2NTgtNDAyYy05Y2Q4LTFmZjRiNGZlOTM3OSJ9.eyJpYXQiOjE3NTQ2MDMyNDEsImV4cCI6MTc4NjEzOTI0MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.2lAOwYbTlPAZS3K6D6qhpe9h2xX7ffgg1VzOIciD2Bw	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:47:21.683	\N	\N
1572123028853097599	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjFkNWFmMzBmLTM1YzAtNGZiNy1iY2EwLWE5YzczNDg1YzQ3OCJ9.eyJpYXQiOjE3NTQ2MDMyNjksImV4cCI6MTc4NjEzOTI2OSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.37eztz7Z_VmsL8CNsvm_-Qr80vXvglVlVZtc7S90RZI	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:47:49.355	\N	\N
1572130827263804546	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjJjM2VkODc2LTJkNmMtNDAwNi04MWFkLWExMTEyZmM0NjM5OCJ9.eyJpYXQiOjE3NTQ2MDQxOTgsImV4cCI6MTc4NjE0MDE5OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.4rSidu_0MEvWHb36QnCIESkr0urZO4ZYw2J8472hXRU	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:03:18.996	\N	\N
1572131155786859665	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjVmZjA1NzY0LTk0ZTQtNGExNi1hNjBhLWI0OWYzNzFhY2YwNSJ9.eyJpYXQiOjE3NTQ2MDQyMzgsImV4cCI6MTc4NjE0MDIzOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.cIifhdg3RiuPw7BSOdLRKqm4903UZt7OqOOGoVhCU6w	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:03:58.161	\N	\N
1572131313291363488	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjlhZGU5YjQ0LTkyM2MtNDNiYi1hYzczLTE2ZmFiZDkyNGMyMiJ9.eyJpYXQiOjE3NTQ2MDQyNTYsImV4cCI6MTc4NjE0MDI1Niwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.9jrwy4HYjcfDmV3jBvQLhrEROKzo5GWvii12RA8bmQo	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:04:16.937	\N	\N
1572131367280444591	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImVhNmYyZDNlLTk4ZGUtNDg4ZC04ODhkLWFhMDhjMGUyZGI0NiJ9.eyJpYXQiOjE3NTQ2MDQyNjMsImV4cCI6MTc4NjE0MDI2Mywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Lb110Bgwgd-uvPpHOBj8d2JftFhUwaLg-AuUmdnm3bI	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:04:23.374	\N	\N
1572131515842692286	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjllZTRkZjc5LTZlODAtNGFhNC04OGRlLWE3MWZlM2RkYjBiOCJ9.eyJpYXQiOjE3NTQ2MDQyODEsImV4cCI6MTc4NjE0MDI4MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.7t0D8fRszB2hRqnlo2HV_n0A65YB-BpTy-AzwIt7zWY	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:04:41.082	\N	\N
1572132139728635103	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImFjMmM4Yzc1LTU1YTUtNDUzZi05NTg1LTVmYmRlYWM5Y2Q4MCJ9.eyJpYXQiOjE3NTQ2MDQzNTUsImV4cCI6MTc4NjE0MDM1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.33sXLWxXv5OqxPc7w6wYEWyMKVRtvfTShfqWLDmXRDE	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:05:55.455	\N	\N
1572132307601458432	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjZiN2FlMDlkLWJhNzYtNGRmNC1hZTU2LWJhNmVkNGVlMjQyZSJ9.eyJpYXQiOjE3NTQ2MDQzNzUsImV4cCI6MTc4NjE0MDM3NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.BlgzsB6XtVucEjzOPudMcjrry0LSoZqdt80V03rC6Jo	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:06:15.467	\N	\N
1572132506755400961	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImUzMjE4YjkyLTA2MTUtNGEwNi05ODgyLThjMTdjNDlmN2Y4MiJ9.eyJpYXQiOjE3NTQ2MDQzOTksImV4cCI6MTc4NjE0MDM5OSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.5nrfWnMwyYMcZhMA5KopAvEPSxh875YAWCsfCvU7PhM	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:06:39.208	\N	\N
1572133168926950658	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc0YmMzMTE4LTExNDUtNDk4NS1hOTY0LTM5OWNjNmNhMDM5NCJ9.eyJpYXQiOjE3NTQ2MDQ0NzgsImV4cCI6MTc4NjE0MDQ3OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ktDc75UculROzIG6FKvUfetBEW4amYDaLbqCk_eZPkw	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:07:58.145	\N	\N
1572139607955342627	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg4NDNiNTAwLTg4M2QtNDExNS1hOTc1LTU5ZDU3OWU4ZTYwYSJ9.eyJpYXQiOjE3NTQ2MDUyNDUsImV4cCI6MTc4NjE0MTI0NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.eVskS1Lq74Or76EMZjQ2_XPOW-OYImmxuOkCnlaLPVo	4ed8dc5c-8393-44ba-a459-4063f96f4eb3	142.250.179.187	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-07 22:20:45.737	\N	\N
1572140517012014373	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImNhNWFkMTM4LTJiYjgtNGIzZi1iNDRkLTI0ZmFiZGViZGNmMSJ9.eyJpYXQiOjE3NTQ2MDUzNTQsImV4cCI6MTc4NjE0MTM1NCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Xue2Vaqs0sEhuZ4Hn8L8CnOUdaJBYuN7i8iC8_iy8ek	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:22:34.105	\N	\N
1572141597875766607	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjliOTM5ZjhiLWE4NmMtNGM5Ny1iYmVmLWY2NzQ5NGIzYTk2MyJ9.eyJpYXQiOjE3NTQ2MDU0ODIsImV4cCI6MTc4NjE0MTQ4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Dw5urJY2zYUd29uI46VFo-ms_V0kfeA7QE54qiO2xds	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:24:42.955	\N	\N
1573185207350068570	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjI2ZDlkY2U5LWQ4NGYtNGMwZC1iY2E1LThhN2RjMzc1ZGVkOCJ9.eyJpYXQiOjE3NTQ3Mjk4OTAsImV4cCI6MTc4NjI2NTg5MCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.zhOJNh-CKHIMbB30xPt_YWPW6jdCYLbsIEDCm0e9Las	924a3417-bc5d-4a68-a961-f928e9ca1d8c	172.66.128.70	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-09 08:58:10.898	\N	\N
1573191082949215580	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjMwZGU2ZWYzLTExY2MtNDE3Yy05Y2EzLTY3MzQyYWQ4ZWU0YSJ9.eyJpYXQiOjE3NTQ3MzA1OTEsImV4cCI6MTc4NjI2NjU5MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.U1DIW7L6FlObNkU6Zp2-ZPs4fyYKYXqPUJeDK_Yd3Zk	\N	172.26.0.2	Python/3.12 aiohttp/3.12.15	2025-08-09 09:09:51.316	\N	\N
1573193974946989610	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJhNzM1ZDlhLThkZTgtNGRkMy04NWYyLWM5Y2U1N2I0NzYyZiJ9.eyJpYXQiOjE3NTQ3MzA5MzYsImV4cCI6MTc4NjI2NjkzNiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.SOIem_vkR5aL54QKRn5z_eZKHJzXC4uCM9HP6ryKsIA	\N	172.26.0.2	python-requests/2.32.4	2025-08-09 09:15:36.078	\N	\N
1573201460772996897	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImI4Nzg0MzhkLTM0ZDktNDEwNi05NzdkLWVkZWU3MDIwZjBjOSJ9.eyJpYXQiOjE3NTQ3MzE4MjgsImV4cCI6MTc4NjI2NzgyOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.MhMuJaIsQi6hClay_-6VXQfR1jDTxyx6rUQdygkAUkc	\N	172.26.0.2	python-requests/2.32.4	2025-08-09 09:30:28.457	\N	\N
1573203893385430818	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImVkZDcwZGY0LTc0MjItNGE0ZS04Y2U2LTBhMmQ5ZGI0ODkzMCJ9.eyJpYXQiOjE3NTQ3MzIxMTgsImV4cCI6MTc4NjI2ODExOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Q_3kWuwevvjPzTSY7-TCoBt6OxLoKS-VYosldUtI7fE	\N	172.26.0.2	python-requests/2.32.4	2025-08-09 09:35:18.448	\N	\N
1573216175389673253	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImMyZWNjZWE2LWU2MTAtNDFiMi1hNjRiLTY2MGRmZGQ2ZTgzMyJ9.eyJpYXQiOjE3NTQ3MzM1ODIsImV4cCI6MTc4NjI2OTU4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.PtDpuG9BxXuAK8oXmKJQCTXayN0TwgCSU7VhnjNIuGo	228dd350-bd34-480c-9982-9189f989fa29	172.66.128.70	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-09 09:59:42.574	\N	\N
1625784483108095783	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImIxZWFhNTllLWMyNmEtNGExYy05ZGM1LWUzYWM0OGIxMTRiNSJ9.eyJpYXQiOjE3NjEwMDAyMTMsImV4cCI6NDkxNDYwMDIxMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.QMVlbidLo82MJ1dNhWPHVhYQYkMv-hhOjZz_fn6nb2k	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-20 22:43:33.183	\N	\N
1625784484508993322	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjYyMzE0MTU3LTBhMWMtNDZmMC05N2YxLTM2ZWUzZTc0MWUyNSJ9.eyJpYXQiOjE3NjEwMDAyMTMsImV4cCI6NDkxNDYwMDIxMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.lENObpd_DPFaEpddcDtg8DLA8CM35EcCaA83aGQQeIo	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-20 22:43:33.356	\N	\N
1625784489072396085	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjFiOTNmYWExLWYzZTItNDQ5Zi1hOWIwLWUxYTMxMTFhZWFlZCJ9.eyJpYXQiOjE3NjEwMDAyMTMsImV4cCI6NDkxNDYwMDIxMywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.RgByQ2DCpJvbZad3-o0g9q9oMlQxTPGbJjbLr9zGMbs	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-20 22:43:33.904	\N	\N
1625784490582345536	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjJlN2NkODVlLTFmN2ItNDkxZS1iN2QxLTc1ZGE0NDNhZGFkMyJ9.eyJpYXQiOjE3NjEwMDAyMTQsImV4cCI6NDkxNDYwMDIxNCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.KQhJIJPWp3_trYvi-l_0IJeXKQOtRUYbHgzeftf_Ga0	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-20 22:43:34.085	\N	\N
1625784492134238027	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImRkMThiOTZiLTUzMGYtNDMwZC05NjQ5LWVlNDhiY2ZmYjM4MiJ9.eyJpYXQiOjE3NjEwMDAyMTQsImV4cCI6NDkxNDYwMDIxNCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Rck2ZwiS7Z7-iOK33t54ISvgU0wt4u8BosmfNUYmgiE	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-20 22:43:34.269	\N	\N
1625784494583711574	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjlmM2I2MWZiLTMxNTktNDk5ZS1iOWM5LTQ5Y2ZlZmI4N2NhNiJ9.eyJpYXQiOjE3NjEwMDAyMTQsImV4cCI6NDkxNDYwMDIxNCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.U7qjwKpWYKhusWw2y27s2xF04nzTDIkHDBhfmig8_kY	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-20 22:43:34.561	\N	\N
1625784544714032999	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImU3NTFiNmEyLTIyZGEtNDE4Yy05ZDY1LTUwNDVhNGIzZmJhZSJ9.eyJpYXQiOjE3NjEwMDAyMjAsImV4cCI6NDkxNDYwMDIyMCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.isWCAnppog4a_tFipBu20bfb1ey_uMbwyXaxBvH4_Lw	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-20 22:43:40.537	\N	\N
1625967477387167603	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjA5ZTczMWMwLTdhM2YtNGIxYS1hNDEzLTBhODJhZGQ0YzU1NCJ9.eyJpYXQiOjE3NjEwMjIwMjcsImV4cCI6NDkxNDYyMjAyNywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Jd_x2_JX4iX9OwBXODbnRSvZ93x45tb5EXu7Y6z0iek	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 04:47:07.803	\N	\N
1625967478033090422	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjIzZjdmN2JlLTE4MzAtNDEwYS04ZTg5LTM2OGVlNGQyN2I2YiJ9.eyJpYXQiOjE3NjEwMjIwMjcsImV4cCI6NDkxNDYyMjAyNywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ZRnmAaJHUrlm9OQK7siC45yS00thDauJ5aLwtIL8Rb8	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 04:47:07.889	\N	\N
1625967479048112001	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImNiOWRkOWZlLWUxOGMtNDY5My04NDIzLWY1NzVhNjdjZjg0MiJ9.eyJpYXQiOjE3NjEwMjIwMjgsImV4cCI6NDkxNDYyMjAyOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ekW82lq_inubTFAU5UC7Cju9GI9vqBRajKvQ42hE76Q	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 04:47:08.009	\N	\N
1625967480230905740	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjE1N2E4MmVjLWZlNGQtNGJhMi1iZjRkLWU2OTkzNGM0NGM3YSJ9.eyJpYXQiOjE3NjEwMjIwMjgsImV4cCI6NDkxNDYyMjAyOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.MwqnBOQ0brJJEKj9zHyUr7SXPPtMuIihbT7hQW3_zjc	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 04:47:08.15	\N	\N
1625967481027823511	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg0MDFkOTQ3LTg1OTMtNDYxYy05ODM1LTJjNTA0NTVhMjM0YSJ9.eyJpYXQiOjE3NjEwMjIwMjgsImV4cCI6NDkxNDYyMjAyOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.n1Za3fE5tYPcJjFtatFHux-WWHjrEThEQw9rMYxnsJM	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 04:47:08.245	\N	\N
1625967482026067874	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjhlYmEzYzczLWQ5ZjYtNDdlMi1hNWIxLWRhYzE1NGZjYTcyOCJ9.eyJpYXQiOjE3NjEwMjIwMjgsImV4cCI6NDkxNDYyMjAyOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.1cPz6gY9CD6su8B9kO4qA96CuZcs-9r_U7YZNqpDrg8	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 04:47:08.364	\N	\N
1625967509909800883	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImVjZmJlNTE4LTYwNmMtNDM2YS05ZTIzLTlmNGVlMmE0NzQ4NCJ9.eyJpYXQiOjE3NjEwMjIwMzEsImV4cCI6NDkxNDYyMjAzMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ny2MQ29kfWTYaAIMh7zWJVPwWIfXGvQwz_UWd0y5YLM	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 04:47:11.689	\N	\N
1625967537936140223	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImZmNThhNjRiLWQzOGEtNGFiNy05NDM3LTFkZTJhYzBiMzY4ZiJ9.eyJpYXQiOjE3NjEwMjIwMzUsImV4cCI6NDkxNDYyMjAzNSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.HbwrSzWqwkwvS29q7H5Hdk-zkFfuk-KnwxZX7kuC_Vo	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 04:47:15.029	\N	\N
1625967538481399746	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImEzNzE4NGVlLWUxZDMtNDliNi05NmJhLTUzYjY5YzJjMzM0NyJ9.eyJpYXQiOjE3NjEwMjIwMzUsImV4cCI6NDkxNDYyMjAzNSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.5Q8m7ZGTXvjpHefXVFtoBfwWGNEW36cVlanKgaHFyeY	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 04:47:15.095	\N	\N
1625967539009882051	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjRiM2JhZGU1LWNkYjMtNGE5ZC1iYTcyLTE3NjYzNTY2MTkwZiJ9.eyJpYXQiOjE3NjEwMjIwMzUsImV4cCI6NDkxNDYyMjAzNSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Jh-p8vcQj_u6hKFwzdILxjzv853Zm9kAH2R8tNeShgw	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 04:47:15.157	\N	\N
1625967539597084613	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjgyNDE1ZGVkLTRiZmUtNDJjMC1hNTViLTFjMTkwODA4YTM1YiJ9.eyJpYXQiOjE3NjEwMjIwMzUsImV4cCI6NDkxNDYyMjAzNSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.sOYPNwWoJ6ZxG1lbppvM_kYb9e9tj133wSdofMSItkQ	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 04:47:15.228	\N	\N
1625967825925441480	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjcxNmNhN2MzLWU4ZWYtNGU3NS1hYzFjLTcyYmFiYjg5Zjg1ZCJ9.eyJpYXQiOjE3NjEwMjIwNjksImV4cCI6NDkxNDYyMjA2OSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Xw5CB5vCaVRiqUw8de8vagFi45bgaXXbCrWP91lr--I	16a22621-4415-4903-bad1-5645bf4e9729	172.18.0.13	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-21 04:47:49.359	\N	\N
1625968751490893785	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijk2YWFkMjRjLWU3NjMtNGIwZi04ZjZiLWUwYzBkZWIyYWM5ZCJ9.eyJpYXQiOjE3NjEwMjIxNzksImV4cCI6NDkxNDYyMjE3OSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.PkpPnzHx4dNrdnRo6D5eAqsrRoiFYQtI8lPamiummpI	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 04:49:39.694	\N	\N
1625968752195536858	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijk2NzY2ZWM4LTliMTItNGQxNS04YjdhLWNhZmM0NGQ5ZjRjNiJ9.eyJpYXQiOjE3NjEwMjIxNzksImV4cCI6NDkxNDYyMjE3OSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.IV6hvrrCeTMKSgIkZhGRdMlmnvU0tRgdzoaDUBXeDPU	\N	172.18.0.13	Python/3.12 aiohttp/3.13.0	2025-10-21 04:49:39.781	\N	\N
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task (id, task_list_id, assignee_user_id, "position", name, is_completed, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_list (id, card_id, "position", name, show_on_front_of_card, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_account (id, email, password, role, name, username, avatar, phone, organization, language, subscribe_to_own_cards, subscribe_to_card_when_commenting, turn_off_recent_card_highlighting, enable_favorites_by_default, default_editor_mode, default_home_view, default_projects_order, is_sso_user, is_deactivated, created_at, updated_at, password_changed_at) FROM stdin;
1560328737491256323	execution_agent@gmail.com	$2b$10$vpoSEvqsa0KymG.SnTHsU.CwGePmc/gPAO0Ze4/QE.BAUF8UH1SeK	boardUser	Execution Agent	execution_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-30 10:50:39.567685	2025-07-30 11:00:33.651	\N
1560328737491256324	kanban_agent@gmail.com	$2b$10$vpoSEvqsa0KymG.SnTHsU.CwGePmc/gPAO0Ze4/QE.BAUF8UH1SeK	boardUser	Kanban Agent	kanban_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-30 10:50:39.567685	2025-07-30 11:00:37.275	\N
1560328737491256325	meta_agent@gmail.com	$2b$10$vpoSEvqsa0KymG.SnTHsU.CwGePmc/gPAO0Ze4/QE.BAUF8UH1SeK	boardUser	Meta Agent	meta_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-30 10:50:39.567685	2025-07-30 11:00:41.191	\N
1560328737491256322	agent@gmail.com	$2b$10$vpoSEvqsa0KymG.SnTHsU.CwGePmc/gPAO0Ze4/QE.BAUF8UH1SeK	admin	Admin Agent	admin_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-30 10:50:39.567685	2025-07-30 11:23:54.304	\N
1560278692305830913	demo@demo.demo	$2b$10$ZPuIAkXdl6WH.CBuf6DLNOQgXaXgQwYwRFp1p4hJfomYIODJVxKXC	admin	Demo User	demo	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-22 13:35:14.411	\N	\N
1625967990719645641	project_agent@gmail.com	$2b$10$ki5KTUJbn3Mbqkm.qds2r.vxv7V4m6G2IdqYi84juWzL1Oo3Vjln6	boardUser	Project Agent	project_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-10-21 04:48:09.004	\N	\N
\.


--
-- Name: migration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migration_id_seq', 4, true);


--
-- Name: migration_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migration_lock_index_seq', 1, true);


--
-- Name: next_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.next_id_seq', 988, true);


--
-- Name: action action_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.action
    ADD CONSTRAINT action_pkey PRIMARY KEY (id);


--
-- Name: attachment attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachment
    ADD CONSTRAINT attachment_pkey PRIMARY KEY (id);


--
-- Name: background_image background_image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.background_image
    ADD CONSTRAINT background_image_pkey PRIMARY KEY (id);


--
-- Name: base_custom_field_group base_custom_field_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.base_custom_field_group
    ADD CONSTRAINT base_custom_field_group_pkey PRIMARY KEY (id);


--
-- Name: board_membership board_membership_board_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_membership
    ADD CONSTRAINT board_membership_board_id_user_id_unique UNIQUE (board_id, user_id);


--
-- Name: board_membership board_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_membership
    ADD CONSTRAINT board_membership_pkey PRIMARY KEY (id);


--
-- Name: board board_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board
    ADD CONSTRAINT board_pkey PRIMARY KEY (id);


--
-- Name: board_subscription board_subscription_board_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_subscription
    ADD CONSTRAINT board_subscription_board_id_user_id_unique UNIQUE (board_id, user_id);


--
-- Name: board_subscription board_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_subscription
    ADD CONSTRAINT board_subscription_pkey PRIMARY KEY (id);


--
-- Name: card_label card_label_card_id_label_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_label
    ADD CONSTRAINT card_label_card_id_label_id_unique UNIQUE (card_id, label_id);


--
-- Name: card_label card_label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_label
    ADD CONSTRAINT card_label_pkey PRIMARY KEY (id);


--
-- Name: card_membership card_membership_card_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_membership
    ADD CONSTRAINT card_membership_card_id_user_id_unique UNIQUE (card_id, user_id);


--
-- Name: card_membership card_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_membership
    ADD CONSTRAINT card_membership_pkey PRIMARY KEY (id);


--
-- Name: card card_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card
    ADD CONSTRAINT card_pkey PRIMARY KEY (id);


--
-- Name: card_subscription card_subscription_card_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_subscription
    ADD CONSTRAINT card_subscription_card_id_user_id_unique UNIQUE (card_id, user_id);


--
-- Name: card_subscription card_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_subscription
    ADD CONSTRAINT card_subscription_pkey PRIMARY KEY (id);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: custom_field_group custom_field_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field_group
    ADD CONSTRAINT custom_field_group_pkey PRIMARY KEY (id);


--
-- Name: custom_field custom_field_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field
    ADD CONSTRAINT custom_field_pkey PRIMARY KEY (id);


--
-- Name: custom_field_value custom_field_value_card_id_custom_field_group_id_custom_field_i; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field_value
    ADD CONSTRAINT custom_field_value_card_id_custom_field_group_id_custom_field_i UNIQUE (card_id, custom_field_group_id, custom_field_id);


--
-- Name: custom_field_value custom_field_value_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field_value
    ADD CONSTRAINT custom_field_value_pkey PRIMARY KEY (id);


--
-- Name: file_reference file_reference_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_reference
    ADD CONSTRAINT file_reference_pkey PRIMARY KEY (id);


--
-- Name: identity_provider_user identity_provider_user_issuer_sub_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider_user
    ADD CONSTRAINT identity_provider_user_issuer_sub_unique UNIQUE (issuer, sub);


--
-- Name: identity_provider_user identity_provider_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider_user
    ADD CONSTRAINT identity_provider_user_pkey PRIMARY KEY (id);


--
-- Name: label label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: list list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list
    ADD CONSTRAINT list_pkey PRIMARY KEY (id);


--
-- Name: migration_lock migration_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration_lock
    ADD CONSTRAINT migration_lock_pkey PRIMARY KEY (index);


--
-- Name: migration migration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration
    ADD CONSTRAINT migration_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: notification_service notification_service_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_service
    ADD CONSTRAINT notification_service_pkey PRIMARY KEY (id);


--
-- Name: project_favorite project_favorite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_favorite
    ADD CONSTRAINT project_favorite_pkey PRIMARY KEY (id);


--
-- Name: project_favorite project_favorite_project_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_favorite
    ADD CONSTRAINT project_favorite_project_id_user_id_unique UNIQUE (project_id, user_id);


--
-- Name: project_manager project_manager_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_manager
    ADD CONSTRAINT project_manager_pkey PRIMARY KEY (id);


--
-- Name: project_manager project_manager_project_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_manager
    ADD CONSTRAINT project_manager_project_id_user_id_unique UNIQUE (project_id, user_id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: session session_access_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_access_token_unique UNIQUE (access_token);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: task_list task_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_list
    ADD CONSTRAINT task_list_pkey PRIMARY KEY (id);


--
-- Name: task task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: user_account user_account_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_email_unique UNIQUE (email);


--
-- Name: user_account user_account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_pkey PRIMARY KEY (id);


--
-- Name: user_account user_account_username_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_username_unique EXCLUDE USING btree (username WITH =) WHERE ((username IS NOT NULL));


--
-- Name: action_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_board_id_index ON public.action USING btree (board_id);


--
-- Name: action_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_card_id_index ON public.action USING btree (card_id);


--
-- Name: action_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_user_id_index ON public.action USING btree (user_id);


--
-- Name: attachment_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachment_card_id_index ON public.attachment USING btree (card_id);


--
-- Name: attachment_creator_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachment_creator_user_id_index ON public.attachment USING btree (creator_user_id);


--
-- Name: background_image_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX background_image_project_id_index ON public.background_image USING btree (project_id);


--
-- Name: base_custom_field_group_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX base_custom_field_group_project_id_index ON public.base_custom_field_group USING btree (project_id);


--
-- Name: board_membership_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_membership_project_id_index ON public.board_membership USING btree (project_id);


--
-- Name: board_membership_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_membership_user_id_index ON public.board_membership USING btree (user_id);


--
-- Name: board_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_position_index ON public.board USING btree ("position");


--
-- Name: board_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_project_id_index ON public.board USING btree (project_id);


--
-- Name: board_subscription_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_subscription_user_id_index ON public.board_subscription USING btree (user_id);


--
-- Name: card_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_board_id_index ON public.card USING btree (board_id);


--
-- Name: card_creator_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_creator_user_id_index ON public.card USING btree (creator_user_id);


--
-- Name: card_description_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_description_index ON public.card USING gin (description public.gin_trgm_ops);


--
-- Name: card_label_label_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_label_label_id_index ON public.card_label USING btree (label_id);


--
-- Name: card_list_changed_at_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_list_changed_at_index ON public.card USING btree (list_changed_at);


--
-- Name: card_list_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_list_id_index ON public.card USING btree (list_id);


--
-- Name: card_membership_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_membership_user_id_index ON public.card_membership USING btree (user_id);


--
-- Name: card_name_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_name_index ON public.card USING gin (name public.gin_trgm_ops);


--
-- Name: card_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_position_index ON public.card USING btree ("position");


--
-- Name: card_subscription_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_subscription_user_id_index ON public.card_subscription USING btree (user_id);


--
-- Name: comment_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX comment_card_id_index ON public.comment USING btree (card_id);


--
-- Name: comment_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX comment_user_id_index ON public.comment USING btree (user_id);


--
-- Name: custom_field_base_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_base_custom_field_group_id_index ON public.custom_field USING btree (base_custom_field_group_id);


--
-- Name: custom_field_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_custom_field_group_id_index ON public.custom_field USING btree (custom_field_group_id);


--
-- Name: custom_field_group_base_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_base_custom_field_group_id_index ON public.custom_field_group USING btree (base_custom_field_group_id);


--
-- Name: custom_field_group_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_board_id_index ON public.custom_field_group USING btree (board_id);


--
-- Name: custom_field_group_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_card_id_index ON public.custom_field_group USING btree (card_id);


--
-- Name: custom_field_group_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_position_index ON public.custom_field_group USING btree ("position");


--
-- Name: custom_field_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_position_index ON public.custom_field USING btree ("position");


--
-- Name: custom_field_value_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_value_custom_field_group_id_index ON public.custom_field_value USING btree (custom_field_group_id);


--
-- Name: custom_field_value_custom_field_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_value_custom_field_id_index ON public.custom_field_value USING btree (custom_field_id);


--
-- Name: file_reference_total_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX file_reference_total_index ON public.file_reference USING btree (total);


--
-- Name: identity_provider_user_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX identity_provider_user_user_id_index ON public.identity_provider_user USING btree (user_id);


--
-- Name: label_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX label_board_id_index ON public.label USING btree (board_id);


--
-- Name: label_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX label_position_index ON public.label USING btree ("position");


--
-- Name: list_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_board_id_index ON public.list USING btree (board_id);


--
-- Name: list_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_position_index ON public.list USING btree ("position");


--
-- Name: list_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_type_index ON public.list USING btree (type);


--
-- Name: notification_action_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_action_id_index ON public.notification USING btree (action_id);


--
-- Name: notification_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_card_id_index ON public.notification USING btree (card_id);


--
-- Name: notification_comment_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_comment_id_index ON public.notification USING btree (comment_id);


--
-- Name: notification_creator_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_creator_user_id_index ON public.notification USING btree (creator_user_id);


--
-- Name: notification_is_read_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_is_read_index ON public.notification USING btree (is_read);


--
-- Name: notification_service_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_service_board_id_index ON public.notification_service USING btree (board_id);


--
-- Name: notification_service_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_service_user_id_index ON public.notification_service USING btree (user_id);


--
-- Name: notification_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_user_id_index ON public.notification USING btree (user_id);


--
-- Name: project_favorite_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_favorite_user_id_index ON public.project_favorite USING btree (user_id);


--
-- Name: project_manager_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_manager_user_id_index ON public.project_manager USING btree (user_id);


--
-- Name: project_owner_project_manager_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_owner_project_manager_id_index ON public.project USING btree (owner_project_manager_id);


--
-- Name: session_remote_address_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX session_remote_address_index ON public.session USING btree (remote_address);


--
-- Name: session_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX session_user_id_index ON public.session USING btree (user_id);


--
-- Name: task_assignee_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_assignee_user_id_index ON public.task USING btree (assignee_user_id);


--
-- Name: task_list_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_list_card_id_index ON public.task_list USING btree (card_id);


--
-- Name: task_list_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_list_position_index ON public.task_list USING btree ("position");


--
-- Name: task_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_position_index ON public.task USING btree ("position");


--
-- Name: task_task_list_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_task_list_id_index ON public.task USING btree (task_list_id);


--
-- Name: user_account_is_deactivated_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_account_is_deactivated_index ON public.user_account USING btree (is_deactivated);


--
-- Name: user_account_role_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_account_role_index ON public.user_account USING btree (role);


--
-- Name: user_account_username_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_account_username_index ON public.user_account USING btree (username);


--
-- PostgreSQL database dump complete
--

\unrestrict IBh6NlAyH8shliulMQJ498oEdgPCCqQC0seIH3xveMcTpgdDrYE7F0IbEbME34d

--
-- Database "postgres" dump
--

--
-- PostgreSQL database dump
--

\restrict QzlNVHFZYH75Ok91vALsQLaH1gQRo9YmjniwozqswagnewabiyyJQOTalPwNCQx

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\unrestrict QzlNVHFZYH75Ok91vALsQLaH1gQRo9YmjniwozqswagnewabiyyJQOTalPwNCQx
\connect postgres
\restrict QzlNVHFZYH75Ok91vALsQLaH1gQRo9YmjniwozqswagnewabiyyJQOTalPwNCQx

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- PostgreSQL database dump complete
--

\unrestrict QzlNVHFZYH75Ok91vALsQLaH1gQRo9YmjniwozqswagnewabiyyJQOTalPwNCQx

--
-- PostgreSQL database cluster dump complete
--

