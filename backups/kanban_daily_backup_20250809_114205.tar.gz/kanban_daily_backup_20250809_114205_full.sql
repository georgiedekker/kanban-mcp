--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--

DROP DATABASE planka;




--
-- Drop roles
--

DROP ROLE postgres;


--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:RXXbR5Ez0xCVEUmXHIR9qA==$3o0TSW6x5rqx3qdlLk32OfFNrZRZVB8/K7bWHnwLmkQ=:xIdiISN265+TTY4Pv++lFB8dX/RomJ7hp+cbJs6PIT8=';

--
-- User Configurations
--








--
-- Databases
--

--
-- Database "template1" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

UPDATE pg_catalog.pg_database SET datistemplate = false WHERE datname = 'template1';
DROP DATABASE template1;
--
-- Name: template1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE template1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE template1 OWNER TO postgres;

\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE template1 IS 'default template for new databases';


--
-- Name: template1; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE template1 IS_TEMPLATE = true;


\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: ACL; Schema: -; Owner: postgres
--

REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- Database "planka" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: planka; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE planka WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE planka OWNER TO postgres;

\connect planka

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: next_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.next_id(OUT id bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
      DECLARE
        shard INT := 1;
        epoch BIGINT := 1567191600000;
        sequence BIGINT;
        milliseconds BIGINT;
      BEGIN
        SELECT nextval('next_id_seq') % 1024 INTO sequence;
        SELECT FLOOR(EXTRACT(EPOCH FROM clock_timestamp()) * 1000) INTO milliseconds;
        id := (milliseconds - epoch) << 23;
        id := id | (shard << 10);
        id := id | (sequence);
      END;
    $$;


ALTER FUNCTION public.next_id(OUT id bigint) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.action (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint,
    type text NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    board_id bigint
);


ALTER TABLE public.action OWNER TO postgres;

--
-- Name: attachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attachment (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    creator_user_id bigint,
    type text NOT NULL,
    data jsonb NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.attachment OWNER TO postgres;

--
-- Name: background_image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.background_image (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    dirname text NOT NULL,
    extension text NOT NULL,
    size_in_bytes bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.background_image OWNER TO postgres;

--
-- Name: base_custom_field_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.base_custom_field_group (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.base_custom_field_group OWNER TO postgres;

--
-- Name: board; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text NOT NULL,
    default_view text NOT NULL,
    default_card_type text NOT NULL,
    limit_card_types_to_default_one boolean NOT NULL,
    always_display_card_creator boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.board OWNER TO postgres;

--
-- Name: board_membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board_membership (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    board_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role text NOT NULL,
    can_comment boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.board_membership OWNER TO postgres;

--
-- Name: board_subscription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board_subscription (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.board_subscription OWNER TO postgres;

--
-- Name: card; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    list_id bigint NOT NULL,
    creator_user_id bigint,
    prev_list_id bigint,
    cover_attachment_id bigint,
    type text NOT NULL,
    "position" double precision,
    name text NOT NULL,
    description text,
    due_date timestamp without time zone,
    stopwatch jsonb,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    list_changed_at timestamp without time zone,
    comments_total integer NOT NULL
);


ALTER TABLE public.card OWNER TO postgres;

--
-- Name: card_label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_label (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    label_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_label OWNER TO postgres;

--
-- Name: card_membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_membership (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_membership OWNER TO postgres;

--
-- Name: card_subscription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_subscription (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint NOT NULL,
    is_permanent boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_subscription OWNER TO postgres;

--
-- Name: comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comment (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint,
    text text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.comment OWNER TO postgres;

--
-- Name: custom_field; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_field (
    id bigint DEFAULT public.next_id() NOT NULL,
    base_custom_field_group_id bigint,
    custom_field_group_id bigint,
    "position" double precision NOT NULL,
    name text NOT NULL,
    show_on_front_of_card boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.custom_field OWNER TO postgres;

--
-- Name: custom_field_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_field_group (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint,
    card_id bigint,
    base_custom_field_group_id bigint,
    "position" double precision NOT NULL,
    name text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.custom_field_group OWNER TO postgres;

--
-- Name: custom_field_value; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_field_value (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    custom_field_group_id bigint NOT NULL,
    custom_field_id bigint NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.custom_field_value OWNER TO postgres;

--
-- Name: file_reference; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file_reference (
    id bigint DEFAULT public.next_id() NOT NULL,
    total integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.file_reference OWNER TO postgres;

--
-- Name: identity_provider_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.identity_provider_user (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    issuer text NOT NULL,
    sub text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.identity_provider_user OWNER TO postgres;

--
-- Name: label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.label (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text,
    color text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.label OWNER TO postgres;

--
-- Name: list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.list (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    type text NOT NULL,
    "position" double precision,
    name text,
    color text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.list OWNER TO postgres;

--
-- Name: migration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migration (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


ALTER TABLE public.migration OWNER TO postgres;

--
-- Name: migration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_id_seq OWNER TO postgres;

--
-- Name: migration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migration_id_seq OWNED BY public.migration.id;


--
-- Name: migration_lock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migration_lock (
    index integer NOT NULL,
    is_locked integer
);


ALTER TABLE public.migration_lock OWNER TO postgres;

--
-- Name: migration_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migration_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_lock_index_seq OWNER TO postgres;

--
-- Name: migration_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migration_lock_index_seq OWNED BY public.migration_lock.index;


--
-- Name: next_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.next_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.next_id_seq OWNER TO postgres;

--
-- Name: notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    creator_user_id bigint,
    board_id bigint NOT NULL,
    card_id bigint NOT NULL,
    comment_id bigint,
    action_id bigint,
    type text NOT NULL,
    data jsonb NOT NULL,
    is_read boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.notification OWNER TO postgres;

--
-- Name: notification_service; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_service (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint,
    board_id bigint,
    url text NOT NULL,
    format text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.notification_service OWNER TO postgres;

--
-- Name: project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project (
    id bigint DEFAULT public.next_id() NOT NULL,
    owner_project_manager_id bigint,
    background_image_id bigint,
    name text NOT NULL,
    description text,
    background_type text,
    background_gradient text,
    is_hidden boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.project OWNER TO postgres;

--
-- Name: project_favorite; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_favorite (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.project_favorite OWNER TO postgres;

--
-- Name: project_manager; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_manager (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.project_manager OWNER TO postgres;

--
-- Name: session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    access_token text NOT NULL,
    http_only_token text,
    remote_address text NOT NULL,
    user_agent text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.session OWNER TO postgres;

--
-- Name: task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task (
    id bigint DEFAULT public.next_id() NOT NULL,
    task_list_id bigint NOT NULL,
    assignee_user_id bigint,
    "position" double precision NOT NULL,
    name text NOT NULL,
    is_completed boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.task OWNER TO postgres;

--
-- Name: task_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_list (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text NOT NULL,
    show_on_front_of_card boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.task_list OWNER TO postgres;

--
-- Name: user_account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_account (
    id bigint DEFAULT public.next_id() NOT NULL,
    email text NOT NULL,
    password text,
    role text NOT NULL,
    name text NOT NULL,
    username text,
    avatar jsonb,
    phone text,
    organization text,
    language text,
    subscribe_to_own_cards boolean NOT NULL,
    subscribe_to_card_when_commenting boolean NOT NULL,
    turn_off_recent_card_highlighting boolean NOT NULL,
    enable_favorites_by_default boolean NOT NULL,
    default_editor_mode text NOT NULL,
    default_home_view text NOT NULL,
    default_projects_order text NOT NULL,
    is_sso_user boolean NOT NULL,
    is_deactivated boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    password_changed_at timestamp without time zone
);


ALTER TABLE public.user_account OWNER TO postgres;

--
-- Name: migration id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration ALTER COLUMN id SET DEFAULT nextval('public.migration_id_seq'::regclass);


--
-- Name: migration_lock index; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration_lock ALTER COLUMN index SET DEFAULT nextval('public.migration_lock_index_seq'::regclass);


--
-- Data for Name: action; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.action (id, card_id, user_id, type, data, created_at, updated_at, board_id) FROM stdin;
1566011327149769792	1566011327091049535	1560278692305830913	createCard	{"card": {"name": "test"}, "list": {"id": "1566004621732742167", "name": "TODO", "type": "active"}}	2025-07-30 11:24:57.736	\N	1541385320996537361
1566031207873905757	1566011327091049535	1560328737491256322	moveCard	{"card": {"name": "test"}, "toList": {"id": "1566004621741130776", "name": "READY", "type": "active"}, "fromList": {"id": "1566004621732742167", "name": "TODO", "type": "active"}}	2025-07-30 12:04:27.702	\N	1541385320996537361
1566031272583627871	1566011327091049535	1560328737491256322	moveCard	{"card": {"name": "test"}, "toList": {"id": "1566004621732742167", "name": "TODO", "type": "active"}, "fromList": {"id": "1566004621741130776", "name": "READY", "type": "active"}}	2025-07-30 12:04:35.417	\N	1541385320996537361
1566031331001893985	1566011327091049535	1560328737491256322	moveCard	{"card": {"name": "test"}, "toList": {"id": "1566004621741130776", "name": "READY", "type": "active"}, "fromList": {"id": "1566004621732742167", "name": "TODO", "type": "active"}}	2025-07-30 12:04:42.38	\N	1541385320996537361
1566031382063350883	1566011327091049535	1560328737491256322	moveCard	{"card": {"name": "test"}, "toList": {"id": "1566004621732742167", "name": "TODO", "type": "active"}, "fromList": {"id": "1566004621741130776", "name": "READY", "type": "active"}}	2025-07-30 12:04:48.468	\N	1541385320996537361
1566034264774935664	1566034264749769839	1560328737491256322	createCard	{"card": {"name": "test"}, "list": {"id": "1566000088495424528", "name": "TODO", "type": "active"}}	2025-07-30 12:10:32.115	\N	1565999911277691916
\.


--
-- Data for Name: attachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attachment (id, card_id, creator_user_id, type, data, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: background_image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.background_image (id, project_id, dirname, extension, size_in_bytes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: base_custom_field_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.base_custom_field_group (id, project_id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: board; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board (id, project_id, "position", name, default_view, default_card_type, limit_card_types_to_default_one, always_display_card_creator, created_at, updated_at) FROM stdin;
1565999911277691916	1565999851240424458	65536	execution	kanban	project	f	f	2025-07-30 11:02:16.858	2025-07-30 11:02:18.785
1541385320996537361	1541383442627822607	1	execution	kanban	project	f	f	2025-07-30 10:51:08.31029	2025-07-30 11:39:19.68077
1541386488111957023	1541383442627822607	2	kanban	kanban	project	f	f	2025-07-30 10:51:08.31029	2025-07-30 11:39:19.68077
1541386853553275948	1541383442627822607	3	meta	kanban	project	f	f	2025-07-30 10:51:08.31029	2025-07-30 11:39:19.68077
1566019210167977027	1565999851240424458	131072	kanban	kanban	project	f	f	2025-07-30 11:40:37.465987	2025-07-30 11:40:37.465987
1566019210167977028	1565999851240424458	196608	meta	kanban	project	f	f	2025-07-30 11:40:37.465987	2025-07-30 11:40:37.465987
1572130827708400773	1572130827590960259	16384	Execution Board	kanban	project	f	f	2025-08-07 22:03:19.051	\N
1572130827834229897	1572130827590960259	1	Kanban Board	kanban	project	f	f	2025-08-07 22:03:19.066	\N
1572130827934893197	1572130827590960259	2	Meta Board	kanban	project	f	f	2025-08-07 22:03:19.079	\N
1572131156130792596	1572131156055295122	16384	Execution Board	kanban	project	f	f	2025-08-07 22:03:58.203	\N
1572131156214678680	1572131156055295122	1	Kanban Board	kanban	project	f	f	2025-08-07 22:03:58.213	\N
1572131156315341980	1572131156055295122	2	Meta Board	kanban	project	f	f	2025-08-07 22:03:58.225	\N
1572131313685628067	1572131313543021729	16384	Execution Board	kanban	project	f	f	2025-08-07 22:04:16.985	\N
1572131313786291367	1572131313543021729	1	Kanban Board	kanban	project	f	f	2025-08-07 22:04:16.996	\N
1572131313987617963	1572131313543021729	2	Meta Board	kanban	project	f	f	2025-08-07 22:04:17.021	\N
1572131367565657266	1572131367481771184	16384	Execution Board	kanban	project	f	f	2025-08-07 22:04:23.408	\N
1572131367666320566	1572131367481771184	1	Kanban Board	kanban	project	f	f	2025-08-07 22:04:23.42	\N
1572131367758595258	1572131367481771184	2	Meta Board	kanban	project	f	f	2025-08-07 22:04:23.431	\N
1572131516127904961	1572131516052407487	16384	Execution Board	kanban	project	f	f	2025-08-07 22:04:41.117	\N
1572131516203402437	1572131516052407487	1	Kanban Board	kanban	project	f	f	2025-08-07 22:04:41.127	\N
1572131516287288521	1572131516052407487	2	Meta Board	kanban	project	f	f	2025-08-07 22:04:41.136	\N
1572132140055790818	1572132139971904736	16384	Execution Board	kanban	project	f	f	2025-08-07 22:05:55.495	\N
1572132140131288294	1572132139971904736	1	Kanban Board	kanban	project	f	f	2025-08-07 22:05:55.505	\N
1572132140223562986	1572132139971904736	2	Meta Board	kanban	project	f	f	2025-08-07 22:05:55.515	\N
1572133169111500037	1572133169052779779	16384	Execution Board	kanban	project	f	f	2025-08-07 22:07:58.168	\N
1572133169178608905	1572133169052779779	1	Kanban Board	kanban	project	f	f	2025-08-07 22:07:58.177	\N
1572133169237329165	1572133169052779779	2	Meta Board	kanban	project	f	f	2025-08-07 22:07:58.184	\N
1572140517339170088	1572140517255284006	16384	Execution Board	kanban	project	f	f	2025-08-07 22:22:34.146	\N
1572140517498553644	1572140517255284006	1	Kanban Board	kanban	project	f	f	2025-08-07 22:22:34.165	\N
1572140517582439728	1572140517255284006	2	Meta Board	kanban	project	f	f	2025-08-07 22:22:34.175	\N
1573191158689957215	1573191157196784989	1	Execution	kanban	project	f	f	2025-08-09 09:10:00.354	\N
1573191162078954860	1573191157196784989	16385	Kanban	kanban	project	f	f	2025-08-09 09:10:00.758	\N
1573191162976535929	1573191157196784989	8193	Meta	kanban	project	f	f	2025-08-09 09:10:00.863	\N
1573191243674944904	1573191243087742342	1	Execution	kanban	project	f	f	2025-08-09 09:10:10.486	\N
1573191244379587989	1573191243087742342	16385	Kanban	kanban	project	f	f	2025-08-09 09:10:10.569	\N
1573191245428164002	1573191243087742342	8193	Meta	kanban	project	f	f	2025-08-09 09:10:10.694	\N
1573192322609317297	1573192321996948911	1	Execution	kanban	project	f	f	2025-08-09 09:12:19.105	\N
1573192323683059134	1573192321996948911	16385	Kanban	kanban	project	f	f	2025-08-09 09:12:19.233	\N
1573192324756800971	1573192321996948911	8193	Meta	kanban	project	f	f	2025-08-09 09:12:19.36	\N
1573193618523424218	1573193617936221656	1	Execution	kanban	project	f	f	2025-08-09 09:14:53.589	\N
1573193619236455911	1573193617936221656	16385	Kanban	kanban	project	f	f	2025-08-09 09:14:53.675	\N
1573193619974653428	1573193617936221656	8193	Meta	kanban	project	f	f	2025-08-09 09:14:53.762	\N
1573193972312966659	1573193971809650177	1	Execution	kanban	project	f	f	2025-08-09 09:15:35.764	\N
1573193973009221136	1573193971809650177	16385	Kanban	kanban	project	f	f	2025-08-09 09:15:35.848	\N
1573193973999076893	1573193971809650177	8193	Meta	kanban	project	f	f	2025-08-09 09:15:35.966	\N
1573194907919582765	1573194907097499179	1	Execution	kanban	project	f	f	2025-08-09 09:17:27.297	\N
1573194908641003066	1573194907097499179	16385	Kanban	kanban	project	f	f	2025-08-09 09:17:27.384	\N
1573194909303703111	1573194907097499179	8193	Meta	kanban	project	f	f	2025-08-09 09:17:27.463	\N
1573196042780804694	1573196042059384404	1	Execution	kanban	project	f	f	2025-08-09 09:19:42.583	\N
1573196043686774371	1573196042059384404	16385	Kanban	kanban	project	f	f	2025-08-09 09:19:42.691	\N
1573196044307531376	1573196042059384404	8193	Meta	kanban	project	f	f	2025-08-09 09:19:42.766	\N
1573196403423839871	1573196403004409469	1	Execution	kanban	project	f	f	2025-08-09 09:20:25.574	\N
1573196404128482956	1573196403004409469	16385	Kanban	kanban	project	f	f	2025-08-09 09:20:25.66	\N
1573196405042841241	1573196403004409469	8193	Meta	kanban	project	f	f	2025-08-09 09:20:25.769	\N
1573197655188702888	1573197654752495270	1	Execution	kanban	project	f	f	2025-08-09 09:22:54.797	\N
1573197655859791541	1573197654752495270	16385	Kanban	kanban	project	f	f	2025-08-09 09:22:54.878	\N
1573197656472159938	1573197654752495270	8193	Meta	kanban	project	f	f	2025-08-09 09:22:54.951	\N
1573200268852463313	1573200268282037967	1	Execution	kanban	project	f	f	2025-08-09 09:28:06.37	\N
1573200269775210206	1573200268282037967	16385	Kanban	kanban	project	f	f	2025-08-09 09:28:06.481	\N
1573200270446298859	1573200268282037967	8193	Meta	kanban	project	f	f	2025-08-09 09:28:06.561	\N
1573201068874008314	1573201067548608248	1	EXECUTION	kanban	project	f	f	2025-08-09 09:29:41.74	\N
1573201069712869127	1573201067548608248	16385	KANBAN	kanban	project	f	f	2025-08-09 09:29:41.841	\N
1573201070316848916	1573201067548608248	8193	META	kanban	project	f	f	2025-08-09 09:29:41.912	\N
\.


--
-- Data for Name: board_membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board_membership (id, project_id, board_id, user_id, role, can_comment, created_at, updated_at) FROM stdin;
1565999911302857741	1565999851240424458	1565999911277691916	1560278692305830913	editor	\N	2025-07-30 11:02:16.862	\N
1566008985369183280	1541383442627822607	1541385320996537361	1560328737491256322	editor	t	2025-07-30 11:20:18.574444	2025-07-30 11:20:18.574444
1566008985369183281	1541383442627822607	1541385320996537361	1560328737491256323	editor	t	2025-07-30 11:20:18.574444	2025-07-30 11:20:18.574444
1566008985369183282	1541383442627822607	1541385320996537361	1560328737491256324	editor	t	2025-07-30 11:20:18.574444	2025-07-30 11:20:18.574444
1566008985369183283	1541383442627822607	1541385320996537361	1560328737491256325	editor	t	2025-07-30 11:20:18.574444	2025-07-30 11:20:18.574444
1566008985369183284	1541383442627822607	1541386488111957023	1560328737491256322	editor	t	2025-07-30 11:20:18.574444	2025-07-30 11:20:18.574444
1566008985369183285	1541383442627822607	1541386488111957023	1560328737491256323	editor	t	2025-07-30 11:20:18.574444	2025-07-30 11:20:18.574444
1566008985369183286	1541383442627822607	1541386488111957023	1560328737491256324	editor	t	2025-07-30 11:20:18.574444	2025-07-30 11:20:18.574444
1566008985369183287	1541383442627822607	1541386488111957023	1560328737491256325	editor	t	2025-07-30 11:20:18.574444	2025-07-30 11:20:18.574444
1566008985369183288	1541383442627822607	1541386853553275948	1560328737491256322	editor	t	2025-07-30 11:20:18.574444	2025-07-30 11:20:18.574444
1566008985369183289	1541383442627822607	1541386853553275948	1560328737491256323	editor	t	2025-07-30 11:20:18.574444	2025-07-30 11:20:18.574444
1566008985369183290	1541383442627822607	1541386853553275948	1560328737491256324	editor	t	2025-07-30 11:20:18.574444	2025-07-30 11:20:18.574444
1566008985369183291	1541383442627822607	1541386853553275948	1560328737491256325	editor	t	2025-07-30 11:20:18.574444	2025-07-30 11:20:18.574444
1566011293360456766	1541383442627822607	1541385320996537361	1560278692305830913	editor	\N	2025-07-30 11:24:53.708	\N
1566019392897025109	1565999851240424458	1566019210167977027	1560278692305830913	editor	\N	2025-07-30 11:40:59.248542	2025-07-30 11:40:59.248542
1566019392897025110	1565999851240424458	1566019210167977028	1560278692305830913	editor	\N	2025-07-30 11:40:59.248542	2025-07-30 11:40:59.248542
1566033853867361385	1565999851240424458	1566019210167977028	1560328737491256324	editor	\N	2025-07-30 12:09:43.131	\N
1566033893511922794	1565999851240424458	1566019210167977028	1560328737491256322	editor	\N	2025-07-30 12:09:47.857	\N
1566033931873027179	1565999851240424458	1566019210167977027	1560328737491256324	editor	\N	2025-07-30 12:09:52.43	\N
1566033955688285292	1565999851240424458	1566019210167977027	1560328737491256322	editor	\N	2025-07-30 12:09:55.269	\N
1566033989444043885	1565999851240424458	1565999911277691916	1560328737491256322	editor	\N	2025-07-30 12:09:59.292	\N
1566034012948923502	1565999851240424458	1565999911277691916	1560328737491256323	editor	\N	2025-07-30 12:10:02.095	\N
1572130827708400774	1572130827590960259	1572130827708400773	1560328737491256322	editor	\N	2025-08-07 22:03:19.052	\N
1572130827834229898	1572130827590960259	1572130827834229897	1560328737491256322	editor	\N	2025-08-07 22:03:19.067	\N
1572130827943281806	1572130827590960259	1572130827934893197	1560328737491256322	editor	\N	2025-08-07 22:03:19.08	\N
1572131156139181205	1572131156055295122	1572131156130792596	1560328737491256322	editor	\N	2025-08-07 22:03:58.204	\N
1572131156223067289	1572131156055295122	1572131156214678680	1560328737491256322	editor	\N	2025-08-07 22:03:58.214	\N
1572131156315341981	1572131156055295122	1572131156315341980	1560328737491256322	editor	\N	2025-08-07 22:03:58.225	\N
1572131313694016676	1572131313543021729	1572131313685628067	1560328737491256322	editor	\N	2025-08-07 22:04:16.986	\N
1572131313811457192	1572131313543021729	1572131313786291367	1560328737491256322	editor	\N	2025-08-07 22:04:17	\N
1572131313987617964	1572131313543021729	1572131313987617963	1560328737491256322	editor	\N	2025-08-07 22:04:17.021	\N
1572131367574045875	1572131367481771184	1572131367565657266	1560328737491256322	editor	\N	2025-08-07 22:04:23.408	\N
1572131367674709175	1572131367481771184	1572131367666320566	1560328737491256322	editor	\N	2025-08-07 22:04:23.42	\N
1572131367766983867	1572131367481771184	1572131367758595258	1560328737491256322	editor	\N	2025-08-07 22:04:23.432	\N
1572131516127904962	1572131516052407487	1572131516127904961	1560328737491256322	editor	\N	2025-08-07 22:04:41.118	\N
1572131516211791046	1572131516052407487	1572131516203402437	1560328737491256322	editor	\N	2025-08-07 22:04:41.128	\N
1572131516287288522	1572131516052407487	1572131516287288521	1560328737491256322	editor	\N	2025-08-07 22:04:41.137	\N
1572132140055790819	1572132139971904736	1572132140055790818	1560328737491256322	editor	\N	2025-08-07 22:05:55.496	\N
1572132140139676903	1572132139971904736	1572132140131288294	1560328737491256322	editor	\N	2025-08-07 22:05:55.505	\N
1572132140231951595	1572132139971904736	1572132140223562986	1560328737491256322	editor	\N	2025-08-07 22:05:55.517	\N
1572133169119888646	1572133169052779779	1572133169111500037	1560328737491256322	editor	\N	2025-08-07 22:07:58.169	\N
1572133169186997514	1572133169052779779	1572133169178608905	1560328737491256322	editor	\N	2025-08-07 22:07:58.178	\N
1572133169237329166	1572133169052779779	1572133169237329165	1560328737491256322	editor	\N	2025-08-07 22:07:58.184	\N
1572139863807886628	1572133169052779779	1572133169178608905	1560328737491256323	editor	\N	2025-08-07 22:21:16.237	\N
1572140517347558697	1572140517255284006	1572140517339170088	1560328737491256322	editor	\N	2025-08-07 22:22:34.147	\N
1572140517506942253	1572140517255284006	1572140517498553644	1560328737491256322	editor	\N	2025-08-07 22:22:34.166	\N
1572140517582439729	1572140517255284006	1572140517582439728	1560328737491256322	editor	\N	2025-08-07 22:22:34.175	\N
1572140518933005638	1572140517255284006	1572140517339170088	1560328737491256323	editor	\N	2025-08-07 22:22:34.336	\N
1572140518983337287	1572140517255284006	1572140517339170088	1560328737491256324	viewer	f	2025-08-07 22:22:34.342	\N
1572140519033668936	1572140517255284006	1572140517339170088	1560328737491256325	viewer	f	2025-08-07 22:22:34.348	\N
1572140519075611977	1572140517255284006	1572140517498553644	1560328737491256324	editor	\N	2025-08-07 22:22:34.353	\N
1572140519142720842	1572140517255284006	1572140517498553644	1560328737491256323	viewer	f	2025-08-07 22:22:34.36	\N
1572140519184663883	1572140517255284006	1572140517498553644	1560328737491256325	viewer	f	2025-08-07 22:22:34.366	\N
1572140519234995532	1572140517255284006	1572140517582439728	1560328737491256325	editor	\N	2025-08-07 22:22:34.371	\N
1572140519285327181	1572140517255284006	1572140517582439728	1560328737491256323	viewer	f	2025-08-07 22:22:34.377	\N
1572140519352436046	1572140517255284006	1572140517582439728	1560328737491256324	viewer	f	2025-08-07 22:22:34.385	\N
1572141597968041296	1572133169052779779	1572133169111500037	1560328737491256323	editor	\N	2025-08-07 22:24:42.967	\N
1572141598035150161	1572133169052779779	1572133169111500037	1560328737491256324	viewer	f	2025-08-07 22:24:42.975	\N
1572141598085481810	1572133169052779779	1572133169111500037	1560328737491256325	viewer	f	2025-08-07 22:24:42.981	\N
1572141598135813459	1572133169052779779	1572133169178608905	1560328737491256324	editor	\N	2025-08-07 22:24:42.986	\N
1572141598236476757	1572133169052779779	1572133169178608905	1560328737491256325	viewer	f	2025-08-07 22:24:42.999	\N
1572141598286808406	1572133169052779779	1572133169237329165	1560328737491256325	editor	\N	2025-08-07 22:24:43.005	\N
1572141598337140055	1572133169052779779	1572133169237329165	1560328737491256323	viewer	f	2025-08-07 22:24:43.011	\N
1572141598387471704	1572133169052779779	1572133169237329165	1560328737491256324	viewer	f	2025-08-07 22:24:43.017	\N
1573191158715123040	1573191157196784989	1573191158689957215	1560328737491256322	editor	\N	2025-08-09 09:10:00.358	\N
1573191161676301673	1573191157196784989	1573191158689957215	1560328737491256323	editor	\N	2025-08-09 09:10:00.71	\N
1573191161793742186	1573191157196784989	1573191158689957215	1560328737491256324	viewer	t	2025-08-09 09:10:00.724	\N
1573191161869239659	1573191157196784989	1573191158689957215	1560328737491256325	viewer	t	2025-08-09 09:10:00.733	\N
1573191162087343469	1573191157196784989	1573191162078954860	1560328737491256322	editor	\N	2025-08-09 09:10:00.759	\N
1573191162657768822	1573191157196784989	1573191162078954860	1560328737491256324	editor	\N	2025-08-09 09:10:00.827	\N
1573191162775209335	1573191157196784989	1573191162078954860	1560328737491256323	viewer	t	2025-08-09 09:10:00.842	\N
1573191162833929592	1573191157196784989	1573191162078954860	1560328737491256325	viewer	t	2025-08-09 09:10:00.849	\N
1573191162984924538	1573191157196784989	1573191162976535929	1560328737491256322	editor	\N	2025-08-09 09:10:00.867	\N
1573191163597292931	1573191157196784989	1573191162976535929	1560328737491256325	editor	\N	2025-08-09 09:10:00.94	\N
1573191163689567620	1573191157196784989	1573191162976535929	1560328737491256323	viewer	t	2025-08-09 09:10:00.95	\N
1573191163748287877	1573191157196784989	1573191162976535929	1560328737491256324	viewer	t	2025-08-09 09:10:00.957	\N
1573191243683333513	1573191243087742342	1573191243674944904	1560328737491256322	editor	\N	2025-08-09 09:10:10.487	\N
1573191244153095570	1573191243087742342	1573191243674944904	1560328737491256323	editor	\N	2025-08-09 09:10:10.543	\N
1573191244236981651	1573191243087742342	1573191243674944904	1560328737491256324	viewer	t	2025-08-09 09:10:10.553	\N
1573191244287313300	1573191243087742342	1573191243674944904	1560328737491256325	viewer	t	2025-08-09 09:10:10.559	\N
1573191244379587990	1573191243087742342	1573191244379587989	1560328737491256322	editor	\N	2025-08-09 09:10:10.57	\N
1573191245126174111	1573191243087742342	1573191244379587989	1560328737491256324	editor	\N	2025-08-09 09:10:10.657	\N
1573191245260391840	1573191243087742342	1573191244379587989	1560328737491256323	viewer	t	2025-08-09 09:10:10.675	\N
1573191245310723489	1573191243087742342	1573191244379587989	1560328737491256325	viewer	t	2025-08-09 09:10:10.68	\N
1573191245428164003	1573191243087742342	1573191245428164002	1560328737491256322	editor	\N	2025-08-09 09:10:10.695	\N
1573191245822428588	1573191243087742342	1573191245428164002	1560328737491256325	editor	\N	2025-08-09 09:10:10.741	\N
1573191245889537453	1573191243087742342	1573191245428164002	1560328737491256323	viewer	t	2025-08-09 09:10:10.749	\N
1573191245948257710	1573191243087742342	1573191245428164002	1560328737491256324	viewer	t	2025-08-09 09:10:10.757	\N
1573192322626094514	1573192321996948911	1573192322609317297	1560328737491256322	editor	\N	2025-08-09 09:12:19.106	\N
1573192323347514811	1573192321996948911	1573192322609317297	1560328737491256323	editor	\N	2025-08-09 09:12:19.192	\N
1573192323431400892	1573192321996948911	1573192322609317297	1560328737491256324	viewer	t	2025-08-09 09:12:19.202	\N
1573192323582395837	1573192321996948911	1573192322609317297	1560328737491256325	viewer	t	2025-08-09 09:12:19.221	\N
1573192323691447743	1573192321996948911	1573192323683059134	1560328737491256322	editor	\N	2025-08-09 09:12:19.233	\N
1573192324563862984	1573192321996948911	1573192323683059134	1560328737491256324	editor	\N	2025-08-09 09:12:19.338	\N
1573192324622583241	1573192321996948911	1573192323683059134	1560328737491256323	viewer	t	2025-08-09 09:12:19.344	\N
1573192324672914890	1573192321996948911	1573192323683059134	1560328737491256325	viewer	t	2025-08-09 09:12:19.351	\N
1573192324765189580	1573192321996948911	1573192324756800971	1560328737491256322	editor	\N	2025-08-09 09:12:19.361	\N
1573192325151065557	1573192321996948911	1573192324756800971	1560328737491256325	editor	\N	2025-08-09 09:12:19.408	\N
1573192325209785814	1573192321996948911	1573192324756800971	1560328737491256323	viewer	t	2025-08-09 09:12:19.415	\N
1573192325268506071	1573192321996948911	1573192324756800971	1560328737491256324	viewer	t	2025-08-09 09:12:19.422	\N
1573193618548590043	1573193617936221656	1573193618523424218	1560328737491256322	editor	\N	2025-08-09 09:14:53.591	\N
1573193619009963492	1573193617936221656	1573193618523424218	1560328737491256323	editor	\N	2025-08-09 09:14:53.648	\N
1573193619085460965	1573193617936221656	1573193618523424218	1560328737491256324	viewer	t	2025-08-09 09:14:53.657	\N
1573193619144181222	1573193617936221656	1573193618523424218	1560328737491256325	viewer	t	2025-08-09 09:14:53.663	\N
1573193619244844520	1573193617936221656	1573193619236455911	1560328737491256322	editor	\N	2025-08-09 09:14:53.676	\N
1573193619722995185	1573193617936221656	1573193619236455911	1560328737491256324	editor	\N	2025-08-09 09:14:53.733	\N
1573193619773326834	1573193617936221656	1573193619236455911	1560328737491256323	viewer	t	2025-08-09 09:14:53.738	\N
1573193619840435699	1573193617936221656	1573193619236455911	1560328737491256325	viewer	t	2025-08-09 09:14:53.747	\N
1573193619991430645	1573193617936221656	1573193619974653428	1560328737491256322	editor	\N	2025-08-09 09:14:53.765	\N
1573193620436026878	1573193617936221656	1573193619974653428	1560328737491256325	editor	\N	2025-08-09 09:14:53.817	\N
1573193620494747135	1573193617936221656	1573193619974653428	1560328737491256323	viewer	t	2025-08-09 09:14:53.824	\N
1573193620536690176	1573193617936221656	1573193619974653428	1560328737491256324	viewer	t	2025-08-09 09:14:53.83	\N
1573193972338132484	1573193971809650177	1573193972312966659	1560328737491256322	editor	\N	2025-08-09 09:15:35.766	\N
1573193972807894541	1573193971809650177	1573193972312966659	1560328737491256323	editor	\N	2025-08-09 09:15:35.824	\N
1573193972866614798	1573193971809650177	1573193972312966659	1560328737491256324	viewer	t	2025-08-09 09:15:35.831	\N
1573193972916946447	1573193971809650177	1573193972312966659	1560328737491256325	viewer	t	2025-08-09 09:15:35.837	\N
1573193973017609745	1573193971809650177	1573193973009221136	1560328737491256322	editor	\N	2025-08-09 09:15:35.849	\N
1573193973638366746	1573193971809650177	1573193973009221136	1560328737491256324	editor	\N	2025-08-09 09:15:35.923	\N
1573193973789361691	1573193971809650177	1573193973009221136	1560328737491256323	viewer	t	2025-08-09 09:15:35.94	\N
1573193973831304732	1573193971809650177	1573193973009221136	1560328737491256325	viewer	t	2025-08-09 09:15:35.946	\N
1573193974007465502	1573193971809650177	1573193973999076893	1560328737491256322	editor	\N	2025-08-09 09:15:35.966	\N
1573193974334621223	1573193971809650177	1573193973999076893	1560328737491256325	editor	\N	2025-08-09 09:15:36.006	\N
1573193974384952872	1573193971809650177	1573193973999076893	1560328737491256323	viewer	t	2025-08-09 09:15:36.011	\N
1573193974435284521	1573193971809650177	1573193973999076893	1560328737491256324	viewer	t	2025-08-09 09:15:36.017	\N
1573194907927971374	1573194907097499179	1573194907919582765	1560328737491256322	editor	\N	2025-08-09 09:17:27.299	\N
1573194908431287863	1573194907097499179	1573194907919582765	1560328737491256323	editor	\N	2025-08-09 09:17:27.359	\N
1573194908490008120	1573194907097499179	1573194907919582765	1560328737491256324	viewer	t	2025-08-09 09:17:27.366	\N
1573194908548728377	1573194907097499179	1573194907919582765	1560328737491256325	viewer	t	2025-08-09 09:17:27.372	\N
1573194908641003067	1573194907097499179	1573194908641003066	1560328737491256322	editor	\N	2025-08-09 09:17:27.384	\N
1573194909093987908	1573194907097499179	1573194908641003066	1560328737491256324	editor	\N	2025-08-09 09:17:27.437	\N
1573194909169485381	1573194907097499179	1573194908641003066	1560328737491256323	viewer	t	2025-08-09 09:17:27.447	\N
1573194909236594246	1573194907097499179	1573194908641003066	1560328737491256325	viewer	t	2025-08-09 09:17:27.454	\N
1573194909312091720	1573194907097499179	1573194909303703111	1560328737491256322	editor	\N	2025-08-09 09:17:27.463	\N
1573194909949625937	1573194907097499179	1573194909303703111	1560328737491256325	editor	\N	2025-08-09 09:17:27.539	\N
1573194910033512018	1573194907097499179	1573194909303703111	1560328737491256323	viewer	t	2025-08-09 09:17:27.549	\N
1573194910150952531	1573194907097499179	1573194909303703111	1560328737491256324	viewer	t	2025-08-09 09:17:27.564	\N
1573196042814359127	1573196042059384404	1573196042780804694	1560328737491256322	editor	\N	2025-08-09 09:19:42.585	\N
1573196043502224992	1573196042059384404	1573196042780804694	1560328737491256323	editor	\N	2025-08-09 09:19:42.669	\N
1573196043560945249	1573196042059384404	1573196042780804694	1560328737491256324	viewer	t	2025-08-09 09:19:42.676	\N
1573196043602888290	1573196042059384404	1573196042780804694	1560328737491256325	viewer	t	2025-08-09 09:19:42.681	\N
1573196043686774372	1573196042059384404	1573196043686774371	1560328737491256322	editor	\N	2025-08-09 09:19:42.692	\N
1573196044131370605	1573196042059384404	1573196043686774371	1560328737491256324	editor	\N	2025-08-09 09:19:42.744	\N
1573196044190090862	1573196042059384404	1573196043686774371	1560328737491256323	viewer	t	2025-08-09 09:19:42.752	\N
1573196044240422511	1573196042059384404	1573196043686774371	1560328737491256325	viewer	t	2025-08-09 09:19:42.757	\N
1573196044315919985	1573196042059384404	1573196044307531376	1560328737491256322	editor	\N	2025-08-09 09:19:42.766	\N
1573196044802459258	1573196042059384404	1573196044307531376	1560328737491256325	editor	\N	2025-08-09 09:19:42.825	\N
1573196044861179515	1573196042059384404	1573196044307531376	1560328737491256323	viewer	t	2025-08-09 09:19:42.831	\N
1573196044903122556	1573196042059384404	1573196044307531376	1560328737491256324	viewer	t	2025-08-09 09:19:42.837	\N
1573196403432228480	1573196403004409469	1573196403423839871	1560328737491256322	editor	\N	2025-08-09 09:20:25.577	\N
1573196403960710793	1573196403004409469	1573196403423839871	1560328737491256323	editor	\N	2025-08-09 09:20:25.64	\N
1573196404019431050	1573196403004409469	1573196403423839871	1560328737491256324	viewer	t	2025-08-09 09:20:25.647	\N
1573196404061374091	1573196403004409469	1573196403423839871	1560328737491256325	viewer	t	2025-08-09 09:20:25.652	\N
1573196404136871565	1573196403004409469	1573196404128482956	1560328737491256322	editor	\N	2025-08-09 09:20:25.661	\N
1573196404833126038	1573196403004409469	1573196404128482956	1560328737491256324	editor	\N	2025-08-09 09:20:25.744	\N
1573196404900234903	1573196403004409469	1573196404128482956	1560328737491256323	viewer	t	2025-08-09 09:20:25.752	\N
1573196404950566552	1573196403004409469	1573196404128482956	1560328737491256325	viewer	t	2025-08-09 09:20:25.758	\N
1573196405059618458	1573196403004409469	1573196405042841241	1560328737491256322	editor	\N	2025-08-09 09:20:25.771	\N
1573196405504214691	1573196403004409469	1573196405042841241	1560328737491256325	editor	\N	2025-08-09 09:20:25.823	\N
1573196405554546340	1573196403004409469	1573196405042841241	1560328737491256323	viewer	t	2025-08-09 09:20:25.83	\N
1573196405604877989	1573196403004409469	1573196405042841241	1560328737491256324	viewer	t	2025-08-09 09:20:25.835	\N
1573197655197091497	1573197654752495270	1573197655188702888	1560328737491256322	editor	\N	2025-08-09 09:22:54.799	\N
1573197655658464946	1573197654752495270	1573197655188702888	1560328737491256323	editor	\N	2025-08-09 09:22:54.853	\N
1573197655725573811	1573197654752495270	1573197655188702888	1560328737491256324	viewer	t	2025-08-09 09:22:54.861	\N
1573197655767516852	1573197654752495270	1573197655188702888	1560328737491256325	viewer	t	2025-08-09 09:22:54.867	\N
1573197655868180150	1573197654752495270	1573197655859791541	1560328737491256322	editor	\N	2025-08-09 09:22:54.879	\N
1573197656304387775	1573197654752495270	1573197655859791541	1560328737491256324	editor	\N	2025-08-09 09:22:54.93	\N
1573197656346330816	1573197654752495270	1573197655859791541	1560328737491256323	viewer	t	2025-08-09 09:22:54.936	\N
1573197656388273857	1573197654752495270	1573197655859791541	1560328737491256325	viewer	t	2025-08-09 09:22:54.941	\N
1573197656472159939	1573197654752495270	1573197656472159938	1560328737491256322	editor	\N	2025-08-09 09:22:54.951	\N
1573197656799315660	1573197654752495270	1573197656472159938	1560328737491256325	editor	\N	2025-08-09 09:22:54.989	\N
1573197656858035917	1573197654752495270	1573197656472159938	1560328737491256323	viewer	t	2025-08-09 09:22:54.997	\N
1573197656899978958	1573197654752495270	1573197656472159938	1560328737491256324	viewer	t	2025-08-09 09:22:55.002	\N
1573200268860851922	1573200268282037967	1573200268852463313	1560328737491256322	editor	\N	2025-08-09 09:28:06.372	\N
1573200269615826651	1573200268282037967	1573200268852463313	1560328737491256323	editor	\N	2025-08-09 09:28:06.462	\N
1573200269666158300	1573200268282037967	1573200268852463313	1560328737491256324	viewer	t	2025-08-09 09:28:06.468	\N
1573200269708101341	1573200268282037967	1573200268852463313	1560328737491256325	viewer	t	2025-08-09 09:28:06.473	\N
1573200269775210207	1573200268282037967	1573200269775210206	1560328737491256322	editor	\N	2025-08-09 09:28:06.481	\N
1573200270261749480	1573200268282037967	1573200269775210206	1560328737491256324	editor	\N	2025-08-09 09:28:06.538	\N
1573200270328858345	1573200268282037967	1573200269775210206	1560328737491256323	viewer	t	2025-08-09 09:28:06.547	\N
1573200270362412778	1573200268282037967	1573200269775210206	1560328737491256325	viewer	t	2025-08-09 09:28:06.551	\N
1573200270446298860	1573200268282037967	1573200270446298859	1560328737491256322	editor	\N	2025-08-09 09:28:06.561	\N
1573200270781843189	1573200268282037967	1573200270446298859	1560328737491256325	editor	\N	2025-08-09 09:28:06.601	\N
1573200270857340662	1573200268282037967	1573200270446298859	1560328737491256323	viewer	t	2025-08-09 09:28:06.61	\N
1573200270916060919	1573200268282037967	1573200270446298859	1560328737491256324	viewer	t	2025-08-09 09:28:06.617	\N
1573201068882396923	1573201067548608248	1573201068874008314	1560328737491256322	editor	\N	2025-08-09 09:29:41.742	\N
1573201069377324804	1573201067548608248	1573201068874008314	1560328737491256323	editor	\N	2025-08-09 09:29:41.801	\N
1573201069486376709	1573201067548608248	1573201068874008314	1560328737491256324	viewer	t	2025-08-09 09:29:41.814	\N
1573201069553485574	1573201067548608248	1573201068874008314	1560328737491256325	viewer	t	2025-08-09 09:29:41.822	\N
1573201069721257736	1573201067548608248	1573201069712869127	1560328737491256322	editor	\N	2025-08-09 09:29:41.842	\N
1573201070140688145	1573201067548608248	1573201069712869127	1560328737491256324	editor	\N	2025-08-09 09:29:41.891	\N
1573201070191019794	1573201067548608248	1573201069712869127	1560328737491256323	viewer	t	2025-08-09 09:29:41.897	\N
1573201070241351443	1573201067548608248	1573201069712869127	1560328737491256325	viewer	t	2025-08-09 09:29:41.904	\N
1573201070316848917	1573201067548608248	1573201070316848916	1560328737491256322	editor	\N	2025-08-09 09:29:41.913	\N
1573201070711113502	1573201067548608248	1573201070316848916	1560328737491256325	editor	\N	2025-08-09 09:29:41.96	\N
1573201070761445151	1573201067548608248	1573201070316848916	1560328737491256323	viewer	t	2025-08-09 09:29:41.965	\N
1573201070820165408	1573201067548608248	1573201070316848916	1560328737491256324	viewer	t	2025-08-09 09:29:41.972	\N
\.


--
-- Data for Name: board_subscription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board_subscription (id, board_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card (id, board_id, list_id, creator_user_id, prev_list_id, cover_attachment_id, type, "position", name, description, due_date, stopwatch, created_at, updated_at, list_changed_at, comments_total) FROM stdin;
1566011327091049535	1541385320996537361	1566004621732742167	1560278692305830913	\N	\N	project	65536	test	\N	\N	\N	2025-07-30 11:24:57.73	2025-07-30 12:04:48.462	2025-07-30 12:04:48.459	0
1566034264749769839	1565999911277691916	1566000088495424528	1560328737491256322	\N	\N	project	65536	test	\N	\N	\N	2025-07-30 12:10:32.111	\N	2025-07-30 12:10:32.11	0
\.


--
-- Data for Name: card_label; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_label (id, card_id, label_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card_membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_membership (id, card_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card_subscription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_subscription (id, card_id, user_id, is_permanent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comment (id, card_id, user_id, text, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: custom_field; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_field (id, base_custom_field_group_id, custom_field_group_id, "position", name, show_on_front_of_card, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: custom_field_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_field_group (id, board_id, card_id, base_custom_field_group_id, "position", name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: custom_field_value; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_field_value (id, card_id, custom_field_group_id, custom_field_id, content, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: file_reference; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.file_reference (id, total, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: identity_provider_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.identity_provider_user (id, user_id, issuer, sub, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.label (id, board_id, "position", name, color, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.list (id, board_id, type, "position", name, color, created_at, updated_at) FROM stdin;
1565999911328023566	1565999911277691916	archive	\N	\N	\N	2025-07-30 11:02:16.865	\N
1565999911336412175	1565999911277691916	trash	\N	\N	\N	2025-07-30 11:02:16.865	\N
1566000088495424528	1565999911277691916	active	65536	TODO	\N	2025-07-30 11:02:37.985	\N
1566000119298393105	1565999911277691916	active	131072	READY	\N	2025-07-30 11:02:41.657	\N
1566000136696366098	1565999911277691916	active	196608	DOING	\N	2025-07-30 11:02:43.731	\N
1566000182816932883	1565999911277691916	active	262144	QA	\N	2025-07-30 11:02:49.229	\N
1566000208536405012	1565999911277691916	active	327680	BLOCKED	\N	2025-07-30 11:02:52.295	\N
1566000258272461845	1565999911277691916	active	393216	DONE	\N	2025-07-30 11:02:58.222	\N
1566004621732742167	1541385320996537361	active	65536	TODO	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130776	1541385320996537361	active	131072	READY	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130777	1541385320996537361	active	196608	DOING	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130778	1541385320996537361	active	262144	QA	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130779	1541385320996537361	active	327680	BLOCKED	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130780	1541385320996537361	active	393216	DONE	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130781	1541385320996537361	trash	\N	\N	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130782	1541385320996537361	archive	\N	\N	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130783	1541386488111957023	active	65536	TODO	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130784	1541386488111957023	active	131072	READY	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130785	1541386488111957023	active	196608	DOING	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130786	1541386488111957023	active	262144	QA	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130787	1541386488111957023	active	327680	BLOCKED	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130788	1541386488111957023	active	393216	DONE	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130789	1541386488111957023	trash	\N	\N	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130790	1541386488111957023	archive	\N	\N	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130791	1541386853553275948	active	65536	TODO	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130792	1541386853553275948	active	131072	READY	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130793	1541386853553275948	active	196608	DOING	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130794	1541386853553275948	active	262144	QA	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130795	1541386853553275948	active	327680	BLOCKED	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130796	1541386853553275948	active	393216	DONE	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130797	1541386853553275948	trash	\N	\N	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566004621741130798	1541386853553275948	archive	\N	\N	\N	2025-07-30 11:11:38.38802	2025-07-30 11:11:38.38802
1566019310093075525	1566019210167977027	active	65536	TODO	\N	2025-07-30 11:40:49.378045	2025-07-30 11:40:49.378045
1566019310101464134	1566019210167977027	active	131072	READY	\N	2025-07-30 11:40:49.378045	2025-07-30 11:40:49.378045
1566019310101464135	1566019210167977027	active	196608	DOING	\N	2025-07-30 11:40:49.378045	2025-07-30 11:40:49.378045
1566019310101464136	1566019210167977027	active	262144	QA	\N	2025-07-30 11:40:49.378045	2025-07-30 11:40:49.378045
1566019310101464137	1566019210167977027	active	327680	BLOCKED	\N	2025-07-30 11:40:49.378045	2025-07-30 11:40:49.378045
1566019310101464138	1566019210167977027	active	393216	DONE	\N	2025-07-30 11:40:49.378045	2025-07-30 11:40:49.378045
1566019310101464139	1566019210167977027	trash	\N	\N	\N	2025-07-30 11:40:49.378045	2025-07-30 11:40:49.378045
1566019310101464140	1566019210167977027	archive	\N	\N	\N	2025-07-30 11:40:49.378045	2025-07-30 11:40:49.378045
1566019310101464141	1566019210167977028	active	65536	TODO	\N	2025-07-30 11:40:49.378045	2025-07-30 11:40:49.378045
1566019310101464142	1566019210167977028	active	131072	READY	\N	2025-07-30 11:40:49.378045	2025-07-30 11:40:49.378045
1566019310101464143	1566019210167977028	active	196608	DOING	\N	2025-07-30 11:40:49.378045	2025-07-30 11:40:49.378045
1566019310101464144	1566019210167977028	active	262144	QA	\N	2025-07-30 11:40:49.378045	2025-07-30 11:40:49.378045
1566019310101464145	1566019210167977028	active	327680	BLOCKED	\N	2025-07-30 11:40:49.378045	2025-07-30 11:40:49.378045
1566019310101464146	1566019210167977028	active	393216	DONE	\N	2025-07-30 11:40:49.378045	2025-07-30 11:40:49.378045
1566019310101464147	1566019210167977028	trash	\N	\N	\N	2025-07-30 11:40:49.378045	2025-07-30 11:40:49.378045
1566019310101464148	1566019210167977028	archive	\N	\N	\N	2025-07-30 11:40:49.378045	2025-07-30 11:40:49.378045
1572130827716789383	1572130827708400773	archive	\N	\N	\N	2025-08-07 22:03:19.053	\N
1572130827725177992	1572130827708400773	trash	\N	\N	\N	2025-08-07 22:03:19.053	\N
1572130827842618507	1572130827834229897	archive	\N	\N	\N	2025-08-07 22:03:19.067	\N
1572130827842618508	1572130827834229897	trash	\N	\N	\N	2025-08-07 22:03:19.067	\N
1572130827951670415	1572130827934893197	archive	\N	\N	\N	2025-08-07 22:03:19.08	\N
1572130827951670416	1572130827934893197	trash	\N	\N	\N	2025-08-07 22:03:19.08	\N
1572131156147569814	1572131156130792596	archive	\N	\N	\N	2025-08-07 22:03:58.204	\N
1572131156147569815	1572131156130792596	trash	\N	\N	\N	2025-08-07 22:03:58.204	\N
1572131156231455898	1572131156214678680	archive	\N	\N	\N	2025-08-07 22:03:58.215	\N
1572131156231455899	1572131156214678680	trash	\N	\N	\N	2025-08-07 22:03:58.215	\N
1572131156323730590	1572131156315341980	archive	\N	\N	\N	2025-08-07 22:03:58.226	\N
1572131156323730591	1572131156315341980	trash	\N	\N	\N	2025-08-07 22:03:58.226	\N
1572131313702405285	1572131313685628067	archive	\N	\N	\N	2025-08-07 22:04:16.987	\N
1572131313702405286	1572131313685628067	trash	\N	\N	\N	2025-08-07 22:04:16.987	\N
1572131313819845801	1572131313786291367	archive	\N	\N	\N	2025-08-07 22:04:17.001	\N
1572131313819845802	1572131313786291367	trash	\N	\N	\N	2025-08-07 22:04:17.001	\N
1572131313996006573	1572131313987617963	archive	\N	\N	\N	2025-08-07 22:04:17.022	\N
1572131313996006574	1572131313987617963	trash	\N	\N	\N	2025-08-07 22:04:17.022	\N
1572131367574045876	1572131367565657266	archive	\N	\N	\N	2025-08-07 22:04:23.409	\N
1572131367574045877	1572131367565657266	trash	\N	\N	\N	2025-08-07 22:04:23.409	\N
1572131367674709176	1572131367666320566	archive	\N	\N	\N	2025-08-07 22:04:23.421	\N
1572131367674709177	1572131367666320566	trash	\N	\N	\N	2025-08-07 22:04:23.421	\N
1572131367766983868	1572131367758595258	archive	\N	\N	\N	2025-08-07 22:04:23.432	\N
1572131367766983869	1572131367758595258	trash	\N	\N	\N	2025-08-07 22:04:23.432	\N
1572131516136293571	1572131516127904961	archive	\N	\N	\N	2025-08-07 22:04:41.118	\N
1572131516136293572	1572131516127904961	trash	\N	\N	\N	2025-08-07 22:04:41.118	\N
1572131516211791047	1572131516203402437	archive	\N	\N	\N	2025-08-07 22:04:41.128	\N
1572131516211791048	1572131516203402437	trash	\N	\N	\N	2025-08-07 22:04:41.128	\N
1572131516295677131	1572131516287288521	archive	\N	\N	\N	2025-08-07 22:04:41.138	\N
1572131516295677132	1572131516287288521	trash	\N	\N	\N	2025-08-07 22:04:41.138	\N
1572131516371174605	1572131516127904961	active	16384	TODO	\N	2025-08-07 22:04:41.146	\N
1572131516597667022	1572131516127904961	active	65536	READY	\N	2025-08-07 22:04:41.174	\N
1572131516647998671	1572131516127904961	active	131072	DOING	\N	2025-08-07 22:04:41.18	\N
1572131516698330320	1572131516127904961	active	196608	QA	\N	2025-08-07 22:04:41.186	\N
1572131516748661969	1572131516127904961	active	262144	BLOCKED	\N	2025-08-07 22:04:41.192	\N
1572131516798993618	1572131516127904961	active	327680	DONE	\N	2025-08-07 22:04:41.198	\N
1572131516891268307	1572131516203402437	active	16384	TODO	\N	2025-08-07 22:04:41.209	\N
1572131517126149332	1572131516203402437	active	65536	READY	\N	2025-08-07 22:04:41.237	\N
1572131517176480981	1572131516203402437	active	131072	DOING	\N	2025-08-07 22:04:41.243	\N
1572131517243589846	1572131516203402437	active	196608	QA	\N	2025-08-07 22:04:41.25	\N
1572131517293921495	1572131516203402437	active	262144	BLOCKED	\N	2025-08-07 22:04:41.257	\N
1572131517344253144	1572131516203402437	active	327680	DONE	\N	2025-08-07 22:04:41.262	\N
1572131517419750617	1572131516287288521	active	16384	TODO	\N	2025-08-07 22:04:41.272	\N
1572131517470082266	1572131516287288521	active	65536	READY	\N	2025-08-07 22:04:41.278	\N
1572131517520413915	1572131516287288521	active	131072	DOING	\N	2025-08-07 22:04:41.284	\N
1572131517570745564	1572131516287288521	active	196608	QA	\N	2025-08-07 22:04:41.29	\N
1572131517621077213	1572131516287288521	active	262144	BLOCKED	\N	2025-08-07 22:04:41.296	\N
1572131517671408862	1572131516287288521	active	327680	DONE	\N	2025-08-07 22:04:41.302	\N
1572132140064179428	1572132140055790818	archive	\N	\N	\N	2025-08-07 22:05:55.497	\N
1572132140064179429	1572132140055790818	trash	\N	\N	\N	2025-08-07 22:05:55.497	\N
1572132140139676904	1572132140131288294	archive	\N	\N	\N	2025-08-07 22:05:55.506	\N
1572132140139676905	1572132140131288294	trash	\N	\N	\N	2025-08-07 22:05:55.506	\N
1572132140231951596	1572132140223562986	archive	\N	\N	\N	2025-08-07 22:05:55.517	\N
1572132140231951597	1572132140223562986	trash	\N	\N	\N	2025-08-07 22:05:55.517	\N
1572132140315837678	1572132140055790818	active	16384	TODO	\N	2025-08-07 22:05:55.527	\N
1572132140366169327	1572132140055790818	active	65536	READY	\N	2025-08-07 22:05:55.533	\N
1572132140424889584	1572132140055790818	active	131072	DOING	\N	2025-08-07 22:05:55.54	\N
1572132140475221233	1572132140055790818	active	196608	QA	\N	2025-08-07 22:05:55.546	\N
1572132140517164274	1572132140055790818	active	262144	BLOCKED	\N	2025-08-07 22:05:55.551	\N
1572132140567495923	1572132140055790818	active	327680	DONE	\N	2025-08-07 22:05:55.557	\N
1572132140642993396	1572132140131288294	active	16384	TODO	\N	2025-08-07 22:05:55.565	\N
1572132140693325045	1572132140131288294	active	65536	READY	\N	2025-08-07 22:05:55.572	\N
1572132140743656694	1572132140131288294	active	131072	DOING	\N	2025-08-07 22:05:55.578	\N
1572132140802376951	1572132140131288294	active	196608	QA	\N	2025-08-07 22:05:55.584	\N
1572132140852708600	1572132140131288294	active	262144	BLOCKED	\N	2025-08-07 22:05:55.591	\N
1572132140911428857	1572132140131288294	active	327680	DONE	\N	2025-08-07 22:05:55.596	\N
1572132140986926330	1572132140223562986	active	16384	TODO	\N	2025-08-07 22:05:55.606	\N
1572132141037257979	1572132140223562986	active	65536	READY	\N	2025-08-07 22:05:55.613	\N
1572132141087589628	1572132140223562986	active	131072	DOING	\N	2025-08-07 22:05:55.618	\N
1572132141137921277	1572132140223562986	active	196608	QA	\N	2025-08-07 22:05:55.625	\N
1572132141188252926	1572132140223562986	active	262144	BLOCKED	\N	2025-08-07 22:05:55.631	\N
1572132141230195967	1572132140223562986	active	327680	DONE	\N	2025-08-07 22:05:55.636	\N
1572133169128277255	1572133169111500037	archive	\N	\N	\N	2025-08-07 22:07:58.171	\N
1572133169128277256	1572133169111500037	trash	\N	\N	\N	2025-08-07 22:07:58.171	\N
1572133169186997515	1572133169178608905	archive	\N	\N	\N	2025-08-07 22:07:58.178	\N
1572133169186997516	1572133169178608905	trash	\N	\N	\N	2025-08-07 22:07:58.178	\N
1572133169245717775	1572133169237329165	archive	\N	\N	\N	2025-08-07 22:07:58.185	\N
1572133169245717776	1572133169237329165	trash	\N	\N	\N	2025-08-07 22:07:58.185	\N
1572133169296049425	1572133169111500037	active	16384	TODO	\N	2025-08-07 22:07:58.191	\N
1572133169388324114	1572133169111500037	active	65536	READY	\N	2025-08-07 22:07:58.202	\N
1572133169547707667	1572133169111500037	active	131072	DOING	\N	2025-08-07 22:07:58.221	\N
1572133169598039316	1572133169111500037	active	196608	QA	\N	2025-08-07 22:07:58.227	\N
1572133169639982357	1572133169111500037	active	262144	BLOCKED	\N	2025-08-07 22:07:58.232	\N
1572133169690314006	1572133169111500037	active	327680	DONE	\N	2025-08-07 22:07:58.237	\N
1572133169740645655	1572133169178608905	active	16384	TODO	\N	2025-08-07 22:07:58.244	\N
1572133169790977304	1572133169178608905	active	65536	READY	\N	2025-08-07 22:07:58.25	\N
1572133169841308953	1572133169178608905	active	131072	DOING	\N	2025-08-07 22:07:58.255	\N
1572133169891640602	1572133169178608905	active	196608	QA	\N	2025-08-07 22:07:58.262	\N
1572133169950360859	1572133169178608905	active	262144	BLOCKED	\N	2025-08-07 22:07:58.269	\N
1572133170000692508	1572133169178608905	active	327680	DONE	\N	2025-08-07 22:07:58.275	\N
1572133170042635549	1572133169237329165	active	16384	TODO	\N	2025-08-07 22:07:58.28	\N
1572133170092967198	1572133169237329165	active	65536	READY	\N	2025-08-07 22:07:58.285	\N
1572133170143298847	1572133169237329165	active	131072	DOING	\N	2025-08-07 22:07:58.291	\N
1572133170176853280	1572133169237329165	active	196608	QA	\N	2025-08-07 22:07:58.296	\N
1572133170227184929	1572133169237329165	active	262144	BLOCKED	\N	2025-08-07 22:07:58.302	\N
1572133170336236834	1572133169237329165	active	327680	DONE	\N	2025-08-07 22:07:58.313	\N
1572140517355947306	1572140517339170088	archive	\N	\N	\N	2025-08-07 22:22:34.148	\N
1572140517364335915	1572140517339170088	trash	\N	\N	\N	2025-08-07 22:22:34.148	\N
1572140517515330862	1572140517498553644	archive	\N	\N	\N	2025-08-07 22:22:34.166	\N
1572140517515330863	1572140517498553644	trash	\N	\N	\N	2025-08-07 22:22:34.166	\N
1572140517590828338	1572140517582439728	archive	\N	\N	\N	2025-08-07 22:22:34.176	\N
1572140517590828339	1572140517582439728	trash	\N	\N	\N	2025-08-07 22:22:34.176	\N
1572140517657937204	1572140517339170088	active	16384	TODO	\N	2025-08-07 22:22:34.183	\N
1572140517708268853	1572140517339170088	active	65536	READY	\N	2025-08-07 22:22:34.19	\N
1572140517758600502	1572140517339170088	active	131072	DOING	\N	2025-08-07 22:22:34.196	\N
1572140517808932151	1572140517339170088	active	196608	QA	\N	2025-08-07 22:22:34.201	\N
1572140517850875192	1572140517339170088	active	262144	BLOCKED	\N	2025-08-07 22:22:34.207	\N
1572140517892818233	1572140517339170088	active	327680	DONE	\N	2025-08-07 22:22:34.212	\N
1572140517968315706	1572140517498553644	active	16384	TODO	\N	2025-08-07 22:22:34.221	\N
1572140518035424571	1572140517498553644	active	65536	READY	\N	2025-08-07 22:22:34.229	\N
1572140518102533436	1572140517498553644	active	131072	DOING	\N	2025-08-07 22:22:34.237	\N
1572140518178030909	1572140517498553644	active	196608	QA	\N	2025-08-07 22:22:34.245	\N
1572140518354191678	1572140517498553644	active	262144	BLOCKED	\N	2025-08-07 22:22:34.267	\N
1572140518438077759	1572140517498553644	active	327680	DONE	\N	2025-08-07 22:22:34.277	\N
1572140518521963840	1572140517582439728	active	16384	TODO	\N	2025-08-07 22:22:34.286	\N
1572140518597461313	1572140517582439728	active	65536	READY	\N	2025-08-07 22:22:34.296	\N
1572140518656181570	1572140517582439728	active	131072	DOING	\N	2025-08-07 22:22:34.302	\N
1572140518706513219	1572140517582439728	active	196608	QA	\N	2025-08-07 22:22:34.308	\N
1572140518748456260	1572140517582439728	active	262144	BLOCKED	\N	2025-08-07 22:22:34.314	\N
1572140518790399301	1572140517582439728	active	327680	DONE	\N	2025-08-07 22:22:34.319	\N
1573191158740288865	1573191158689957215	archive	\N	\N	\N	2025-08-09 09:10:00.36	\N
1573191158748677474	1573191158689957215	trash	\N	\N	\N	2025-08-09 09:10:00.36	\N
1573191158966781283	1573191158689957215	active	65536	TODO	\N	2025-08-09 09:10:00.388	\N
1573191160183129444	1573191158689957215	active	131072	READY	\N	2025-08-09 09:10:00.532	\N
1573191160434787685	1573191158689957215	active	196608	DOING	\N	2025-08-09 09:10:00.562	\N
1573191160711611750	1573191158689957215	active	262144	QA	\N	2025-08-09 09:10:00.596	\N
1573191161223316839	1573191158689957215	active	327680	BLOCKED	\N	2025-08-09 09:10:00.655	\N
1573191161516918120	1573191158689957215	active	393216	DONE	\N	2025-08-09 09:10:00.692	\N
1573191162095732078	1573191162078954860	archive	\N	\N	\N	2025-08-09 09:10:00.761	\N
1573191162095732079	1573191162078954860	trash	\N	\N	\N	2025-08-09 09:10:00.761	\N
1573191162162840944	1573191162078954860	active	65536	TODO	\N	2025-08-09 09:10:00.768	\N
1573191162238338417	1573191162078954860	active	131072	READY	\N	2025-08-09 09:10:00.777	\N
1573191162305447282	1573191162078954860	active	196608	DOING	\N	2025-08-09 09:10:00.786	\N
1573191162372556147	1573191162078954860	active	262144	QA	\N	2025-08-09 09:10:00.793	\N
1573191162422887796	1573191162078954860	active	327680	BLOCKED	\N	2025-08-09 09:10:00.8	\N
1573191162548716917	1573191162078954860	active	393216	DONE	\N	2025-08-09 09:10:00.815	\N
1573191163010090363	1573191162976535929	archive	\N	\N	\N	2025-08-09 09:10:00.87	\N
1573191163010090364	1573191162976535929	trash	\N	\N	\N	2025-08-09 09:10:00.87	\N
1573191163093976445	1573191162976535929	active	65536	TODO	\N	2025-08-09 09:10:00.879	\N
1573191163161085310	1573191162976535929	active	131072	READY	\N	2025-08-09 09:10:00.887	\N
1573191163228194175	1573191162976535929	active	196608	DOING	\N	2025-08-09 09:10:00.896	\N
1573191163328857472	1573191162976535929	active	262144	QA	\N	2025-08-09 09:10:00.906	\N
1573191163404354945	1573191162976535929	active	327680	BLOCKED	\N	2025-08-09 09:10:00.916	\N
1573191163479852418	1573191162976535929	active	393216	DONE	\N	2025-08-09 09:10:00.926	\N
1573191243691722122	1573191243674944904	archive	\N	\N	\N	2025-08-09 09:10:10.487	\N
1573191243691722123	1573191243674944904	trash	\N	\N	\N	2025-08-09 09:10:10.487	\N
1573191243775608204	1573191243674944904	active	65536	TODO	\N	2025-08-09 09:10:10.497	\N
1573191243842717069	1573191243674944904	active	131072	READY	\N	2025-08-09 09:10:10.506	\N
1573191243918214542	1573191243674944904	active	196608	DOING	\N	2025-08-09 09:10:10.514	\N
1573191243960157583	1573191243674944904	active	262144	QA	\N	2025-08-09 09:10:10.52	\N
1573191244002100624	1573191243674944904	active	327680	BLOCKED	\N	2025-08-09 09:10:10.524	\N
1573191244044043665	1573191243674944904	active	393216	DONE	\N	2025-08-09 09:10:10.53	\N
1573191244396365207	1573191244379587989	archive	\N	\N	\N	2025-08-09 09:10:10.571	\N
1573191244396365208	1573191244379587989	trash	\N	\N	\N	2025-08-09 09:10:10.571	\N
1573191244471862681	1573191244379587989	active	65536	TODO	\N	2025-08-09 09:10:10.58	\N
1573191244555748762	1573191244379587989	active	131072	READY	\N	2025-08-09 09:10:10.591	\N
1573191244606080411	1573191244379587989	active	196608	DOING	\N	2025-08-09 09:10:10.597	\N
1573191244715132316	1573191244379587989	active	262144	QA	\N	2025-08-09 09:10:10.61	\N
1573191244782241181	1573191244379587989	active	327680	BLOCKED	\N	2025-08-09 09:10:10.618	\N
1573191244916458910	1573191244379587989	active	393216	DONE	\N	2025-08-09 09:10:10.634	\N
1573191245444941220	1573191245428164002	archive	\N	\N	\N	2025-08-09 09:10:10.697	\N
1573191245444941221	1573191245428164002	trash	\N	\N	\N	2025-08-09 09:10:10.697	\N
1573191245512050086	1573191245428164002	active	65536	TODO	\N	2025-08-09 09:10:10.704	\N
1573191245553993127	1573191245428164002	active	131072	READY	\N	2025-08-09 09:10:10.71	\N
1573191245595936168	1573191245428164002	active	196608	DOING	\N	2025-08-09 09:10:10.715	\N
1573191245637879209	1573191245428164002	active	262144	QA	\N	2025-08-09 09:10:10.72	\N
1573191245679822250	1573191245428164002	active	327680	BLOCKED	\N	2025-08-09 09:10:10.725	\N
1573191245721765291	1573191245428164002	active	393216	DONE	\N	2025-08-09 09:10:10.73	\N
1573192322642871731	1573192322609317297	archive	\N	\N	\N	2025-08-09 09:12:19.108	\N
1573192322642871732	1573192322609317297	trash	\N	\N	\N	2025-08-09 09:12:19.108	\N
1573192322735146421	1573192322609317297	active	65536	TODO	\N	2025-08-09 09:12:19.119	\N
1573192322844198326	1573192322609317297	active	131072	READY	\N	2025-08-09 09:12:19.132	\N
1573192322961638839	1573192322609317297	active	196608	DOING	\N	2025-08-09 09:12:19.146	\N
1573192323070690744	1573192322609317297	active	262144	QA	\N	2025-08-09 09:12:19.16	\N
1573192323154576825	1573192322609317297	active	327680	BLOCKED	\N	2025-08-09 09:12:19.169	\N
1573192323204908474	1573192322609317297	active	393216	DONE	\N	2025-08-09 09:12:19.175	\N
1573192323691447744	1573192323683059134	archive	\N	\N	\N	2025-08-09 09:12:19.234	\N
1573192323691447745	1573192323683059134	trash	\N	\N	\N	2025-08-09 09:12:19.234	\N
1573192324001826242	1573192323683059134	active	65536	TODO	\N	2025-08-09 09:12:19.27	\N
1573192324261873091	1573192323683059134	active	131072	READY	\N	2025-08-09 09:12:19.301	\N
1573192324328981956	1573192323683059134	active	196608	DOING	\N	2025-08-09 09:12:19.309	\N
1573192324379313605	1573192323683059134	active	262144	QA	\N	2025-08-09 09:12:19.316	\N
1573192324429645254	1573192323683059134	active	327680	BLOCKED	\N	2025-08-09 09:12:19.321	\N
1573192324463199687	1573192323683059134	active	393216	DONE	\N	2025-08-09 09:12:19.326	\N
1573192324773578189	1573192324756800971	archive	\N	\N	\N	2025-08-09 09:12:19.363	\N
1573192324773578190	1573192324756800971	trash	\N	\N	\N	2025-08-09 09:12:19.363	\N
1573192324840687055	1573192324756800971	active	65536	TODO	\N	2025-08-09 09:12:19.37	\N
1573192324891018704	1573192324756800971	active	131072	READY	\N	2025-08-09 09:12:19.376	\N
1573192324932961745	1573192324756800971	active	196608	DOING	\N	2025-08-09 09:12:19.381	\N
1573192324983293394	1573192324756800971	active	262144	QA	\N	2025-08-09 09:12:19.388	\N
1573192325042013651	1573192324756800971	active	327680	BLOCKED	\N	2025-08-09 09:12:19.395	\N
1573192325083956692	1573192324756800971	active	393216	DONE	\N	2025-08-09 09:12:19.4	\N
1573193618556978652	1573193618523424218	archive	\N	\N	\N	2025-08-09 09:14:53.594	\N
1573193618556978653	1573193618523424218	trash	\N	\N	\N	2025-08-09 09:14:53.594	\N
1573193618632476126	1573193618523424218	active	65536	TODO	\N	2025-08-09 09:14:53.602	\N
1573193618707973599	1573193618523424218	active	131072	READY	\N	2025-08-09 09:14:53.612	\N
1573193618749916640	1573193618523424218	active	196608	DOING	\N	2025-08-09 09:14:53.617	\N
1573193618791859681	1573193618523424218	active	262144	QA	\N	2025-08-09 09:14:53.622	\N
1573193618833802722	1573193618523424218	active	327680	BLOCKED	\N	2025-08-09 09:14:53.627	\N
1573193618875745763	1573193618523424218	active	393216	DONE	\N	2025-08-09 09:14:53.631	\N
1573193619244844521	1573193619236455911	archive	\N	\N	\N	2025-08-09 09:14:53.676	\N
1573193619244844522	1573193619236455911	trash	\N	\N	\N	2025-08-09 09:14:53.676	\N
1573193619311953387	1573193619236455911	active	65536	TODO	\N	2025-08-09 09:14:53.683	\N
1573193619370673644	1573193619236455911	active	131072	READY	\N	2025-08-09 09:14:53.691	\N
1573193619412616685	1573193619236455911	active	196608	DOING	\N	2025-08-09 09:14:53.696	\N
1573193619462948334	1573193619236455911	active	262144	QA	\N	2025-08-09 09:14:53.702	\N
1573193619513279983	1573193619236455911	active	327680	BLOCKED	\N	2025-08-09 09:14:53.708	\N
1573193619555223024	1573193619236455911	active	393216	DONE	\N	2025-08-09 09:14:53.713	\N
1573193619991430646	1573193619974653428	archive	\N	\N	\N	2025-08-09 09:14:53.765	\N
1573193619991430647	1573193619974653428	trash	\N	\N	\N	2025-08-09 09:14:53.765	\N
1573193620075316728	1573193619974653428	active	65536	TODO	\N	2025-08-09 09:14:53.775	\N
1573193620142425593	1573193619974653428	active	131072	READY	\N	2025-08-09 09:14:53.782	\N
1573193620175980026	1573193619974653428	active	196608	DOING	\N	2025-08-09 09:14:53.786	\N
1573193620217923067	1573193619974653428	active	262144	QA	\N	2025-08-09 09:14:53.792	\N
1573193620276643324	1573193619974653428	active	327680	BLOCKED	\N	2025-08-09 09:14:53.798	\N
1573193620318586365	1573193619974653428	active	393216	DONE	\N	2025-08-09 09:14:53.804	\N
1573193972346521093	1573193972312966659	archive	\N	\N	\N	2025-08-09 09:15:35.768	\N
1573193972346521094	1573193972312966659	trash	\N	\N	\N	2025-08-09 09:15:35.768	\N
1573193972463961607	1573193972312966659	active	65536	TODO	\N	2025-08-09 09:15:35.782	\N
1573193972547847688	1573193972312966659	active	131072	READY	\N	2025-08-09 09:15:35.792	\N
1573193972606567945	1573193972312966659	active	196608	DOING	\N	2025-08-09 09:15:35.8	\N
1573193972648510986	1573193972312966659	active	262144	QA	\N	2025-08-09 09:15:35.805	\N
1573193972690454027	1573193972312966659	active	327680	BLOCKED	\N	2025-08-09 09:15:35.81	\N
1573193972724008460	1573193972312966659	active	393216	DONE	\N	2025-08-09 09:15:35.814	\N
1573193973017609746	1573193973009221136	archive	\N	\N	\N	2025-08-09 09:15:35.849	\N
1573193973017609747	1573193973009221136	trash	\N	\N	\N	2025-08-09 09:15:35.849	\N
1573193973076330004	1573193973009221136	active	65536	TODO	\N	2025-08-09 09:15:35.856	\N
1573193973126661653	1573193973009221136	active	131072	READY	\N	2025-08-09 09:15:35.862	\N
1573193973176993302	1573193973009221136	active	196608	DOING	\N	2025-08-09 09:15:35.868	\N
1573193973235713559	1573193973009221136	active	262144	QA	\N	2025-08-09 09:15:35.875	\N
1573193973286045208	1573193973009221136	active	327680	BLOCKED	\N	2025-08-09 09:15:35.88	\N
1573193973378319897	1573193973009221136	active	393216	DONE	\N	2025-08-09 09:15:35.892	\N
1573193974007465503	1573193973999076893	archive	\N	\N	\N	2025-08-09 09:15:35.967	\N
1573193974007465504	1573193973999076893	trash	\N	\N	\N	2025-08-09 09:15:35.967	\N
1573193974066185761	1573193973999076893	active	65536	TODO	\N	2025-08-09 09:15:35.974	\N
1573193974116517410	1573193973999076893	active	131072	READY	\N	2025-08-09 09:15:35.98	\N
1573193974150071843	1573193973999076893	active	196608	DOING	\N	2025-08-09 09:15:35.984	\N
1573193974192014884	1573193973999076893	active	262144	QA	\N	2025-08-09 09:15:35.989	\N
1573193974233957925	1573193973999076893	active	327680	BLOCKED	\N	2025-08-09 09:15:35.993	\N
1573193974267512358	1573193973999076893	active	393216	DONE	\N	2025-08-09 09:15:35.998	\N
1573194907969914415	1573194907919582765	archive	\N	\N	\N	2025-08-09 09:17:27.302	\N
1573194907969914416	1573194907919582765	trash	\N	\N	\N	2025-08-09 09:17:27.302	\N
1573194908087354929	1573194907919582765	active	65536	TODO	\N	2025-08-09 09:17:27.318	\N
1573194908162852402	1573194907919582765	active	131072	READY	\N	2025-08-09 09:17:27.327	\N
1573194908221572659	1573194907919582765	active	196608	DOING	\N	2025-08-09 09:17:27.333	\N
1573194908263515700	1573194907919582765	active	262144	QA	\N	2025-08-09 09:17:27.339	\N
1573194908305458741	1573194907919582765	active	327680	BLOCKED	\N	2025-08-09 09:17:27.344	\N
1573194908355790390	1573194907919582765	active	393216	DONE	\N	2025-08-09 09:17:27.35	\N
1573194908649391676	1573194908641003066	archive	\N	\N	\N	2025-08-09 09:17:27.385	\N
1573194908649391677	1573194908641003066	trash	\N	\N	\N	2025-08-09 09:17:27.385	\N
1573194908733277758	1573194908641003066	active	65536	TODO	\N	2025-08-09 09:17:27.395	\N
1573194908800386623	1573194908641003066	active	131072	READY	\N	2025-08-09 09:17:27.402	\N
1573194908867495488	1573194908641003066	active	196608	DOING	\N	2025-08-09 09:17:27.411	\N
1573194908942992961	1573194908641003066	active	262144	QA	\N	2025-08-09 09:17:27.42	\N
1573194908976547394	1573194908641003066	active	327680	BLOCKED	\N	2025-08-09 09:17:27.424	\N
1573194909018490435	1573194908641003066	active	393216	DONE	\N	2025-08-09 09:17:27.429	\N
1573194909312091721	1573194909303703111	archive	\N	\N	\N	2025-08-09 09:17:27.464	\N
1573194909312091722	1573194909303703111	trash	\N	\N	\N	2025-08-09 09:17:27.464	\N
1573194909395977803	1573194909303703111	active	65536	TODO	\N	2025-08-09 09:17:27.474	\N
1573194909505029708	1573194909303703111	active	131072	READY	\N	2025-08-09 09:17:27.487	\N
1573194909572138573	1573194909303703111	active	196608	DOING	\N	2025-08-09 09:17:27.495	\N
1573194909656024654	1573194909303703111	active	262144	QA	\N	2025-08-09 09:17:27.505	\N
1573194909773465167	1573194909303703111	active	327680	BLOCKED	\N	2025-08-09 09:17:27.519	\N
1573194909865739856	1573194909303703111	active	393216	DONE	\N	2025-08-09 09:17:27.529	\N
1573196042839524952	1573196042780804694	archive	\N	\N	\N	2025-08-09 09:19:42.59	\N
1573196042839524953	1573196042780804694	trash	\N	\N	\N	2025-08-09 09:19:42.59	\N
1573196042998908506	1573196042780804694	active	65536	TODO	\N	2025-08-09 09:19:42.609	\N
1573196043116349019	1573196042780804694	active	131072	READY	\N	2025-08-09 09:19:42.623	\N
1573196043225400924	1573196042780804694	active	196608	DOING	\N	2025-08-09 09:19:42.636	\N
1573196043275732573	1573196042780804694	active	262144	QA	\N	2025-08-09 09:19:42.643	\N
1573196043326064222	1573196042780804694	active	327680	BLOCKED	\N	2025-08-09 09:19:42.649	\N
1573196043376395871	1573196042780804694	active	393216	DONE	\N	2025-08-09 09:19:42.655	\N
1573196043695162981	1573196043686774371	archive	\N	\N	\N	2025-08-09 09:19:42.692	\N
1573196043695162982	1573196043686774371	trash	\N	\N	\N	2025-08-09 09:19:42.692	\N
1573196043745494631	1573196043686774371	active	65536	TODO	\N	2025-08-09 09:19:42.699	\N
1573196043829380712	1573196043686774371	active	131072	READY	\N	2025-08-09 09:19:42.708	\N
1573196043888100969	1573196043686774371	active	196608	DOING	\N	2025-08-09 09:19:42.716	\N
1573196043963598442	1573196043686774371	active	262144	QA	\N	2025-08-09 09:19:42.724	\N
1573196044013930091	1573196043686774371	active	327680	BLOCKED	\N	2025-08-09 09:19:42.731	\N
1573196044055873132	1573196043686774371	active	393216	DONE	\N	2025-08-09 09:19:42.735	\N
1573196044324308594	1573196044307531376	archive	\N	\N	\N	2025-08-09 09:19:42.768	\N
1573196044324308595	1573196044307531376	trash	\N	\N	\N	2025-08-09 09:19:42.768	\N
1573196044424971892	1573196044307531376	active	65536	TODO	\N	2025-08-09 09:19:42.78	\N
1573196044483692149	1573196044307531376	active	131072	READY	\N	2025-08-09 09:19:42.786	\N
1573196044542412406	1573196044307531376	active	196608	DOING	\N	2025-08-09 09:19:42.794	\N
1573196044584355447	1573196044307531376	active	262144	QA	\N	2025-08-09 09:19:42.799	\N
1573196044668241528	1573196044307531376	active	327680	BLOCKED	\N	2025-08-09 09:19:42.809	\N
1573196044735350393	1573196044307531376	active	393216	DONE	\N	2025-08-09 09:19:42.817	\N
1573196403449005697	1573196403423839871	archive	\N	\N	\N	2025-08-09 09:20:25.578	\N
1573196403449005698	1573196403423839871	trash	\N	\N	\N	2025-08-09 09:20:25.578	\N
1573196403524503171	1573196403423839871	active	65536	TODO	\N	2025-08-09 09:20:25.588	\N
1573196403591612036	1573196403423839871	active	131072	READY	\N	2025-08-09 09:20:25.596	\N
1573196403683886725	1573196403423839871	active	196608	DOING	\N	2025-08-09 09:20:25.607	\N
1573196403750995590	1573196403423839871	active	262144	QA	\N	2025-08-09 09:20:25.615	\N
1573196403809715847	1573196403423839871	active	327680	BLOCKED	\N	2025-08-09 09:20:25.622	\N
1573196403860047496	1573196403423839871	active	393216	DONE	\N	2025-08-09 09:20:25.628	\N
1573196404136871566	1573196404128482956	archive	\N	\N	\N	2025-08-09 09:20:25.661	\N
1573196404145260175	1573196404128482956	trash	\N	\N	\N	2025-08-09 09:20:25.661	\N
1573196404195591824	1573196404128482956	active	65536	TODO	\N	2025-08-09 09:20:25.668	\N
1573196404254312081	1573196404128482956	active	131072	READY	\N	2025-08-09 09:20:25.675	\N
1573196404304643730	1573196404128482956	active	196608	DOING	\N	2025-08-09 09:20:25.681	\N
1573196404388529811	1573196404128482956	active	262144	QA	\N	2025-08-09 09:20:25.691	\N
1573196404489193108	1573196404128482956	active	327680	BLOCKED	\N	2025-08-09 09:20:25.702	\N
1573196404581467797	1573196404128482956	active	393216	DONE	\N	2025-08-09 09:20:25.713	\N
1573196405118338715	1573196405042841241	archive	\N	\N	\N	2025-08-09 09:20:25.778	\N
1573196405118338716	1573196405042841241	trash	\N	\N	\N	2025-08-09 09:20:25.778	\N
1573196405193836189	1573196405042841241	active	65536	TODO	\N	2025-08-09 09:20:25.787	\N
1573196405244167838	1573196405042841241	active	131072	READY	\N	2025-08-09 09:20:25.792	\N
1573196405286110879	1573196405042841241	active	196608	DOING	\N	2025-08-09 09:20:25.798	\N
1573196405336442528	1573196405042841241	active	262144	QA	\N	2025-08-09 09:20:25.803	\N
1573196405386774177	1573196405042841241	active	327680	BLOCKED	\N	2025-08-09 09:20:25.81	\N
1573196405428717218	1573196405042841241	active	393216	DONE	\N	2025-08-09 09:20:25.815	\N
1573197655230645930	1573197655188702888	archive	\N	\N	\N	2025-08-09 09:22:54.801	\N
1573197655239034539	1573197655188702888	trash	\N	\N	\N	2025-08-09 09:22:54.801	\N
1573197655306143404	1573197655188702888	active	65536	TODO	\N	2025-08-09 09:22:54.812	\N
1573197655356475053	1573197655188702888	active	131072	READY	\N	2025-08-09 09:22:54.818	\N
1573197655398418094	1573197655188702888	active	196608	DOING	\N	2025-08-09 09:22:54.823	\N
1573197655473915567	1573197655188702888	active	262144	QA	\N	2025-08-09 09:22:54.832	\N
1573197655515858608	1573197655188702888	active	327680	BLOCKED	\N	2025-08-09 09:22:54.837	\N
1573197655557801649	1573197655188702888	active	393216	DONE	\N	2025-08-09 09:22:54.841	\N
1573197655884957367	1573197655859791541	archive	\N	\N	\N	2025-08-09 09:22:54.881	\N
1573197655884957368	1573197655859791541	trash	\N	\N	\N	2025-08-09 09:22:54.881	\N
1573197655960454841	1573197655859791541	active	65536	TODO	\N	2025-08-09 09:22:54.89	\N
1573197656035952314	1573197655859791541	active	131072	READY	\N	2025-08-09 09:22:54.899	\N
1573197656077895355	1573197655859791541	active	196608	DOING	\N	2025-08-09 09:22:54.904	\N
1573197656136615612	1573197655859791541	active	262144	QA	\N	2025-08-09 09:22:54.911	\N
1573197656186947261	1573197655859791541	active	327680	BLOCKED	\N	2025-08-09 09:22:54.917	\N
1573197656228890302	1573197655859791541	active	393216	DONE	\N	2025-08-09 09:22:54.922	\N
1573197656480548548	1573197656472159938	archive	\N	\N	\N	2025-08-09 09:22:54.952	\N
1573197656480548549	1573197656472159938	trash	\N	\N	\N	2025-08-09 09:22:54.952	\N
1573197656530880198	1573197656472159938	active	65536	TODO	\N	2025-08-09 09:22:54.958	\N
1573197656572823239	1573197656472159938	active	131072	READY	\N	2025-08-09 09:22:54.963	\N
1573197656606377672	1573197656472159938	active	196608	DOING	\N	2025-08-09 09:22:54.967	\N
1573197656656709321	1573197656472159938	active	262144	QA	\N	2025-08-09 09:22:54.973	\N
1573197656690263754	1573197656472159938	active	327680	BLOCKED	\N	2025-08-09 09:22:54.977	\N
1573197656723818187	1573197656472159938	active	393216	DONE	\N	2025-08-09 09:22:54.981	\N
1573200268877629139	1573200268852463313	archive	\N	\N	\N	2025-08-09 09:28:06.373	\N
1573200268894406356	1573200268852463313	trash	\N	\N	\N	2025-08-09 09:28:06.373	\N
1573200268953126613	1573200268852463313	active	65536	TODO	\N	2025-08-09 09:28:06.383	\N
1573200269062178518	1573200268852463313	active	131072	READY	\N	2025-08-09 09:28:06.394	\N
1573200269179619031	1573200268852463313	active	196608	DOING	\N	2025-08-09 09:28:06.409	\N
1573200269255116504	1573200268852463313	active	262144	QA	\N	2025-08-09 09:28:06.419	\N
1573200269422888665	1573200268852463313	active	327680	BLOCKED	\N	2025-08-09 09:28:06.438	\N
1573200269464831706	1573200268852463313	active	393216	DONE	\N	2025-08-09 09:28:06.444	\N
1573200269783598816	1573200269775210206	archive	\N	\N	\N	2025-08-09 09:28:06.482	\N
1573200269783598817	1573200269775210206	trash	\N	\N	\N	2025-08-09 09:28:06.482	\N
1573200269850707682	1573200269775210206	active	65536	TODO	\N	2025-08-09 09:28:06.49	\N
1573200269959759587	1573200269775210206	active	131072	READY	\N	2025-08-09 09:28:06.503	\N
1573200270026868452	1573200269775210206	active	196608	DOING	\N	2025-08-09 09:28:06.51	\N
1573200270085588709	1573200269775210206	active	262144	QA	\N	2025-08-09 09:28:06.517	\N
1573200270127531750	1573200269775210206	active	327680	BLOCKED	\N	2025-08-09 09:28:06.523	\N
1573200270169474791	1573200269775210206	active	393216	DONE	\N	2025-08-09 09:28:06.528	\N
1573200270454687469	1573200270446298859	archive	\N	\N	\N	2025-08-09 09:28:06.562	\N
1573200270454687470	1573200270446298859	trash	\N	\N	\N	2025-08-09 09:28:06.562	\N
1573200270505019119	1573200270446298859	active	65536	TODO	\N	2025-08-09 09:28:06.568	\N
1573200270555350768	1573200270446298859	active	131072	READY	\N	2025-08-09 09:28:06.574	\N
1573200270588905201	1573200270446298859	active	196608	DOING	\N	2025-08-09 09:28:06.578	\N
1573200270622459634	1573200270446298859	active	262144	QA	\N	2025-08-09 09:28:06.582	\N
1573200270664402675	1573200270446298859	active	327680	BLOCKED	\N	2025-08-09 09:28:06.586	\N
1573200270697957108	1573200270446298859	active	393216	DONE	\N	2025-08-09 09:28:06.59	\N
1573201068890785532	1573201068874008314	archive	\N	\N	\N	2025-08-09 09:29:41.743	\N
1573201068890785533	1573201068874008314	trash	\N	\N	\N	2025-08-09 09:29:41.743	\N
1573201068957894398	1573201068874008314	active	65536	TODO	\N	2025-08-09 09:29:41.751	\N
1573201069058557695	1573201068874008314	active	131072	READY	\N	2025-08-09 09:29:41.762	\N
1573201069100500736	1573201068874008314	active	196608	DOING	\N	2025-08-09 09:29:41.768	\N
1573201069150832385	1573201068874008314	active	262144	QA	\N	2025-08-09 09:29:41.774	\N
1573201069226329858	1573201068874008314	active	327680	BLOCKED	\N	2025-08-09 09:29:41.783	\N
1573201069268272899	1573201068874008314	active	393216	DONE	\N	2025-08-09 09:29:41.788	\N
1573201069729646345	1573201069712869127	archive	\N	\N	\N	2025-08-09 09:29:41.843	\N
1573201069729646346	1573201069712869127	trash	\N	\N	\N	2025-08-09 09:29:41.843	\N
1573201069788366603	1573201069712869127	active	65536	TODO	\N	2025-08-09 09:29:41.85	\N
1573201069872252684	1573201069712869127	active	131072	READY	\N	2025-08-09 09:29:41.859	\N
1573201069922584333	1573201069712869127	active	196608	DOING	\N	2025-08-09 09:29:41.866	\N
1573201069972915982	1573201069712869127	active	262144	QA	\N	2025-08-09 09:29:41.872	\N
1573201070014859023	1573201069712869127	active	327680	BLOCKED	\N	2025-08-09 09:29:41.877	\N
1573201070056802064	1573201069712869127	active	393216	DONE	\N	2025-08-09 09:29:41.882	\N
1573201070325237526	1573201070316848916	archive	\N	\N	\N	2025-08-09 09:29:41.914	\N
1573201070325237527	1573201070316848916	trash	\N	\N	\N	2025-08-09 09:29:41.914	\N
1573201070425900824	1573201070316848916	active	65536	TODO	\N	2025-08-09 09:29:41.925	\N
1573201070476232473	1573201070316848916	active	131072	READY	\N	2025-08-09 09:29:41.932	\N
1573201070518175514	1573201070316848916	active	196608	DOING	\N	2025-08-09 09:29:41.937	\N
1573201070560118555	1573201070316848916	active	262144	QA	\N	2025-08-09 09:29:41.942	\N
1573201070602061596	1573201070316848916	active	327680	BLOCKED	\N	2025-08-09 09:29:41.947	\N
1573201070644004637	1573201070316848916	active	393216	DONE	\N	2025-08-09 09:29:41.952	\N
\.


--
-- Data for Name: migration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migration (id, name, batch, migration_time) FROM stdin;
1	20250228000022_version_2.js	1	2025-07-22 13:35:14.35+00
2	20250522151122_add_board_activity_log.js	1	2025-07-22 13:35:14.352+00
3	20250523131647_add_comments_counter.js	1	2025-07-22 13:35:14.353+00
4	20250603102521_canonicalize_locale_codes.js	1	2025-07-22 13:35:14.354+00
\.


--
-- Data for Name: migration_lock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migration_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification (id, user_id, creator_user_id, board_id, card_id, comment_id, action_id, type, data, is_read, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_service; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_service (id, user_id, board_id, url, format, created_at, updated_at) FROM stdin;
1565999542187328521	1560278692305830913	\N	json://mini2.local:8634/api/v1/flow-events/webhook	markdown	2025-07-30 11:01:32.859	\N
1566022531410822231	\N	1541385320996537361	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:13.388652	2025-07-30 12:08:07.365
1566022531410822232	\N	1541386488111957023	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:13.388652	2025-07-30 12:08:15.742
1566022531410822233	\N	1541386853553275948	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:13.388652	2025-07-30 12:08:23.596
1566033706831840358	\N	1566019210167977028	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 12:09:25.602	\N
1566033750276441191	\N	1566019210167977027	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 12:09:30.782	\N
1566033792991233128	\N	1565999911277691916	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 12:09:35.874	\N
1566022633139471450	\N	1565999911277691916	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:25.515868	2025-07-30 11:47:25.515868
1566022633139471451	\N	1566019210167977027	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:25.515868	2025-07-30 11:47:25.515868
1566022633139471452	\N	1566019210167977028	json://core-app:8634/api/v1/notifications/webhook	markdown	2025-07-30 11:47:25.515868	2025-07-30 11:47:25.515868
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project (id, owner_project_manager_id, background_image_id, name, description, background_type, background_gradient, is_hidden, created_at, updated_at) FROM stdin;
1573201067548608248	\N	\N	Core Repository - Rearchitecture	\N	\N	\N	f	2025-08-09 09:29:41.572	\N
\.


--
-- Data for Name: project_favorite; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_favorite (id, project_id, user_id, created_at, updated_at) FROM stdin;
1566005223917356079	1541383442627822607	1560328737491256322	2025-07-30 11:12:50.174	\N
\.


--
-- Data for Name: project_manager; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_manager (id, project_id, user_id, created_at, updated_at) FROM stdin;
1565999851257201675	1565999851240424458	1560278692305830913	2025-07-30 11:02:09.704	\N
1560328737491256327	1541383442627822607	1560328737491256322	2025-07-30 11:02:11.8245	2025-07-30 11:02:11.8245
1560328737491256328	1541383442627822607	1560328737491256323	2025-07-30 11:02:11.8245	2025-07-30 11:02:11.8245
1560328737491256329	1541383442627822607	1560328737491256324	2025-07-30 11:02:11.8245	2025-07-30 11:02:11.8245
1560328737491256330	1541383442627822607	1560328737491256325	2025-07-30 11:02:11.8245	2025-07-30 11:02:11.8245
1566010990380713021	1541383442627822607	1560278692305830913	2025-07-30 11:24:17.59	\N
1566033392586196069	1565999851240424458	1560328737491256322	2025-07-30 12:08:48.141	\N
1572122797008749694	1572122797000361085	1560328737491256322	2025-08-07 21:47:21.718	\N
1572123029155087489	1572123029146698880	1560328737491256322	2025-08-07 21:47:49.391	\N
1572130827590960260	1572130827590960259	1560328737491256322	2025-08-07 22:03:19.038	\N
1572131156063683731	1572131156055295122	1560328737491256322	2025-08-07 22:03:58.194	\N
1572131313543021730	1572131313543021729	1560328737491256322	2025-08-07 22:04:16.968	\N
1572131367481771185	1572131367481771184	1560328737491256322	2025-08-07 22:04:23.398	\N
1572131516052407488	1572131516052407487	1560328737491256322	2025-08-07 22:04:41.109	\N
1572132139971904737	1572132139971904736	1560328737491256322	2025-08-07 22:05:55.486	\N
1572133169061168388	1572133169052779779	1560328737491256322	2025-08-07 22:07:58.162	\N
1572140517263672615	1572140517255284006	1560328737491256322	2025-08-07 22:22:34.137	\N
1573191157213562206	1573191157196784989	1560328737491256322	2025-08-09 09:10:00.178	\N
1573191243104519559	1573191243087742342	1560328737491256322	2025-08-09 09:10:10.417	\N
1573192322072446384	1573192321996948911	1560328737491256322	2025-08-09 09:12:19.035	\N
1573193617952998873	1573193617936221656	1560328737491256322	2025-08-09 09:14:53.521	\N
1573193971826427394	1573193971809650177	1560328737491256322	2025-08-09 09:15:35.706	\N
1573194907122665004	1573194907097499179	1560328737491256322	2025-08-09 09:17:27.202	\N
1573196042084550229	1573196042059384404	1560328737491256322	2025-08-09 09:19:42.499	\N
1573196403012798078	1573196403004409469	1560328737491256322	2025-08-09 09:20:25.527	\N
1573197654760883879	1573197654752495270	1560328737491256322	2025-08-09 09:22:54.746	\N
1573200268290426576	1573200268282037967	1560328737491256322	2025-08-09 09:28:06.304	\N
1573201067573774073	1573201067548608248	1560328737491256322	2025-08-09 09:29:41.586	\N
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session (id, user_id, access_token, http_only_token, remote_address, user_agent, created_at, updated_at, deleted_at) FROM stdin;
1560294586092356611	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjAzN2Y4YjIyLTU0YzMtNDVhMi04Mzk2LTM2N2FiZWI0M2U2YiJ9.eyJpYXQiOjE3NTMxOTMyMDksImV4cCI6MTc4NDcyOTIwOSwic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.B9YaJbWEbGLo5wG6UuGgeFKDtcixTiCLeCQ0Z462oIs	fcd4dc85-2b9d-4125-81bb-1f21c400d3c6	151.101.128.223	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 14:06:49.095	\N	\N
1560328737491256326	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjllZDg4ODgzLWI0Y2MtNDI0NS1iOTZjLTVkZWZmZTk0ZTg1YSJ9.eyJpYXQiOjE3NTM4NzI2ODMsImV4cCI6MTc4NTQwODY4Mywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.q02RBVLTM2Ald69pfn8xBcUCATBdqAFcFP-ndN-_hF4	\N	127.0.0.1	API Client	2025-07-30 10:51:29.898679	2025-07-30 10:51:29.898679	\N
1565996599279092742	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImIxMDJmZjE3LWU4MjgtNDJhZC05ZDk4LTVlMDFmNjgxNWY4ZiJ9.eyJpYXQiOjE3NTM4NzI5NDIsImV4cCI6MTc4NTQwODk0Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ml3BmWfjj03jomVI2uJdJLlqj8F2fIQkuT5c6CBtNLA	b153c63b-4562-49ca-8cee-2727a4dc051d	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 10:55:42.036	2025-07-30 11:00:11.817	2025-07-30 11:00:11.816
1565998904820892680	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjE3ZDFhYTk1LTM1MmUtNDMwNS04NjZjLTdmMjA0MTY1MjU4ZCJ9.eyJpYXQiOjE3NTM4NzMyMTYsImV4cCI6MTc4NTQwOTIxNiwic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.wxOtFDkb6tEuB-e-G87QBgIFe98EKxESq2uc6vxbvdU	6bfaa4a3-4721-4086-ba63-b0cab1c19a18	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:00:16.878	2025-07-30 11:11:25.3	2025-07-30 11:11:25.298
1566004531731366934	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjBmYmM0ODk2LTI4MWYtNDViOC04NzAyLTNmMGIyMGM4Y2RiZiJ9.eyJpYXQiOjE3NTM4NzM4ODcsImV4cCI6MTc4NTQwOTg4Nywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.8DAHLMniUdCG8eMZkrVi6xM6P0vbTmcx8LYuLbSKAmU	c8d09b71-a2f6-4a6f-927c-fd894eeda38b	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:11:27.659	2025-07-30 11:23:34.744	2025-07-30 11:23:34.743
1566010658535769148	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjkxODMwNWZmLWMzYzMtNDkxMy05YmJkLWZhODkwYWQ0N2UxMiJ9.eyJpYXQiOjE3NTM4NzQ2MTgsImV4cCI6MTc4NTQxMDYxOCwic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.TM6KEQJQBuXsZ7ffjVjcRKrFcArXVaelDHBjgVuxunI	606003c2-c924-4b8f-bae4-f45c63da76ff	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:23:38.032	2025-07-30 11:29:54.912	2025-07-30 11:29:54.91
1566013844503921729	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjcyZmQyYzM1LWVhNjItNDZkYy1iYjA4LTk2MDgzOTUyYmFkMCJ9.eyJpYXQiOjE3NTM4NzQ5OTcsImV4cCI6MTc4NTQxMDk5Nywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Ut1GIjkn2kdZ_OFTubbZTlm7VWgfrycsHTGkORENfXs	49686d2f-d3b0-4688-8979-9ee345e3db01	142.251.36.27	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:29:57.829	\N	\N
1572105354811016308	1560278692305830913	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQzYWMyMTcxLTQ0YmEtNDQ0Yi05YzU0LTVhYzU5NDMzY2Y2YSJ9.eyJpYXQiOjE3NTQ2MDExNjIsImV4cCI6MTc4NjEzNzE2Miwic3ViIjoiMTU2MDI3ODY5MjMwNTgzMDkxMyJ9.wqarkYGmWGchfdqW2CCtNpDL4JXLYAPL4SkDN6ryTnE	019fe815-6f03-496c-ac49-6cab12d4014e	142.250.179.187	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15	2025-08-07 21:12:42.443	\N	\N
1572120589982762101	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg2M2FiMDMwLTUwZjEtNDJmNy1iYTUyLTU3MmEzMzUwMzJkYSJ9.eyJpYXQiOjE3NTQ2MDI5NzgsImV4cCI6MTc4NjEzODk3OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.hIi2r_oad-oBu-zclw2ZvaxaS0W11NLeorH-cKTSJY8	\N	142.250.179.187	Python-urllib/3.13	2025-08-07 21:42:58.618	\N	\N
1572120638863180918	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjY0Y2YxMDM5LTQ3YTAtNDgwNC1iNWE4LWNjZGNmOTgzODdlZSJ9.eyJpYXQiOjE3NTQ2MDI5ODQsImV4cCI6MTc4NjEzODk4NCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Yuq7g116ACd5kml5HP0ayS9FiniAig3gUSC2-gerVE4	\N	142.250.179.187	Python-urllib/3.13	2025-08-07 21:43:04.447	\N	\N
1572120709486871671	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImQ3YzIyOTQxLTkyYTQtNDA4NC1iYTc4LWMxNTVmOTE1ZWYzMSJ9.eyJpYXQiOjE3NTQ2MDI5OTIsImV4cCI6MTc4NjEzODk5Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.e-vOn0G3GnL7PS98X8qmv0QusZxIk1fi_oXHW7fa3WM	\N	142.250.179.187	Python-urllib/3.13	2025-08-07 21:43:12.866	\N	\N
1572120946196612216	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQyM2MzYjlkLTNmZGItNDZhYS04NDc0LTJlNzBlMjJiNTNhYiJ9.eyJpYXQiOjE3NTQ2MDMwMjEsImV4cCI6MTc4NjEzOTAyMSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.LmOR5Htz6wICxT-Ek1aRWKUS6YkSIZqrtFmt7WcDV5k	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:43:41.082	\N	\N
1572121045853275257	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg4OTQ3NGI0LTRmODctNDdhMi04YzUzLTZhMWZmMzQ4NzY4NyJ9.eyJpYXQiOjE3NTQ2MDMwMzIsImV4cCI6MTc4NjEzOTAzMiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Os9ISwVNBNLUjGJE29ZKBh30-KZkxoBqxM7Y07lg8dI	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:43:52.963	\N	\N
1572121901784892538	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjI3NGQxNzJkLTA2ZTktNDA4Zi05ZWIxLWFhODAxZTRkMWI5YiJ9.eyJpYXQiOjE3NTQ2MDMxMzQsImV4cCI6MTc4NjEzOTEzNCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.qqoOOaAnQXVUv_Szc4r9WMa0fN-jC18zZl0QdCQyEXc	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:45:34.998	\N	\N
1572122394867270779	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImU4YjM1OWZkLTk4Y2ItNGUyMy05NjU0LTM1MDUyMTBmZTBmNSJ9.eyJpYXQiOjE3NTQ2MDMxOTMsImV4cCI6MTc4NjEzOTE5Mywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.46DwZc1MK9h2tD2wBgE-nOADpdG9w-Zu7IY4_ZdsMIk	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:46:33.778	\N	\N
1572122796731925628	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjE0YTMzM2YzLTI2NTgtNDAyYy05Y2Q4LTFmZjRiNGZlOTM3OSJ9.eyJpYXQiOjE3NTQ2MDMyNDEsImV4cCI6MTc4NjEzOTI0MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.2lAOwYbTlPAZS3K6D6qhpe9h2xX7ffgg1VzOIciD2Bw	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:47:21.683	\N	\N
1572123028853097599	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjFkNWFmMzBmLTM1YzAtNGZiNy1iY2EwLWE5YzczNDg1YzQ3OCJ9.eyJpYXQiOjE3NTQ2MDMyNjksImV4cCI6MTc4NjEzOTI2OSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.37eztz7Z_VmsL8CNsvm_-Qr80vXvglVlVZtc7S90RZI	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 21:47:49.355	\N	\N
1572130827263804546	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjJjM2VkODc2LTJkNmMtNDAwNi04MWFkLWExMTEyZmM0NjM5OCJ9.eyJpYXQiOjE3NTQ2MDQxOTgsImV4cCI6MTc4NjE0MDE5OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.4rSidu_0MEvWHb36QnCIESkr0urZO4ZYw2J8472hXRU	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:03:18.996	\N	\N
1572131155786859665	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjVmZjA1NzY0LTk0ZTQtNGExNi1hNjBhLWI0OWYzNzFhY2YwNSJ9.eyJpYXQiOjE3NTQ2MDQyMzgsImV4cCI6MTc4NjE0MDIzOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.cIifhdg3RiuPw7BSOdLRKqm4903UZt7OqOOGoVhCU6w	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:03:58.161	\N	\N
1572131313291363488	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjlhZGU5YjQ0LTkyM2MtNDNiYi1hYzczLTE2ZmFiZDkyNGMyMiJ9.eyJpYXQiOjE3NTQ2MDQyNTYsImV4cCI6MTc4NjE0MDI1Niwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.9jrwy4HYjcfDmV3jBvQLhrEROKzo5GWvii12RA8bmQo	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:04:16.937	\N	\N
1572131367280444591	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImVhNmYyZDNlLTk4ZGUtNDg4ZC04ODhkLWFhMDhjMGUyZGI0NiJ9.eyJpYXQiOjE3NTQ2MDQyNjMsImV4cCI6MTc4NjE0MDI2Mywic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Lb110Bgwgd-uvPpHOBj8d2JftFhUwaLg-AuUmdnm3bI	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:04:23.374	\N	\N
1572131515842692286	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjllZTRkZjc5LTZlODAtNGFhNC04OGRlLWE3MWZlM2RkYjBiOCJ9.eyJpYXQiOjE3NTQ2MDQyODEsImV4cCI6MTc4NjE0MDI4MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.7t0D8fRszB2hRqnlo2HV_n0A65YB-BpTy-AzwIt7zWY	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:04:41.082	\N	\N
1572132139728635103	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImFjMmM4Yzc1LTU1YTUtNDUzZi05NTg1LTVmYmRlYWM5Y2Q4MCJ9.eyJpYXQiOjE3NTQ2MDQzNTUsImV4cCI6MTc4NjE0MDM1NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.33sXLWxXv5OqxPc7w6wYEWyMKVRtvfTShfqWLDmXRDE	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:05:55.455	\N	\N
1572132307601458432	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjZiN2FlMDlkLWJhNzYtNGRmNC1hZTU2LWJhNmVkNGVlMjQyZSJ9.eyJpYXQiOjE3NTQ2MDQzNzUsImV4cCI6MTc4NjE0MDM3NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.BlgzsB6XtVucEjzOPudMcjrry0LSoZqdt80V03rC6Jo	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:06:15.467	\N	\N
1572132506755400961	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImUzMjE4YjkyLTA2MTUtNGEwNi05ODgyLThjMTdjNDlmN2Y4MiJ9.eyJpYXQiOjE3NTQ2MDQzOTksImV4cCI6MTc4NjE0MDM5OSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.5nrfWnMwyYMcZhMA5KopAvEPSxh875YAWCsfCvU7PhM	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:06:39.208	\N	\N
1572133168926950658	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc0YmMzMTE4LTExNDUtNDk4NS1hOTY0LTM5OWNjNmNhMDM5NCJ9.eyJpYXQiOjE3NTQ2MDQ0NzgsImV4cCI6MTc4NjE0MDQ3OCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.ktDc75UculROzIG6FKvUfetBEW4amYDaLbqCk_eZPkw	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:07:58.145	\N	\N
1572139607955342627	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijg4NDNiNTAwLTg4M2QtNDExNS1hOTc1LTU5ZDU3OWU4ZTYwYSJ9.eyJpYXQiOjE3NTQ2MDUyNDUsImV4cCI6MTc4NjE0MTI0NSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.eVskS1Lq74Or76EMZjQ2_XPOW-OYImmxuOkCnlaLPVo	4ed8dc5c-8393-44ba-a459-4063f96f4eb3	142.250.179.187	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-07 22:20:45.737	\N	\N
1572140517012014373	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImNhNWFkMTM4LTJiYjgtNGIzZi1iNDRkLTI0ZmFiZGViZGNmMSJ9.eyJpYXQiOjE3NTQ2MDUzNTQsImV4cCI6MTc4NjE0MTM1NCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Xue2Vaqs0sEhuZ4Hn8L8CnOUdaJBYuN7i8iC8_iy8ek	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:22:34.105	\N	\N
1572141597875766607	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjliOTM5ZjhiLWE4NmMtNGM5Ny1iYmVmLWY2NzQ5NGIzYTk2MyJ9.eyJpYXQiOjE3NTQ2MDU0ODIsImV4cCI6MTc4NjE0MTQ4Miwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Dw5urJY2zYUd29uI46VFo-ms_V0kfeA7QE54qiO2xds	\N	142.250.179.187	python-requests/2.32.4	2025-08-07 22:24:42.955	\N	\N
1573185207350068570	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjI2ZDlkY2U5LWQ4NGYtNGMwZC1iY2E1LThhN2RjMzc1ZGVkOCJ9.eyJpYXQiOjE3NTQ3Mjk4OTAsImV4cCI6MTc4NjI2NTg5MCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.zhOJNh-CKHIMbB30xPt_YWPW6jdCYLbsIEDCm0e9Las	924a3417-bc5d-4a68-a961-f928e9ca1d8c	172.66.128.70	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-09 08:58:10.898	\N	\N
1573191082949215580	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjMwZGU2ZWYzLTExY2MtNDE3Yy05Y2EzLTY3MzQyYWQ4ZWU0YSJ9.eyJpYXQiOjE3NTQ3MzA1OTEsImV4cCI6MTc4NjI2NjU5MSwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.U1DIW7L6FlObNkU6Zp2-ZPs4fyYKYXqPUJeDK_Yd3Zk	\N	172.26.0.2	Python/3.12 aiohttp/3.12.15	2025-08-09 09:09:51.316	\N	\N
1573193974946989610	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJhNzM1ZDlhLThkZTgtNGRkMy04NWYyLWM5Y2U1N2I0NzYyZiJ9.eyJpYXQiOjE3NTQ3MzA5MzYsImV4cCI6MTc4NjI2NjkzNiwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.SOIem_vkR5aL54QKRn5z_eZKHJzXC4uCM9HP6ryKsIA	\N	172.26.0.2	python-requests/2.32.4	2025-08-09 09:15:36.078	\N	\N
1573201460772996897	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImI4Nzg0MzhkLTM0ZDktNDEwNi05NzdkLWVkZWU3MDIwZjBjOSJ9.eyJpYXQiOjE3NTQ3MzE4MjgsImV4cCI6MTc4NjI2NzgyOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.MhMuJaIsQi6hClay_-6VXQfR1jDTxyx6rUQdygkAUkc	\N	172.26.0.2	python-requests/2.32.4	2025-08-09 09:30:28.457	\N	\N
1573203893385430818	1560328737491256322	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImVkZDcwZGY0LTc0MjItNGE0ZS04Y2U2LTBhMmQ5ZGI0ODkzMCJ9.eyJpYXQiOjE3NTQ3MzIxMTgsImV4cCI6MTc4NjI2ODExOCwic3ViIjoiMTU2MDMyODczNzQ5MTI1NjMyMiJ9.Q_3kWuwevvjPzTSY7-TCoBt6OxLoKS-VYosldUtI7fE	\N	172.26.0.2	python-requests/2.32.4	2025-08-09 09:35:18.448	\N	\N
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task (id, task_list_id, assignee_user_id, "position", name, is_completed, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_list (id, card_id, "position", name, show_on_front_of_card, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_account (id, email, password, role, name, username, avatar, phone, organization, language, subscribe_to_own_cards, subscribe_to_card_when_commenting, turn_off_recent_card_highlighting, enable_favorites_by_default, default_editor_mode, default_home_view, default_projects_order, is_sso_user, is_deactivated, created_at, updated_at, password_changed_at) FROM stdin;
1560328737491256323	execution_agent@gmail.com	$2b$10$vpoSEvqsa0KymG.SnTHsU.CwGePmc/gPAO0Ze4/QE.BAUF8UH1SeK	boardUser	Execution Agent	execution_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-30 10:50:39.567685	2025-07-30 11:00:33.651	\N
1560328737491256324	kanban_agent@gmail.com	$2b$10$vpoSEvqsa0KymG.SnTHsU.CwGePmc/gPAO0Ze4/QE.BAUF8UH1SeK	boardUser	Kanban Agent	kanban_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-30 10:50:39.567685	2025-07-30 11:00:37.275	\N
1560328737491256325	meta_agent@gmail.com	$2b$10$vpoSEvqsa0KymG.SnTHsU.CwGePmc/gPAO0Ze4/QE.BAUF8UH1SeK	boardUser	Meta Agent	meta_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-30 10:50:39.567685	2025-07-30 11:00:41.191	\N
1560328737491256322	agent@gmail.com	$2b$10$vpoSEvqsa0KymG.SnTHsU.CwGePmc/gPAO0Ze4/QE.BAUF8UH1SeK	admin	Admin Agent	admin_agent	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-30 10:50:39.567685	2025-07-30 11:23:54.304	\N
1560278692305830913	demo@demo.demo	$2b$10$U0Ha64zX313XAnvFvc7eCOO.KqpuAr39Uo/GxxoJcIJdVy/yAao6e	admin	Demo User	demo	\N	\N	\N	\N	f	t	f	f	wysiwyg	groupedProjects	byDefault	f	f	2025-07-22 13:35:14.411	\N	\N
\.


--
-- Name: migration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migration_id_seq', 4, true);


--
-- Name: migration_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migration_lock_index_seq', 1, true);


--
-- Name: next_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.next_id_seq', 802, true);


--
-- Name: action action_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.action
    ADD CONSTRAINT action_pkey PRIMARY KEY (id);


--
-- Name: attachment attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachment
    ADD CONSTRAINT attachment_pkey PRIMARY KEY (id);


--
-- Name: background_image background_image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.background_image
    ADD CONSTRAINT background_image_pkey PRIMARY KEY (id);


--
-- Name: base_custom_field_group base_custom_field_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.base_custom_field_group
    ADD CONSTRAINT base_custom_field_group_pkey PRIMARY KEY (id);


--
-- Name: board_membership board_membership_board_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_membership
    ADD CONSTRAINT board_membership_board_id_user_id_unique UNIQUE (board_id, user_id);


--
-- Name: board_membership board_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_membership
    ADD CONSTRAINT board_membership_pkey PRIMARY KEY (id);


--
-- Name: board board_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board
    ADD CONSTRAINT board_pkey PRIMARY KEY (id);


--
-- Name: board_subscription board_subscription_board_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_subscription
    ADD CONSTRAINT board_subscription_board_id_user_id_unique UNIQUE (board_id, user_id);


--
-- Name: board_subscription board_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_subscription
    ADD CONSTRAINT board_subscription_pkey PRIMARY KEY (id);


--
-- Name: card_label card_label_card_id_label_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_label
    ADD CONSTRAINT card_label_card_id_label_id_unique UNIQUE (card_id, label_id);


--
-- Name: card_label card_label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_label
    ADD CONSTRAINT card_label_pkey PRIMARY KEY (id);


--
-- Name: card_membership card_membership_card_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_membership
    ADD CONSTRAINT card_membership_card_id_user_id_unique UNIQUE (card_id, user_id);


--
-- Name: card_membership card_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_membership
    ADD CONSTRAINT card_membership_pkey PRIMARY KEY (id);


--
-- Name: card card_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card
    ADD CONSTRAINT card_pkey PRIMARY KEY (id);


--
-- Name: card_subscription card_subscription_card_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_subscription
    ADD CONSTRAINT card_subscription_card_id_user_id_unique UNIQUE (card_id, user_id);


--
-- Name: card_subscription card_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_subscription
    ADD CONSTRAINT card_subscription_pkey PRIMARY KEY (id);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: custom_field_group custom_field_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field_group
    ADD CONSTRAINT custom_field_group_pkey PRIMARY KEY (id);


--
-- Name: custom_field custom_field_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field
    ADD CONSTRAINT custom_field_pkey PRIMARY KEY (id);


--
-- Name: custom_field_value custom_field_value_card_id_custom_field_group_id_custom_field_i; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field_value
    ADD CONSTRAINT custom_field_value_card_id_custom_field_group_id_custom_field_i UNIQUE (card_id, custom_field_group_id, custom_field_id);


--
-- Name: custom_field_value custom_field_value_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field_value
    ADD CONSTRAINT custom_field_value_pkey PRIMARY KEY (id);


--
-- Name: file_reference file_reference_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_reference
    ADD CONSTRAINT file_reference_pkey PRIMARY KEY (id);


--
-- Name: identity_provider_user identity_provider_user_issuer_sub_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider_user
    ADD CONSTRAINT identity_provider_user_issuer_sub_unique UNIQUE (issuer, sub);


--
-- Name: identity_provider_user identity_provider_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider_user
    ADD CONSTRAINT identity_provider_user_pkey PRIMARY KEY (id);


--
-- Name: label label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: list list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list
    ADD CONSTRAINT list_pkey PRIMARY KEY (id);


--
-- Name: migration_lock migration_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration_lock
    ADD CONSTRAINT migration_lock_pkey PRIMARY KEY (index);


--
-- Name: migration migration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration
    ADD CONSTRAINT migration_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: notification_service notification_service_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_service
    ADD CONSTRAINT notification_service_pkey PRIMARY KEY (id);


--
-- Name: project_favorite project_favorite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_favorite
    ADD CONSTRAINT project_favorite_pkey PRIMARY KEY (id);


--
-- Name: project_favorite project_favorite_project_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_favorite
    ADD CONSTRAINT project_favorite_project_id_user_id_unique UNIQUE (project_id, user_id);


--
-- Name: project_manager project_manager_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_manager
    ADD CONSTRAINT project_manager_pkey PRIMARY KEY (id);


--
-- Name: project_manager project_manager_project_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_manager
    ADD CONSTRAINT project_manager_project_id_user_id_unique UNIQUE (project_id, user_id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: session session_access_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_access_token_unique UNIQUE (access_token);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: task_list task_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_list
    ADD CONSTRAINT task_list_pkey PRIMARY KEY (id);


--
-- Name: task task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: user_account user_account_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_email_unique UNIQUE (email);


--
-- Name: user_account user_account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_pkey PRIMARY KEY (id);


--
-- Name: user_account user_account_username_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_username_unique EXCLUDE USING btree (username WITH =) WHERE ((username IS NOT NULL));


--
-- Name: action_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_board_id_index ON public.action USING btree (board_id);


--
-- Name: action_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_card_id_index ON public.action USING btree (card_id);


--
-- Name: action_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_user_id_index ON public.action USING btree (user_id);


--
-- Name: attachment_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachment_card_id_index ON public.attachment USING btree (card_id);


--
-- Name: attachment_creator_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachment_creator_user_id_index ON public.attachment USING btree (creator_user_id);


--
-- Name: background_image_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX background_image_project_id_index ON public.background_image USING btree (project_id);


--
-- Name: base_custom_field_group_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX base_custom_field_group_project_id_index ON public.base_custom_field_group USING btree (project_id);


--
-- Name: board_membership_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_membership_project_id_index ON public.board_membership USING btree (project_id);


--
-- Name: board_membership_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_membership_user_id_index ON public.board_membership USING btree (user_id);


--
-- Name: board_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_position_index ON public.board USING btree ("position");


--
-- Name: board_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_project_id_index ON public.board USING btree (project_id);


--
-- Name: board_subscription_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_subscription_user_id_index ON public.board_subscription USING btree (user_id);


--
-- Name: card_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_board_id_index ON public.card USING btree (board_id);


--
-- Name: card_creator_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_creator_user_id_index ON public.card USING btree (creator_user_id);


--
-- Name: card_description_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_description_index ON public.card USING gin (description public.gin_trgm_ops);


--
-- Name: card_label_label_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_label_label_id_index ON public.card_label USING btree (label_id);


--
-- Name: card_list_changed_at_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_list_changed_at_index ON public.card USING btree (list_changed_at);


--
-- Name: card_list_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_list_id_index ON public.card USING btree (list_id);


--
-- Name: card_membership_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_membership_user_id_index ON public.card_membership USING btree (user_id);


--
-- Name: card_name_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_name_index ON public.card USING gin (name public.gin_trgm_ops);


--
-- Name: card_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_position_index ON public.card USING btree ("position");


--
-- Name: card_subscription_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_subscription_user_id_index ON public.card_subscription USING btree (user_id);


--
-- Name: comment_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX comment_card_id_index ON public.comment USING btree (card_id);


--
-- Name: comment_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX comment_user_id_index ON public.comment USING btree (user_id);


--
-- Name: custom_field_base_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_base_custom_field_group_id_index ON public.custom_field USING btree (base_custom_field_group_id);


--
-- Name: custom_field_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_custom_field_group_id_index ON public.custom_field USING btree (custom_field_group_id);


--
-- Name: custom_field_group_base_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_base_custom_field_group_id_index ON public.custom_field_group USING btree (base_custom_field_group_id);


--
-- Name: custom_field_group_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_board_id_index ON public.custom_field_group USING btree (board_id);


--
-- Name: custom_field_group_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_card_id_index ON public.custom_field_group USING btree (card_id);


--
-- Name: custom_field_group_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_position_index ON public.custom_field_group USING btree ("position");


--
-- Name: custom_field_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_position_index ON public.custom_field USING btree ("position");


--
-- Name: custom_field_value_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_value_custom_field_group_id_index ON public.custom_field_value USING btree (custom_field_group_id);


--
-- Name: custom_field_value_custom_field_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_value_custom_field_id_index ON public.custom_field_value USING btree (custom_field_id);


--
-- Name: file_reference_total_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX file_reference_total_index ON public.file_reference USING btree (total);


--
-- Name: identity_provider_user_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX identity_provider_user_user_id_index ON public.identity_provider_user USING btree (user_id);


--
-- Name: label_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX label_board_id_index ON public.label USING btree (board_id);


--
-- Name: label_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX label_position_index ON public.label USING btree ("position");


--
-- Name: list_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_board_id_index ON public.list USING btree (board_id);


--
-- Name: list_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_position_index ON public.list USING btree ("position");


--
-- Name: list_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_type_index ON public.list USING btree (type);


--
-- Name: notification_action_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_action_id_index ON public.notification USING btree (action_id);


--
-- Name: notification_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_card_id_index ON public.notification USING btree (card_id);


--
-- Name: notification_comment_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_comment_id_index ON public.notification USING btree (comment_id);


--
-- Name: notification_creator_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_creator_user_id_index ON public.notification USING btree (creator_user_id);


--
-- Name: notification_is_read_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_is_read_index ON public.notification USING btree (is_read);


--
-- Name: notification_service_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_service_board_id_index ON public.notification_service USING btree (board_id);


--
-- Name: notification_service_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_service_user_id_index ON public.notification_service USING btree (user_id);


--
-- Name: notification_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_user_id_index ON public.notification USING btree (user_id);


--
-- Name: project_favorite_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_favorite_user_id_index ON public.project_favorite USING btree (user_id);


--
-- Name: project_manager_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_manager_user_id_index ON public.project_manager USING btree (user_id);


--
-- Name: project_owner_project_manager_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_owner_project_manager_id_index ON public.project USING btree (owner_project_manager_id);


--
-- Name: session_remote_address_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX session_remote_address_index ON public.session USING btree (remote_address);


--
-- Name: session_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX session_user_id_index ON public.session USING btree (user_id);


--
-- Name: task_assignee_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_assignee_user_id_index ON public.task USING btree (assignee_user_id);


--
-- Name: task_list_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_list_card_id_index ON public.task_list USING btree (card_id);


--
-- Name: task_list_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_list_position_index ON public.task_list USING btree ("position");


--
-- Name: task_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_position_index ON public.task USING btree ("position");


--
-- Name: task_task_list_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_task_list_id_index ON public.task USING btree (task_list_id);


--
-- Name: user_account_is_deactivated_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_account_is_deactivated_index ON public.user_account USING btree (is_deactivated);


--
-- Name: user_account_role_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_account_role_index ON public.user_account USING btree (role);


--
-- Name: user_account_username_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_account_username_index ON public.user_account USING btree (username);


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

